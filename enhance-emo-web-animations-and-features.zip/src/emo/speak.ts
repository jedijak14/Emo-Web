// Optional spoken replies (browser speech synthesis). EMO keeps the voice small and chirpy.
let enabled = true;
let voice: SpeechSynthesisVoice | null = null;
export let speakingUntil = 0;

export function setSpeakEnabled(on: boolean) {
  enabled = on;
  if (!on && typeof speechSynthesis !== "undefined") speechSynthesis.cancel();
}
export const speakSupported = () => typeof speechSynthesis !== "undefined";

function pickVoice() {
  if (voice || typeof speechSynthesis === "undefined") return;
  const vs = speechSynthesis.getVoices().filter((v) => /^en/i.test(v.lang));
  voice = vs.find((v) => /samantha|google us english|aria|jenny|zira|karen|female/i.test(v.name)) || vs[0] || null;
}

export function speak(text: string, onDone?: () => void) {
  if (!enabled || typeof speechSynthesis === "undefined" || !text) return;
  pickVoice();
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text.replace(/°F/g, " degrees Fahrenheit").replace(/°C/g, " degrees Celsius").replace(/°/g, " degrees"));
    if (voice) u.voice = voice;
    u.lang = voice?.lang || "en-US";
    u.rate = 1.04; u.pitch = 1.45; u.volume = 0.9;
    speakingUntil = performance.now() + 1500 + text.length * 80;
    u.onend = () => { speakingUntil = performance.now() + 600; onDone?.(); };
    speechSynthesis.speak(u);
  } catch { /* ignore */ }
}

if (typeof speechSynthesis !== "undefined") {
  speechSynthesis.onvoiceschanged = () => { voice = null; pickVoice(); };
}
