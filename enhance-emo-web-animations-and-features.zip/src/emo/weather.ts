// Shared weather types + helpers (used by the /api/weather route and the client).
export type SceneKind = "clear" | "partly" | "cloudy" | "fog" | "drizzle" | "rain" | "storm" | "snow" | "sleet";

export interface WeatherInfo {
  place: string;
  kind: SceneKind;
  desc: string;
  intensity: number; // 0..1 (how hard it rains / snows)
  isDay: boolean;
  tempC: number;
  feelsC: number;
  highC: number;
  lowC: number;
  humidity: number;
  windKmh: number;
  rainChance: number; // 0..100
  precipMm: number;
  source: string;
  lat?: number;
  lon?: number;
}

export type Units = "auto" | "f" | "c";

export function resolveUnits(u: Units): "f" | "c" {
  if (u !== "auto") return u;
  if (typeof navigator === "undefined") return "c";
  return /^en-(US|LR|MM)/i.test(navigator.language) ? "f" : "c";
}

export const cToF = (c: number) => (c * 9) / 5 + 32;

export function fmtTemp(c: number, u: "f" | "c") {
  return `${Math.round(u === "f" ? cToF(c) : c)}°`;
}
export function fmtTempUnit(c: number, u: "f" | "c") {
  return `${Math.round(u === "f" ? cToF(c) : c)}°${u.toUpperCase()}`;
}
export function fmtWind(kmh: number, u: "f" | "c") {
  return u === "f" ? `${Math.round(kmh * 0.621)} mph` : `${Math.round(kmh)} km/h`;
}

export type WeatherTopic = "general" | "temp" | "rain" | "wind" | "humidity" | "forecast" | "feels" | "advice";

/** What EMO shows big on his screen + the sentence he says out loud / writes in the card. */
export function describeWeather(w: WeatherInfo, topic: WeatherTopic, u: "f" | "c") {
  const where = w.place ? ` in ${w.place}` : "";
  const t = fmtTempUnit(w.tempC, u).replace("°F", " degrees Fahrenheit").replace("°C", " degrees Celsius");
  const desc = w.desc.toLowerCase();
  let big = fmtTemp(w.tempC, u);
  let sentence = "";
  switch (topic) {
    case "temp":
      sentence = `It's ${t}${where}, and it feels like ${fmtTemp(w.feelsC, u)}.`;
      break;
    case "feels":
      big = fmtTemp(w.feelsC, u);
      sentence = `It feels like ${fmtTemp(w.feelsC, u)} right now. The real temperature is ${fmtTemp(w.tempC, u)}.`;
      break;
    case "rain":
      big = `${Math.round(w.rainChance)}%`;
      sentence = w.kind === "rain" || w.kind === "drizzle" || w.kind === "storm"
        ? `Yes, it's ${desc} right now${where}. Chance of rain today is ${Math.round(w.rainChance)} percent.`
        : w.kind === "snow" || w.kind === "sleet"
          ? `It's ${desc} right now${where}.`
          : `${w.rainChance >= 50 ? "Probably" : "Not likely"}. There's a ${Math.round(w.rainChance)} percent chance of rain today${where}.`;
      break;
    case "wind":
      big = fmtWind(w.windKmh, u).replace(" ", "");
      sentence = `Wind is blowing at ${fmtWind(w.windKmh, u)}${where}.`;
      break;
    case "humidity":
      big = `${Math.round(w.humidity)}%`;
      sentence = `Humidity is ${Math.round(w.humidity)} percent${where}.`;
      break;
    case "forecast":
      sentence = `Today${where}: ${desc}, a high of ${fmtTemp(w.highC, u)} and a low of ${fmtTemp(w.lowC, u)}. ${Math.round(w.rainChance)} percent chance of rain.`;
      break;
    case "advice": {
      const wet = w.kind === "rain" || w.kind === "drizzle" || w.kind === "storm" || w.rainChance >= 60;
      const cold = w.feelsC <= 8;
      const hot = w.feelsC >= 30;
      sentence = `${wet ? "Take an umbrella. " : ""}${cold ? "Wear a warm jacket. " : hot ? "It's hot, dress light and drink water. " : !wet ? "A light layer should do. " : ""}It's ${fmtTemp(w.tempC, u)} and ${desc}.`.trim();
      break;
    }
    default:
      sentence = `It's ${t} and ${desc}${where}. High ${fmtTemp(w.highC, u)}, low ${fmtTemp(w.lowC, u)}.`;
  }
  return { big, small: w.desc.toUpperCase(), sentence };
}

export const SAMPLE: Record<string, WeatherInfo> = Object.fromEntries(
  (
    [
      ["clear-day", "clear", "Sunny", 0.5, true, 27],
      ["clear-night", "clear", "Clear night", 0.5, false, 15],
      ["partly", "partly", "Partly cloudy", 0.5, true, 21],
      ["cloudy", "cloudy", "Overcast", 0.5, true, 17],
      ["fog", "fog", "Foggy", 0.5, true, 11],
      ["drizzle", "drizzle", "Light drizzle", 0.3, true, 14],
      ["rain", "rain", "Rain", 0.65, true, 12],
      ["heavy-rain", "rain", "Heavy rain", 1, true, 10],
      ["storm", "storm", "Thunderstorm", 0.9, true, 18],
      ["snow", "snow", "Snow", 0.6, true, -3],
    ] as [string, SceneKind, string, number, boolean, number][]
  ).map(([id, kind, desc, intensity, isDay, tempC]) => [
    id,
    {
      place: "Test City", kind, desc, intensity, isDay, tempC, feelsC: tempC - 2, highC: tempC + 3, lowC: tempC - 5,
      humidity: kind === "clear" ? 35 : 78, windKmh: kind === "storm" ? 42 : 12,
      rainChance: kind === "rain" || kind === "storm" ? 90 : kind === "drizzle" ? 55 : 10, precipMm: 0, source: "test",
    } satisfies WeatherInfo,
  ]),
);
