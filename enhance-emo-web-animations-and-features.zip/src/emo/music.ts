// Music: search + resolve through our own API routes (no flaky public CORS proxies),
// playback through the YouTube IFrame Player API, falling back to the 30-second catalogue preview.
export interface Track {
  id: string;
  title: string;
  artist: string;
  art: string;
  previewUrl?: string;
  videoId?: string;
  alts?: string[];
}

export type PlayStatus = "idle" | "loading" | "playing" | "paused";
export interface PlayerState { status: PlayStatus; track?: Track; full: boolean; note?: string }

function withTimeout(url: string, ms = 9000, init?: RequestInit): Promise<Response> {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  return fetch(url, { ...init, signal: ctl.signal }).finally(() => clearTimeout(t));
}

export async function searchTracks(q: string, apiKey?: string): Promise<Track[]> {
  const r = await withTimeout(`/api/music/search?q=${encodeURIComponent(q)}`, 12000, apiKey ? { headers: { "x-yt-key": apiKey } } : undefined);
  if (!r.ok) throw new Error("search failed");
  const j = await r.json();
  return (j.tracks || []) as Track[];
}

async function resolveVideoIds(t: Track, apiKey?: string): Promise<string[]> {
  if (t.videoId) return [t.videoId, ...(t.alts || [])];
  try {
    const r = await withTimeout(`/api/music/resolve?artist=${encodeURIComponent(t.artist)}&title=${encodeURIComponent(t.title)}`, 10000, apiKey ? { headers: { "x-yt-key": apiKey } } : undefined);
    const j = await r.json();
    return (j.ids || []) as string[];
  } catch {
    return [];
  }
}

let ytPromise: Promise<void> | null = null;
function loadYT(): Promise<void> {
  if (ytPromise) return ytPromise;
  ytPromise = new Promise((resolve, reject) => {
    const w = window as any;
    if (w.YT?.Player) return resolve();
    const prev = w.onYouTubeIframeAPIReady;
    w.onYouTubeIframeAPIReady = () => { prev?.(); resolve(); };
    const s = document.createElement("script");
    s.src = "https://www.youtube.com/iframe_api";
    s.onerror = () => { ytPromise = null; reject(new Error("yt blocked")); };
    document.head.appendChild(s);
    setTimeout(() => { if (!w.YT?.Player) { ytPromise = null; reject(new Error("yt timeout")); } }, 10000);
  });
  return ytPromise;
}

export class MusicPlayer {
  state: PlayerState = { status: "idle", full: false };
  queue: Track[] = [];
  index = -1;
  apiKey = "";
  volume = 80;
  ducked = false;
  onChange?: (s: PlayerState) => void;
  onEnded?: () => void;
  private yt: any = null;
  private ytReady: Promise<void> | null = null;
  private audio: HTMLAudioElement | null = null;
  private cands: string[] = [];
  private candIdx = 0;
  private token = 0;
  private watch: ReturnType<typeof setTimeout> | null = null;

  private set(s: Partial<PlayerState>) {
    this.state = { ...this.state, ...s };
    this.onChange?.(this.state);
  }

  get position() {
    try { if (this.audio) return this.audio.currentTime; return this.yt?.getCurrentTime?.() || 0; } catch { return 0; }
  }
  get duration() {
    try { if (this.audio) return this.audio.duration || 30; return this.yt?.getDuration?.() || 0; } catch { return 0; }
  }
  seek(frac: number) {
    try {
      const d = this.duration;
      if (!d) return;
      if (this.audio) this.audio.currentTime = d * frac;
      else this.yt?.seekTo?.(d * frac, true);
    } catch { /* ignore */ }
  }

  async play(track: Track, queue?: Track[]) {
    const my = ++this.token;
    this.killMedia();
    if (queue) this.queue = queue;
    this.index = this.queue.findIndex((t) => t.id === track.id);
    this.set({ status: "loading", track, full: false, note: undefined });
    const ids = await resolveVideoIds(track, this.apiKey);
    if (my !== this.token) return;
    this.cands = ids;
    this.candIdx = 0;
    if (ids.length) {
      try {
        await this.playYT(ids[0], my);
        return;
      } catch { /* fall back */ }
    }
    if (my !== this.token) return;
    this.playPreview(track, my);
  }

  private armWatch(my: number) {
    if (this.watch) clearTimeout(this.watch);
    this.watch = setTimeout(() => {
      if (my !== this.token || this.state.status === "playing") return;
      this.nextCandidate(my);
    }, 9000);
  }

  private nextCandidate(my: number) {
    if (my !== this.token) return;
    this.candIdx++;
    if (this.candIdx < this.cands.length && this.yt) {
      try { this.yt.loadVideoById(this.cands[this.candIdx]); this.armWatch(my); return; } catch { /* fall through */ }
    }
    try { this.yt?.stopVideo?.(); } catch { /* ignore */ }
    if (this.state.track) this.playPreview(this.state.track, my);
  }

  private async playYT(id: string, my: number) {
    await loadYT();
    if (my !== this.token) return;
    const w = window as any;
    const onState = (s: number) => {
      if (my !== this.token) return;
      if (s === 1) { if (this.watch) clearTimeout(this.watch); this.set({ status: "playing", full: true, note: undefined }); }
      else if (s === 2 && this.state.status === "playing") this.set({ status: "paused" });
      else if (s === 0) this.onEnded?.();
    };
    this.handlers = { state: onState, error: () => this.nextCandidate(my) };
    if (!this.yt) {
      const host = document.createElement("div");
      host.style.cssText = "position:fixed;right:0;bottom:0;width:200px;height:200px;opacity:0.01;pointer-events:none;overflow:hidden;z-index:-1";
      const inner = document.createElement("div");
      inner.id = "emo-yt";
      host.appendChild(inner);
      document.body.appendChild(host);
      this.ytReady = new Promise<void>((resolve) => {
        this.yt = new w.YT.Player("emo-yt", {
          width: 200, height: 200, videoId: id,
          playerVars: { autoplay: 1, controls: 0, playsinline: 1, rel: 0, origin: location.origin },
          events: {
            onReady: (e: any) => { e.target.setVolume(this.effVol()); e.target.playVideo(); resolve(); },
            onStateChange: (e: any) => this.handlers.state(e.data),
            onError: () => this.handlers.error(),
          },
        });
      });
      this.armWatch(my);
      await this.ytReady;
    } else {
      await this.ytReady;
      this.yt.loadVideoById(id);
      this.yt.setVolume(this.effVol());
      this.armWatch(my);
    }
  }
  private handlers: { state: (s: number) => void; error: () => void } = { state: () => {}, error: () => {} };

  private playPreview(track: Track, my: number) {
    if (!track.previewUrl) { this.set({ status: "idle", full: false, note: "Couldn't play that one." }); return; }
    const a = new Audio(track.previewUrl);
    a.volume = this.effVol() / 100;
    this.audio = a;
    a.onplaying = () => { if (my === this.token) this.set({ status: "playing", full: false, note: "30s preview" }); };
    a.onpause = () => { if (my === this.token && !a.ended) this.set({ status: "paused" }); };
    a.onended = () => { if (my === this.token) this.onEnded?.(); };
    a.onerror = () => { if (my === this.token) this.set({ status: "idle", note: "Couldn't play that one." }); };
    a.play().catch(() => { if (my === this.token) this.set({ status: "paused", note: "Tap play to start" }); });
  }

  private effVol() { return this.ducked ? Math.round(this.volume * 0.2) : this.volume; }
  private applyVol() {
    try { this.yt?.setVolume?.(this.effVol()); } catch { /* */ }
    if (this.audio) this.audio.volume = this.effVol() / 100;
  }
  setVolume(v: number) { this.volume = Math.max(0, Math.min(100, v)); this.applyVol(); }
  duck(on: boolean) { if (this.ducked !== on) { this.ducked = on; this.applyVol(); } }

  pause() {
    if (this.audio) this.audio.pause();
    else try { this.yt?.pauseVideo?.(); } catch { /* */ }
    if (this.state.status === "playing") this.set({ status: "paused" });
  }
  resume() {
    if (this.audio) this.audio.play().catch(() => {});
    else try { this.yt?.playVideo?.(); } catch { /* */ }
  }
  private killMedia() {
    if (this.watch) clearTimeout(this.watch);
    if (this.audio) { this.audio.pause(); this.audio.src = ""; this.audio = null; }
    try { this.yt?.stopVideo?.(); } catch { /* */ }
  }
  stop() {
    this.token++;
    this.killMedia();
    this.set({ status: "idle", track: undefined, full: false, note: undefined });
  }
  next() { if (this.queue.length) this.play(this.queue[(this.index + 1) % this.queue.length]); }
  prev() { if (this.queue.length) this.play(this.queue[(this.index - 1 + this.queue.length) % this.queue.length]); }
}
