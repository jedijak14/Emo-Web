import type { WeatherTopic } from "./weather";

export type Cmd =
  | { t: "act"; id: string }
  | { t: "play"; q: string }
  | { t: "music-own" }
  | { t: "stop" } | { t: "pause" } | { t: "resume" } | { t: "next" } | { t: "prev" }
  | { t: "vol"; dir: 1 | -1 }
  | { t: "pick"; n: number }
  | { t: "timer"; secs: number; label?: string } | { t: "timer-show" } | { t: "timer-cancel" }
  | { t: "stopwatch"; op: "start" | "stop" | "show" | "reset" }
  | { t: "clock" } | { t: "date" }
  | { t: "weather"; topic: WeatherTopic; place?: string }
  | { t: "dice"; n: number } | { t: "coin" } | { t: "rps"; you?: string }
  | { t: "number"; min: number; max: number }
  | { t: "calc"; a: number; op: "+" | "-" | "*" | "/"; b: number }
  | { t: "joke" } | { t: "ask"; id: "name" | "help" | "age" }
  | { t: "color"; name: string; rgb: [number, number, number] | null }
  | { t: "mute"; on: boolean }
  | { t: "camera"; on: boolean } | { t: "remember" } | { t: "forget" }
  | { t: "release" }
  | { t: "unknown" };

/* ---------------- wake word ---------------- */
const EMO_VARIANTS = ["emo", "e-mo", "eemo", "emmo", "emu", "imo", "amo", "aymo", "emoh", "ee mo", "e mo", "emma", "ema", "himo", "eimo", "aimo", "eamo", "eemoh", "eemu", "aemo"];
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

export function normalizeWake(w: string) {
  return w.toLowerCase().replace(/[^a-z0-9' -]/g, " ").replace(/^(?:hey|hi|ok|okay|yo)\s+/, "").replace(/\s+/g, " ").trim();
}

function build(word: string) {
  const w = normalizeWake(word) || "emo";
  const alts = w === "emo" ? EMO_VARIANTS.map(esc) : [esc(w).replace(/[ -]+/g, "[\\s-]*")];
  return new RegExp(`\\b(?:(?:hey|hi|ok|okay|yo|hay)[\\s,]+)?(?:${alts.join("|")})\\b[\\s,.!?]*`);
}

let WAKE = build("emo");
export let wakeWord = "emo";
export function setWakeWord(w: string) {
  wakeWord = normalizeWake(w) || "emo";
  WAKE = build(wakeWord);
}
export function hasWake(text: string) {
  return WAKE.test(text.toLowerCase());
}

/* ---------------- numbers ---------------- */
const ONES: Record<string, number> = {
  zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12,
  thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18, nineteen: 19,
  twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90,
};
const NW = Object.keys(ONES).join("|");
const NUM = `(\\d+(?:\\.\\d+)?|a|an|half|(?:${NW})(?:[\\s-](?:${NW}))?)`;

function toNum(s: string): number {
  if (/^\d/.test(s)) return parseFloat(s);
  if (s === "a" || s === "an") return 1;
  if (s === "half") return 0.5;
  return s.split(/[\s-]+/).reduce((a, w) => a + (ONES[w] ?? 0), 0);
}

const PICK: Record<string, number> = {
  one: 1, "1": 1, first: 1, two: 2, "2": 2, second: 2, three: 3, "3": 3, third: 3,
  four: 4, "4": 4, fourth: 4, five: 5, "5": 5, fifth: 5, six: 6, "6": 6, sixth: 6,
};
const PICK_RE = /^(?:play |pick |choose |select |the )?(?:number |option |song |track )?(one|two|three|four|five|six|1|2|3|4|5|6|first|second|third|fourth|fifth|sixth)(?: one| song)?$/;

function parseDuration(t: string): number {
  const re = new RegExp(`${NUM}\\s*(hours?|hrs?|minutes?|mins?|seconds?|secs?)\\b`, "g");
  let total = 0, last = 0, m: RegExpExecArray | null;
  while ((m = re.exec(t))) {
    const n = toNum(m[1]);
    const unit = /^h/.test(m[2]) ? 3600 : /^m/.test(m[2]) ? 60 : 1;
    total += n * unit; last = unit;
  }
  if (last && /and a half/.test(t)) total += last / 2;
  return Math.round(total);
}

function parseAlarm(t: string): { secs: number; label: string } | null {
  if (!/\balarm\b|wake me( up)?|remind me/.test(t)) return null;
  const m = t.match(/\b(?:for|at)\s+(\d{1,2})(?:[:\s.]?(\d{2}))?\s*(a\.?m\.?|p\.?m\.?|in the morning|in the evening|at night)?/);
  if (!m) return null;
  let h = +m[1];
  const min = m[2] ? +m[2] : 0;
  if (h > 24 || min > 59) return null;
  const mer = m[3] ? (/^p|even|night/.test(m[3]) ? "pm" : "am") : "";
  const now = new Date();
  const mk = (hh: number) => { const d = new Date(now); d.setHours(hh, min, 0, 0); if (d.getTime() <= now.getTime() + 1000) d.setDate(d.getDate() + 1); return d; };
  let target: Date;
  if (mer) { if (mer === "pm" && h < 12) h += 12; if (mer === "am" && h === 12) h = 0; target = mk(h); }
  else if (h >= 13 || h === 0) target = mk(h % 24);
  else { const a = mk(h % 12), b = mk((h % 12) + 12); target = a < b ? a : b; }
  const label = target.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  return { secs: Math.max(1, Math.round((target.getTime() - now.getTime()) / 1000)), label: `Alarm ${label}` };
}

const COLORS: Record<string, [number, number, number]> = {
  red: [255, 84, 70], blue: [70, 140, 255], green: [110, 255, 130], purple: [175, 120, 255], pink: [255, 110, 190],
  orange: [255, 160, 60], yellow: [255, 230, 80], white: [240, 245, 255], cyan: [62, 244, 255], teal: [60, 230, 200],
};

const TOPIC_PLACE_STOP = /^(the|my|this|here|home|a|an|it|me|you|your|us|there|today|tonight|tomorrow|now|outside|morning|evening|afternoon|night|a minute|case)$/;

function parseWeather(t: string): Cmd | null {
  const isWeather =
    /weather|temperature|\btemp\b|forecast|how (hot|cold|warm|chilly)|degrees (out|outside)|raining|\bwill it (rain|snow)|\bis it (going to )?(rain|snow|sunny|windy|cold|hot|warm|humid)|\bwindy\b|humidity|humid\b|umbrella|jacket|feels like|what'?s it like outside|how'?s it outside|going to (rain|snow)|do i need a (coat|jacket)/.test(t);
  if (!isWeather) return null;
  let topic: WeatherTopic = "general";
  if (/umbrella|jacket|coat|what (should|do) i wear|bring/.test(t)) topic = "advice";
  else if (/feels like/.test(t)) topic = "feels";
  else if (/rain|snow|precip/.test(t)) topic = "rain";
  else if (/wind/.test(t)) topic = "wind";
  else if (/humid/.test(t)) topic = "humidity";
  else if (/temperature|\btemp\b|how (hot|cold|warm|chilly)|degrees|is it (hot|cold|warm)/.test(t)) topic = "temp";
  else if (/forecast|high|low|today|tonight/.test(t) && /forecast|high|low/.test(t)) topic = "forecast";
  let place: string | undefined;
  const pm = t.match(/\b(?:in|at|for|near|around)\s+([a-z][a-z\s.'-]{1,40}?)(?:\s+(?:right now|today|tonight|tomorrow|now|please|outside|currently|this (?:morning|evening|afternoon|weekend))\b.*)?$/);
  if (pm) {
    const p = pm[1].trim();
    if (!TOPIC_PLACE_STOP.test(p) && !/^(the )?(morning|evening|afternoon|house|room)/.test(p) && p.split(" ").length <= 4) {
      place = p.replace(/\b\w/g, (c) => c.toUpperCase());
    }
  }
  return { t: "weather", topic, place };
}

export function parse(raw: string, o: { requireWake: boolean; hasResults: boolean }): { woke: boolean; cmd: Cmd | null } {
  // raw may contain several alternatives separated by " | "
  const alts = raw.toLowerCase().split("|").map((s) => s.trim()).filter(Boolean);
  let woke = false;
  let best: Cmd | null = null;
  for (const a of alts) {
    let t = a;
    const m = t.match(WAKE);
    if (m) { woke = true; t = t.slice((m.index || 0) + m[0].length); }
    else if (o.requireWake && !(o.hasResults && PICK_RE.test(t))) continue;
    t = t.replace(/^(please|can you|could you|will you|would you|let's|lets|i want you to|i'd like you to|tell me|show me)\s+/g, (x) => (/^(tell me|show me)/.test(x) ? x : "")).trim();
    const c = match(t, o.hasResults);
    if (c && c.t !== "unknown") return { woke, cmd: c };
    if (!best && t.length > 1) best = c;
  }
  return { woke, cmd: woke || !o.requireWake ? best : null };
}

function act(id: string): Cmd { return { t: "act", id }; }

function match(t: string, hasResults: boolean): Cmd {
  t = t.replace(/[.!?]+$/g, "").trim();
  if (!t) return { t: "unknown" };
  let m: RegExpMatchArray | null;

  if (hasResults && (m = t.match(PICK_RE))) return { t: "pick", n: PICK[m[1]] };
  if (/hands? (down|back)|put (them|your hands?) down|relax|at ease|calm down|it'?s ok|you can lower/.test(t)) return { t: "release" };
  if (/hands? up|stick ?(em|them|'em) up|put (your|ya) hands|freeze|don'?t move|this is a (hold ?up|robbery)|raise your hands/.test(t)) return act("handsup");
  if (/dodge|bullet|matrix|duck\b|incoming|neo\b|look out/.test(t)) return act("dodge");
  if (/\b(bang|shoot|pew|gun|fire)\b/.test(t)) return act("shoot");
  if (/play dead|pretend (to be )?dead|die\b/.test(t)) return act("dead");
  if (/play (by yourself|with me|a game)|go play|explore/.test(t)) return act("dance");
  if (/happy birthday|(it'?s|its) my birthday|birthday/.test(t)) return act("birthday");

  // alarms + timers
  const al = parseAlarm(t);
  if (al) return { t: "timer", secs: al.secs, label: al.label };
  if (/cancel .*(timer|alarm)|stop .*(timer|alarm)|clear .*(timer|alarm)|turn off .*(timer|alarm)|delete .*(timer|alarm)/.test(t)) return { t: "timer-cancel" };
  if (/timer|countdown|remind me in|wake me in|alarm in/.test(t)) {
    const secs = parseDuration(t);
    if (secs > 0) return { t: "timer", secs };
    if (/how much|time left|left|remaining|show|check/.test(t)) return { t: "timer-show" };
  }
  if (/how much time|time left|how long (is|until|left)/.test(t)) return { t: "timer-show" };
  if (/stop ?watch/.test(t)) {
    if (/reset|clear/.test(t)) return { t: "stopwatch", op: "reset" };
    if (/\b(start|begin|go|run|open|set|launch)\b/.test(t)) return { t: "stopwatch", op: "start" };
    if (/\b(stop|pause|end|finish|lap)\b/.test(t)) return { t: "stopwatch", op: "stop" };
    return { t: "stopwatch", op: "show" };
  }

  if (/what('?s| is) the (date|day)|what day is it|what'?s today|today'?s date|which day|what is today|what date/.test(t)) return { t: "date" };
  if (/what('?s| is) the time|what time|\bclock\b|show (me )?the time|time is it|tell me the time|the time please|current time/.test(t)) return { t: "clock" };

  const w = parseWeather(t);
  if (w) return w;

  if ((m = t.match(/(?:what(?:'s| is)|calculate|compute|how much is)\s+(\d+(?:\.\d+)?|[a-z-]+)\s*(plus|minus|times|multiplied by|divided by|over|x|\+|-|\*|\/)\s*(\d+(?:\.\d+)?|[a-z-]+)/))) {
    const a = toNum(m[1]), b = toNum(m[3]);
    if (Number.isFinite(a) && Number.isFinite(b) && (/^\d/.test(m[1]) || ONES[m[1]] !== undefined) && (/^\d/.test(m[3]) || ONES[m[3]] !== undefined)) {
      const op = /plus|\+/.test(m[2]) ? "+" : /minus|-/.test(m[2]) ? "-" : /divid|over|\//.test(m[2]) ? "/" : "*";
      return { t: "calc", a, op, b };
    }
  }
  if (/(pick|give me|choose|say|random).*number|number between|random number/.test(t)) {
    const r = t.match(/between (\d+) and (\d+)/);
    const to = t.match(/(?:to|up to|out of) (\d+)/);
    const min = r ? +r[1] : 1, max = r ? +r[2] : to ? +to[1] : t.includes("hundred") ? 100 : 10;
    return { t: "number", min: Math.min(min, max), max: Math.max(min, max) };
  }
  if (/rock[, ]+paper|paper[, ]+scissors|\bjan ?ken\b/.test(t) || /^(i |i'?ll )?(choose|pick|throw|play|go with) (rock|paper|scissors)$/.test(t)) {
    const y = t.match(/\b(rock|paper|scissors)\b(?!.*\b(paper|scissors)\b)/);
    return { t: "rps", you: /choose|pick|throw|go with/.test(t) && y ? y[1] : undefined };
  }
  if (/(roll|throw|toss).*(die|dice)|\bdice\b|\bdie\b/.test(t)) return { t: "dice", n: /two|2|pair|both/.test(t) ? 2 : 1 };
  if (/(flip|toss).*coin|coin (flip|toss)|heads or tails/.test(t)) return { t: "coin" };
  if (/(tell|say|know).*(joke|something funny)|joke|make me laugh/.test(t)) return { t: "joke" };

  if (/(turn|switch) (on|off) (the |your )?(camera|eyes)|(open|close) your eyes|look at me|see me/.test(t)) {
    return { t: "camera", on: !/off|close/.test(t) };
  }
  if (/remember me|learn my face|who am i|know me|this is me|recogni[sz]e me/.test(t)) return { t: "remember" };
  if (/forget (me|my face|everyone|faces)/.test(t)) return { t: "forget" };

  if (/(mute|silence) (yourself|your (sounds?|chirps?|beeps?)|the (sounds?|chirps?))|stop (beeping|chirping)/.test(t)) return { t: "mute", on: true };
  if (/unmute|(turn|bring) (your )?(sounds?|chirps?) (back )?on/.test(t)) return { t: "mute", on: false };
  if ((m = t.match(/\b(?:turn|change|make|go|switch|be)\b.*\b(red|blue|green|purple|pink|orange|yellow|white|cyan|teal)\b/)) || (m = t.match(/\b(red|blue|green|purple|pink|orange|yellow|white|cyan|teal) (eyes|mode|color|colour)\b/))) {
    return { t: "color", name: m[1], rgb: COLORS[m[1]] };
  }
  if (/(normal|default|original|reset) (color|colour|eyes)|back to (normal|cyan)/.test(t)) return { t: "color", name: "normal", rgb: null };

  // music
  if (/^(stop|pause|quiet|silence|shut up|be quiet|enough|stop (the )?(music|song|dancing|dance|it)|stop playing|that'?s enough|turn (it|the music) off|ok stop|thanks stop)$/.test(t)) {
    return /^pause/.test(t) ? { t: "pause" } : { t: "stop" };
  }
  if (/^(pause( the)?( music| song)?)$/.test(t)) return { t: "pause" };
  if (/^(resume|continue|unpause|keep (playing|going)|play( the music| it)?( again)?)$/.test(t)) return { t: "resume" };
  if (/^(next|skip|next song|skip (it|song|this song)|another( one)?|play next)$/.test(t)) return { t: "next" };
  if (/^(previous|previous song|go back|last song|back)$/.test(t)) return { t: "prev" };
  if (/(volume up|louder|turn (it|the (music|volume)) up|crank it)/.test(t)) return { t: "vol", dir: 1 };
  if (/(volume down|quieter|softer|turn (it|the (music|volume)) down|lower the volume)/.test(t)) return { t: "vol", dir: -1 };
  if (/^(music|some music|dance music|dj|let'?s dance|dance for me|dance|boogie|put on some music|play (some )?music|sing( a song)?|sing for me|play something|play a song)$/.test(t)) {
    return /^(sing|play)/.test(t) || /music|dj/.test(t) ? { t: "music-own" } : act("dance");
  }
  if ((m = t.match(/^(?:play|put on|sing|queue( up)?|search( for)?|find|listen to|i want to hear|i wanna hear)\s+(.+)$/))) {
    const q = m[m.length - 1].replace(/^(the song|a song|the track|some)\s+/, "").replace(/\s+(on|from) (youtube|youtube music|spotify)$/, "").trim();
    if (q && q.length > 1 && !/^(dead|music|something)$/.test(q)) return { t: "play", q };
  }

  // questions about EMO
  if (/who are you|your name|introduce yourself|what are you/.test(t)) return { t: "ask", id: "name" };
  if (/how old are you|your age|when were you (born|made)/.test(t)) return { t: "ask", id: "age" };
  if (/what can you do|what do you do|\bhelp\b|your (skills|abilities)/.test(t)) return { t: "ask", id: "help" };

  // moods / expressions
  const E: [RegExp, string][] = [
    [/wake up|get up|good morning|rise and shine/, "wake"],
    [/go to sleep|\bsleep\b|good ?night|\bnap\b|bedtime|time for bed/, "sleep"],
    [/stretch/, "stretch"],
    [/roll your eyes|eye ?roll|\bwhatever\b/, "eyeroll"],
    [/whistle/, "whistle"],
    [/\b(hello|hi|hey|hiya|howdy|what'?s up|sup)\b/, "hello"],
    [/dance|boogie|groove|disco|party time/, "dance"],
    [/laugh|funny|\blol\b|haha/, "laugh"],
    [/i love you|\blove\b|heart|good (boy|robot|job|emo)|cute|adorable|\bbest\b|\bhug\b|cuddle/, "love"],
    [/\bhappy|smile|cheer up|good mood|\bjoy\b/, "happy"],
    [/\bsad|frown|unhappy|upset/, "sad"],
    [/\bcry\b|weep|tears/, "cry"],
    [/annoy|irritat|\bugh\b|so annoying/, "annoyed"],
    [/angry|\bmad\b|grr|furious|rage|get mad/, "angry"],
    [/i'?m (so |really )?cold|it'?s (so |really )?cold|freezing|\bbrr+\b|shiver|are you cold/, "cold"],
    [/i'?m (so |really )?hot|it'?s (so |really )?hot|boiling|sweating|are you hot|too hot/, "hot"],
    [/scare|scary|\bboo\b|afraid|ghost|spooky|monster|frightened/, "scared"],
    [/nervous|anxious|jitters/, "nervous"],
    [/surprise|\bwow\b|no way|\breally\b|\bomg\b/, "surprised"],
    [/\bwink\b|hey there handsome/, "wink"],
    [/\bkiss|mwah|smooch/, "kiss"],
    [/tongue|silly|blep|goofy|raspberry/, "silly"],
    [/mischief|naughty|\bevil\b|plotting|smirk|sneaky|villain/, "mischief"],
    [/puppy|pretty please|\bbeg\b|puppy eyes/, "pleading"],
    [/dream|daydream|romantic|swoon/, "dreamy"],
    [/gross|disgust|yuck|\bew+\b|nasty/, "disgusted"],
    [/\bcool\b|sunglasses|shades|swag|chill/, "cool"],
    [/\bshy\b|blush|compliment|\bthank|you'?re (great|awesome|amazing)/, "shy"],
    [/confus|puzzled|don'?t understand|\bhuh\b/, "confused"],
    [/\bthink|\bhmm+\b|ponder|wonder/, "think"],
    [/curious|what'?s that|interesting/, "curious"],
    [/bored|boring|nothing to do/, "bored"],
    [/suspicious|\bsus\b|doubt|sceptical|skeptical/, "suspicious"],
    [/sneeze|\bsick\b|achoo|\bill\b|\bflu\b/, "sick"],
    [/dizzy|spin|spinning|drunk|round and round/, "dizzy"],
    [/yawn|tired|sleepy|exhausted/, "yawn"],
    [/glitch|malfunction|\bbug\b|\berror\b|crash|hack/, "glitch"],
    [/excited|\byay\b|celebrate|hooray|\bwoo+\b|awesome|amazing|let'?s go|fantastic/, "excited"],
    [/proud|\bflex\b|show off|\bboss\b/, "proud"],
    [/how are you|how do you feel|feeling|\bmood\b/, "mood"],
  ];
  for (const [re, id] of E) if (re.test(t)) return act(id);
  return { t: "unknown" };
}
