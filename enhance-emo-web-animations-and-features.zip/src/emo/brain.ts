import { EmoEngine } from "./engine";
import * as snd from "./sound";
import type { FaceInfo } from "./vision";
import type { Cmd } from "./commands";
import { describeWeather, type WeatherInfo, type WeatherTopic } from "./weather";

const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const pick = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)];
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const CANCEL = Symbol("cancel");

function fmtDur(secs: number) {
  const h = Math.floor(secs / 3600), m = Math.floor((secs % 3600) / 60), s = secs % 60;
  const p = (n: number, u: string) => `${n} ${u}${n === 1 ? "" : "s"}`;
  const parts = [h && p(h, "hour"), m && p(m, "minute"), s && p(s, "second")].filter(Boolean);
  return parts.length ? parts.join(" ") : "0 seconds";
}


type W = (ms: number) => Promise<void>;
type ActionFn = (w: W, alive: () => boolean) => Promise<void>;

export interface Hooks {
  search?: (q: string, autoplay: boolean) => Promise<number>;
  stopMusic?: () => void;
  pauseMusic?: () => void;
  resumeMusic?: () => void;
  nextTrack?: () => void;
  prevTrack?: () => void;
  volume?: (dir: 1 | -1) => void;
  pick?: (n: number) => void;
  camera?: (on: boolean) => void;
  remember?: () => Promise<boolean>;
  forget?: () => void;
  hasResults?: () => boolean;
  getWeather?: (place?: string) => Promise<WeatherInfo | { error: string }>;
  showWeather?: (info: WeatherInfo | null, text?: string) => void;
  say?: (text: string, speak?: boolean) => void;
  units?: () => "f" | "c";
  setMute?: (on: boolean) => void;
}

const JOKES: [string, string][] = [
  ["Why did the robot go on vacation?", "It needed to recharge its batteries!"],
  ["What do you call a robot who loves to dance?", "A boogie-bot!"],
  ["Why was the computer cold?", "It left its Windows open."],
  ["Why don't robots ever panic?", "They have nerves of steel."],
  ["What's a robot's favorite snack?", "Microchips!"],
  ["Why did the smartphone go to therapy?", "It lost its connection."],
  ["How does a robot eat guacamole?", "With computer chips!"],
  ["Why was the robot so tired?", "It had a hard drive."],
  ["What did the router say to the modem?", "You complete my network."],
  ["Why do pixels never get lost?", "They always know their coordinates."],
];

const WEATHER_TINT: Record<string, [number, number, number]> = {
  sun: [255, 214, 90], rain: [140, 200, 255], storm: [196, 172, 255], snow: [190, 230, 255], fog: [205, 214, 228], night: [200, 215, 255],
};

const DJ_COLORS: [number, number, number][] = [
  [62, 244, 255], [255, 92, 220], [140, 255, 120], [255, 210, 80], [170, 140, 255], [255, 120, 90],
];

interface DjMode { id: string; expr: string; sing: boolean; tilt: number; scratch?: boolean; nod?: boolean; confetti?: boolean; bang?: boolean }
const DJ_MODES: DjMode[] = [
  { id: "bounce", expr: "sing", sing: true, tilt: 7 },
  { id: "eq", expr: "eq", sing: false, tilt: 4 },
  { id: "love", expr: "love", sing: true, tilt: 6 },
  { id: "vinyl", expr: "vinyl", sing: false, tilt: 3, scratch: true },
  { id: "cool", expr: "cool", sing: true, tilt: 5, nod: true },
  { id: "star", expr: "excited", sing: true, tilt: 9, confetti: true },
  { id: "bang", expr: "laugh", sing: true, tilt: 15, bang: true },
];

export class Brain {
  hooks: Hooks = {};
  token = 0;
  busy = false;
  cur = "";
  sleeping = false;
  musicOn = false;
  djSrc: "yt" | "own" | "" = "";
  djModeIdx = 0;
  djColorIdx = 0;
  mood = 0.3;
  lastInteract = performance.now();
  listenUntil = 0;
  ambientInfo: WeatherInfo | null = null;
  private nextIdle = performance.now() + 4000;
  private lastZzz = 0;
  private ownTimeout: number | null = null;
  private timer: { end: number; total: number; label?: string } | null = null;
  private stopwatch: { start: number; running: boolean; elapsed: number } | null = null;
  private petting = false;
  private dragging = false;
  private dragVec = { x: 0, y: 0 };
  private shook = false;
  private released = false;
  private taps: number[] = [];
  private vis = { present: false, lastSeen: 0, since: 0, greeted: true, away: 0, hold: {} as Record<string, number>, lastMimic: 0, lastClose: 0, everSeen: false };
  private perkAt = 0;
  private tickId = 0;
  private wReq: { topic: WeatherTopic; place?: string } = { topic: "general" };
  private diceN = 1;
  private numReq = { min: 1, max: 10, text: "", label: "" };
  private rpsReq: string | undefined;
  private jokeIdx = 0;
  onTimerChange?: (t: { remaining: number; total: number; label?: string } | null) => void;
  actions: Record<string, ActionFn> = {};

  constructor(public e: EmoEngine) {
    e.onBeat = (n) => this.onBeat(n);
    e.onLightning = (s) => this.onLightning(s);
    this.defineActions();
    e.setExpr("neutral");
  }

  start() {
    this.tickId = window.setInterval(() => this.tick(), 200);
  }
  destroy() { clearInterval(this.tickId); }

  /* ---------- core runner ---------- */
  run(name: string, fn: ActionFn) {
    const my = ++this.token;
    const e = this.e;
    if (this.cur === "weather" && name !== "weather") { e.sceneFull(false); this.restoreAmbient(); }
    e.resetFx();
    e.autoGaze = true;
    if (name !== "alarm") snd.stopAlarm();
    if (name !== "sleep") this.sleeping = false;
    this.busy = true;
    this.cur = name;
    const w: W = (ms) => new Promise((res, rej) => setTimeout(() => (this.token === my ? res() : rej(CANCEL)), ms));
    fn(w, () => this.token === my)
      .catch((err) => { if (err !== CANCEL) console.error(err); })
      .finally(() => {
        if (this.token === my) { this.busy = false; this.cur = ""; this.after(); }
      });
  }

  private after() {
    const e = this.e;
    e.resetFx();
    e.autoGaze = true;
    e.tweak({ bright: 1 });
    if (this.sleeping) { e.setExpr("sleep"); e.look(0, 0.3); return; }
    if (this.musicOn) { this.applyDjMode(); return; }
    e.setExpr("neutral");
    this.nextIdle = performance.now() + rnd(4000, 9000);
  }

  act(id: string) {
    this.lastInteract = performance.now();
    const f = this.actions[id];
    if (f) this.run(id, f);
  }

  private x(name: string, extra?: any) { this.e.setExpr(name, extra); }
  private say(text: string, speak = true) { this.hooks.say?.(text, speak); }
  private units() { return this.hooks.units?.() ?? "f"; }

  /** step-by-step animation helper: calls fn(k) with k going 0→1 over `ms` */
  private async tween(w: W, ms: number, fn: (k: number) => void) {
    const steps = Math.max(1, Math.round(ms / 50));
    for (let i = 1; i <= steps; i++) { fn(i / steps); await w(50); }
  }

  /* ---------- particle helpers ---------- */
  private hearts(n: number, spread = 1) {
    for (let i = 0; i < n; i++)
      this.e.emit("heart", 1, { x: rnd(260, 540) * spread + 400 * (1 - spread), y: rnd(420, 540), vx: rnd(-25, 25), vy: rnd(-150, -90), max: 1.9, size: rnd(0.7, 1.4), rot: rnd(0, 6) });
  }
  private sparks(n: number) {
    for (let i = 0; i < n; i++)
      this.e.emit("spark", 1, { x: rnd(130, 670), y: rnd(120, 560), vy: rnd(-40, 0), max: rnd(0.7, 1.3), size: rnd(0.8, 1.6), vr: rnd(-3, 3) });
  }
  private stars(n: number) {
    for (let i = 0; i < n; i++)
      this.e.emit("star", 1, { x: rnd(150, 650), y: rnd(150, 520), vy: rnd(-50, -15), max: rnd(1.2, 2), size: rnd(0.7, 1.3), vr: rnd(-2, 2) });
  }
  private tears() {
    for (const x of [250, 550]) this.e.emit("tear", 1, { x: x + rnd(-24, 24), y: 470, vy: 30, g: 520, max: 1.4, size: rnd(0.8, 1.2) });
  }
  private sweat(n = 1) {
    for (let i = 0; i < n; i++) this.e.emit("drop", 1, { type: "sweat", x: pick([180, 620]) + rnd(-20, 20), y: 260 + rnd(0, 40), vy: 20, g: 420, max: 1.3, size: rnd(0.9, 1.3) });
  }
  private notes(n = 1) {
    for (let i = 0; i < n; i++)
      this.e.emit("note", 1, { text: pick(["♪", "♫", "♬"]), x: pick([rnd(40, 150), rnd(650, 760)]), y: rnd(400, 600), vx: rnd(-20, 20), vy: rnd(-130, -80), max: 2.2, size: rnd(0.8, 1.3), rot: rnd(0, 3), hue: pick([180, 300, 100, 45, 260]) });
  }
  private confetti(n: number) {
    for (let i = 0; i < n; i++)
      this.e.emit("confetti", 1, { x: rnd(60, 740), y: rnd(-40, 40), vx: rnd(-50, 50), vy: rnd(60, 190), g: 30, max: rnd(2.5, 4), size: rnd(0.8, 1.6), vr: rnd(-9, 9), hue: rnd(0, 360) });
  }
  private puff() {
    this.e.emit("puff", 1, { x: 400 + rnd(-30, 30), y: 650, vx: rnd(-14, 14), vy: rnd(-55, -30), max: 1.2, size: rnd(0.8, 1.2) });
  }
  private tiltWiggle(amt: number, n: number, ms: number, w: W) {
    return (async () => {
      for (let i = 0; i < n; i++) { this.e.head.tilt.t = (i % 2 ? -1 : 1) * amt; this.e.bump(-180); await w(ms); }
      this.e.head.tilt.t = 0;
    })();
  }

  /** The yawn: a slow inhale (eyes scrunch, mouth stretches into a tall oval, head leans back),
   *  a held peak with a little tear, then a long sleepy exhale. */
  private async yawnSeq(w: W, short = false) {
    const e = this.e;
    const k = short ? 0.7 : 1;
    e.autoGaze = false;
    e.look(0, -0.15);
    this.x("sleepy");
    snd.yawn();
    await w(250 * k);
    // 1. inhale
    e.head.rotX.t = -9; e.head.y.t = -12; e.head.sy.t = 1.025;
    await this.tween(w, 1250 * k, (p) => {
      const q = p * p * (3 - 2 * p);
      e.tweak({ topLid: 0.42 + 0.22 * q, h: 165 - 40 * q, w: 150 + 8 * q, y: 22 + 6 * q, slant: -0.2, mouth: 1, open: 0.05 + 1.7 * q, smile: -0.1 * q, mw: 80 - 28 * q, blush: 0 });
      e.head.tilt.t = -2 * q;
    });
    // 2. peak: eyes squeezed shut, mouth wide
    this.x("yawnPeak");
    e.fx.tremble = 0.7;
    e.head.rotX.t = -13; e.head.y.t = -18;
    for (let i = 0; i < Math.round(3 * k); i++) { await w(330); if (i === 1) e.emit("tear", 1, { x: 535, y: 440, vx: 6, vy: 10, g: 150, max: 1.5, size: 0.8 }); }
    e.fx.tremble = 0;
    // 3. exhale
    this.x("yawnPeak");
    await this.tween(w, 1300 * k, (p) => {
      const q = p * p * (3 - 2 * p);
      e.tweak({ mouth: 1, open: 1.75 - 1.65 * q, mw: 52 + 26 * q, smile: -0.15 * (1 - q) - 0.1 * q });
      if (p > 0.15) e.setExpr("sleepy", { mouth: 1, open: 1.6 * (1 - q) + 0.02, mw: 52 + 26 * q, smile: -0.1 });
    });
    e.head.rotX.t = 4; e.head.y.t = 12; e.head.sy.t = 1; e.head.tilt.t = -4;
    this.x("sleepy");
    snd.chirp("sigh");
    await w(700 * k);
    e.head.rotX.t = 0; e.head.y.t = 6; e.head.tilt.t = 0;
  }

  /* ---------- actions ---------- */
  private defineActions() {
    const e = this.e;
    const A = this.actions;
    const x = this.x.bind(this);

    A.hello = async (w) => {
      x("happy"); snd.chirp("hello"); e.look(0, 0); this.sparks(4);
      await this.tiltWiggle(9, 4, 260, w); await w(700); this.mood = clamp(this.mood + 0.1, -1, 1);
    };
    A.happy = async (w) => { x("happy"); snd.chirp("happy"); this.sparks(5); e.bump(-400); await this.tiltWiggle(6, 4, 300, w); await w(900); this.mood = clamp(this.mood + 0.1, -1, 1); };
    A.laugh = async (w) => {
      x("laugh"); snd.chirp("laugh"); e.fx.tremble = 1.5;
      for (let i = 0; i < 9; i++) { e.head.tilt.t = i % 2 ? -5 : 5; e.bump(-260); e.tweak({ open: i % 2 ? 0.6 : 1 }); await w(210); }
      e.fx.tremble = 0; x("happy"); await w(600); this.mood = clamp(this.mood + 0.15, -1, 1);
    };
    A.love = async (w) => {
      x("love"); snd.chirp("love");
      for (let i = 0; i < 9; i++) { this.hearts(2); e.pulse(1); e.head.sx.v += 2; e.head.sy.v += 2; await w(380); }
      await w(500); this.mood = clamp(this.mood + 0.2, -1, 1);
    };
    A.excited = async (w) => {
      x("excited"); snd.chirp("happy"); this.confetti(30); this.sparks(8);
      for (let i = 0; i < 8; i++) { e.head.tilt.t = i % 2 ? -10 : 10; e.bump(-420); if (i % 3 === 0) this.sparks(3); await w(280); }
      await w(400);
    };
    A.wink = async (w) => { x("neutral"); await w(300); x("wink"); snd.chirp("wink"); this.sparks(4); e.head.tilt.t = 6; e.bump(-250); await w(1100); };
    A.kiss = async (w) => { x("kiss"); snd.chirp("kiss"); await w(300); for (let i = 0; i < 4; i++) { this.hearts(2); await w(250); } await w(900); };
    A.silly = async (w) => { x("silly"); snd.chirp("laugh"); await this.tiltWiggle(8, 6, 300, w); await w(400); };
    A.cool = async (w) => { x("cool"); snd.chirp("proud"); e.look(0, 0); this.sparks(3); e.head.rotX.t = 8; await w(500); e.head.rotX.t = -4; await w(2200); };
    A.proud = async (w) => { x("proud"); snd.chirp("proud"); e.head.y.t = -12; this.sparks(5); await w(2300); };
    A.shy = async (w) => { x("shy"); snd.chirp("pet"); e.look(-0.9, 0.5); e.head.tilt.t = -6; this.hearts(2); await w(1200); e.look(0.9, 0.6); await w(1200); };
    A.curious = async (w) => {
      x("curious"); snd.chirp("curious"); e.autoGaze = false; e.look(0.8, -0.2); e.head.tilt.t = 10;
      e.emit("question", 1, { text: "?", x: 650, y: 190, vy: -20, max: 2, size: 1 }); await w(1000);
      e.look(-0.8, -0.1); e.head.tilt.t = -10; await w(1000);
    };
    A.huh = async (w) => {
      x("confused"); snd.chirp("curious"); e.look(0, -0.2); e.head.tilt.t = 12;
      e.emit("question", 1, { text: "?", x: 640, y: 180, vy: -20, max: 1.8, size: 1.1 }); await w(1500);
    };
    A.think = async (w) => {
      x("thinking"); e.autoGaze = false; e.look(-0.8, -0.7); snd.chirp("hmm"); await w(500); x("dots"); await w(1800);
      x("surprised"); snd.chirp("surprised"); e.emit("bang", 1, { text: "!", x: 640, y: 200, vy: -20, max: 1.2 }); await w(1100);
    };
    A.suspicious = async (w) => {
      x("suspicious"); e.autoGaze = false; e.look(0.9, 0); await w(800); e.look(-0.9, 0); await w(800); e.look(0, 0.05); snd.chirp("curious"); await w(1000);
    };
    A.bored = async (w) => {
      x("bored"); snd.chirp("sleepy"); e.autoGaze = false; e.look(-0.7, -0.3); await w(1300); e.look(0.7, 0.2); await w(1300); x("sleepy"); await w(1000);
      this.mood = clamp(this.mood - 0.05, -1, 1);
    };
    A.eyeroll = async (w) => {
      x("bored"); e.autoGaze = false; snd.chirp("hmm");
      for (let r = 0; r < 2; r++)
        for (let i = 0; i < 10; i++) { const a = (i / 10) * Math.PI * 2 - Math.PI / 2; e.look(Math.cos(a) * 0.95, Math.sin(a) * 0.8); await w(70); }
      e.look(0, 0.1); e.head.tilt.t = -4; snd.chirp("sigh"); await w(900);
    };
    A.surprised = async (w) => {
      x("surprised"); snd.chirp("surprised"); e.fx.tremble = 2; e.emit("bang", 1, { text: "!", x: 640, y: 190, vy: -30, max: 1.4 }); e.bump(-650);
      await w(300); e.fx.tremble = 0; await w(1500);
    };
    A.scared = async (w) => {
      x("scared"); snd.chirp("scared"); e.fx.tremble = 5; e.look(0, 0.1);
      for (let i = 0; i < 6; i++) { this.sweat(1); e.look(rnd(-0.7, 0.7), rnd(-0.2, 0.3)); await w(450); }
    };
    A.nervous = async (w) => {
      x("nervous"); snd.chirp("shiver"); e.autoGaze = false; e.fx.tremble = 1.4;
      for (let i = 0; i < 10; i++) {
        e.look(rnd(-0.8, 0.8), rnd(-0.3, 0.3)); e.tweak({ smile: -0.2 + Math.sin(i * 1.7) * 0.25 });
        if (i % 3 === 0) this.sweat(1);
        await w(380);
      }
    };
    A.sad = async (w) => { x("sad"); snd.chirp("sad"); e.look(0, 0.7); e.head.y.t = 14; e.head.tilt.t = -3; await w(3200); this.mood = clamp(this.mood - 0.05, -1, 1); };
    A.cry = async (w) => {
      x("cry"); snd.chirp("cry"); e.look(0, 0.5); e.fx.tremble = 1; e.head.y.t = 12;
      for (let i = 0; i < 11; i++) { this.tears(); await w(380); }
      x("sad"); await w(600);
    };
    A.angry = async (w) => {
      x("angry"); snd.chirp("angry"); e.emit("anger", 1, { x: 640, y: 170, vy: -10, max: 2.6, size: 1.3 });
      e.fx.tremble = 3;
      for (let i = 0; i < 6; i++) { e.head.x.t = i % 2 ? -8 : 8; e.bump(-120); await w(300); }
      e.head.x.t = 0; await w(700);
    };
    A.annoyed = async (w) => {
      x("annoyed"); snd.chirp("nope"); e.autoGaze = false; e.look(-0.6, 0.1); e.head.tilt.t = -5;
      await w(900); e.look(0.2, -0.1); await w(700); snd.chirp("sigh"); e.look(0.9, 0.2); await w(1000);
    };
    A.disgusted = async (w) => {
      x("disgusted"); snd.chirp("nope"); e.autoGaze = false; e.look(-0.8, 0.2);
      e.head.rotY.t = 16; e.head.tilt.t = -6; e.head.x.t = -10; await w(300);
      e.fx.tremble = 0.8; await w(1900);
    };
    A.cold = async (w) => {
      x("cold"); snd.chirp("shiver"); e.fx.tremble = 1.8; e.look(0, 0.2); e.head.y.t = 8;
      for (let i = 0; i < 9; i++) {
        e.head.x.t = i % 2 ? -4 : 4; e.tweak({ open: 0.1 + (i % 2) * 0.12 });
        if (i % 3 === 1) { this.puff(); snd.chirp("shiver"); }
        await w(330);
      }
      e.head.x.t = 0; x("content"); await w(500);
    };
    A.hot = async (w) => {
      x("hot"); snd.chirp("pant"); e.look(0, 0.2); e.head.y.t = 6;
      for (let i = 0; i < 9; i++) {
        e.tweak({ open: i % 2 ? 0.45 : 0.95, mw: i % 2 ? 56 : 66 }); this.sweat(1);
        if (i % 3 === 0) snd.chirp("pant");
        await w(380);
      }
      x("relief"); snd.chirp("sigh"); await w(700);
    };
    A.mischief = async (w) => {
      x("mischief"); snd.chirp("evil"); e.autoGaze = false; e.look(0.8, 0); e.head.tilt.t = 6; await w(900);
      e.look(-0.8, 0); await w(700); e.look(0, 0.05); x("evil"); e.fx.tremble = 1; snd.chirp("evil");
      for (let i = 0; i < 6; i++) { e.tweak({ open: i % 2 ? 0.5 : 0.9 }); e.bump(-120); await w(220); }
      e.fx.tremble = 0; x("mischief"); await w(700);
    };
    A.pleading = async (w) => {
      x("pleading"); snd.chirp("sparkle"); e.look(0, 0.1); e.head.tilt.t = 8; this.sparks(3);
      for (let i = 0; i < 8; i++) { e.tweak({ smile: -0.5 + Math.sin(i) * 0.15, mw: 30 + (i % 2) * 6 }); if (i % 3 === 0) this.stars(1); await w(380); }
    };
    A.confused = async (w) => {
      x("confused"); snd.chirp("curious"); e.autoGaze = false;
      for (let i = 0; i < 4; i++) {
        e.look(i % 2 ? -0.8 : 0.8, -0.2); e.head.tilt.t = i % 2 ? 9 : -9;
        e.emit("question", 1, { text: "?", x: i % 2 ? 160 : 640, y: 190, vy: -22, max: 1.8, size: rnd(0.8, 1.1) });
        await w(700);
      }
    };
    A.dreamy = async (w) => {
      x("dreamy"); snd.chirp("sparkle"); e.autoGaze = false; e.look(0.4, -0.5);
      for (let i = 0; i < 7; i++) { e.head.tilt.t = i % 2 ? -5 : 5; if (i % 2) this.hearts(1); this.stars(1); await w(500); }
    };
    A.whistle = async (w) => {
      x("whistle"); snd.chirp("whistle"); e.autoGaze = false; e.look(0.4, -0.2);
      for (let i = 0; i < 6; i++) { e.head.tilt.t = i % 2 ? -4 : 4; e.bump(-90); if (i % 2 === 0) this.notes(1); await w(380); }
    };
    A.dizzy = async (w) => {
      x("dizzy"); snd.chirp("dizzy"); e.look(0, 0);
      for (let i = 0; i < 9; i++) { e.head.tilt.t = i % 2 ? -14 : 14; e.head.x.t = i % 2 ? -14 : 14; await w(260); }
      e.head.x.t = 0; e.head.tilt.t = 0; x("sick"); await w(1000);
    };
    A.dead = async (w) => { x("dead"); snd.chirp("sad"); e.head.tilt.t = -9; e.head.y.t = 20; await w(2400); x("surprised"); snd.chirp("surprised"); e.bump(-500); await w(900); };
    A.yawn = async (w) => { await this.yawnSeq(w); await w(400); };
    A.stretch = async (w) => {
      x("squint"); snd.chirp("happy"); e.head.y.t = -22; e.head.sy.t = 1.1; e.head.sx.t = 0.96; e.head.rotX.t = -8;
      await w(900); e.tweak({ mouth: 1, open: 0.5, mw: 50, smile: 0.2 });
      for (let i = 0; i < 4; i++) { e.head.tilt.t = i % 2 ? -7 : 7; await w(260); }
      e.head.y.t = 4; e.head.sy.t = 1; e.head.sx.t = 1; e.head.rotX.t = 0; e.head.tilt.t = 0; x("happy"); snd.chirp("hello"); e.bump(-250); await w(800);
    };
    A.sleep = async (w) => {
      await this.yawnSeq(w);
      this.x("sleepy");
      await this.tween(w, 1300, (p) => e.tweak({ topLid: 0.6 + 0.35 * p, h: 150 - 30 * p, bright: 1 - 0.3 * p }));
      x("sleep"); e.look(0, 0.3);
      e.djStop(); e.hp.t = 0; this.musicOn = false; snd.stopBeat();
      this.clearAmbient();
      this.sleeping = true; e.emit("zzz", 1, { text: "Z", x: 600, y: 270, vx: 25, vy: -35, max: 3, size: 1 });
    };
    A.wake = async (w) => {
      this.sleeping = false; x("sleepy"); await w(500);
      await this.yawnSeq(w, true);
      x("squint"); e.head.y.t = -18; e.head.sy.t = 1.08; await w(500);
      e.head.y.t = 0; e.head.sy.t = 1;
      x("surprised"); e.bump(-400); snd.chirp("wake"); await w(500); x("happy"); snd.chirp("hello"); await w(800);
      if (performance.now() < this.listenUntil) await A.heard(w, () => true);
    };
    A.sick = async (w) => {
      x("sick"); await w(800); x("sneeze"); snd.chirp("sneeze"); e.bump(-800); e.head.tilt.t = -10;
      for (let i = 0; i < 5; i++) e.emit("drop", 1, { x: 400 + rnd(-60, 60), y: 600, vx: rnd(-200, 200), vy: rnd(-100, 60), g: 400, max: 0.9, size: 0.7 });
      await w(1200); e.head.tilt.t = 0; x("sick"); await w(1500);
    };
    A.glitch = async (w) => {
      x("neutral"); e.fx.glitch = 0.9; snd.chirp("glitch");
      for (let i = 0; i < 7; i++) { x(pick(["dizzy", "surprised", "scared", "cool", "angry", "neutral", "love"])); e.fx.glitch = rnd(0.4, 1); e.fx.tremble = 6; await w(170); }
      e.fx.glitch = 0; e.fx.tremble = 0; x("neutral"); await w(400); x("curious"); await w(800);
    };
    A.mood = async (w, alive) => {
      const id = this.mood > 0.45 ? "happy" : this.mood < -0.25 ? "sad" : "content";
      this.say(this.mood > 0.45 ? "I'm feeling great!" : this.mood < -0.25 ? "I'm a little down today." : "I'm doing pretty good, thanks!");
      if (id === "content") { x("content"); snd.chirp("pet"); await w(2200); }
      else { const f = A[id]; await f(w, alive); }
    };
    A.birthday = async (w) => {
      x("excited"); snd.chirp("happy"); this.confetti(40); await w(600);
      x("sing"); e.fx.sing = true;
      const dur = snd.playMelody(snd.HAPPY_BIRTHDAY, 112);
      const end = performance.now() + (dur || 12) * 1000;
      let i = 0;
      while (performance.now() < end) {
        e.head.tilt.t = i % 2 ? -7 : 7; e.bump(-160); if (i % 3 === 0) { this.confetti(10); this.notes(1); } i++;
        await w(420);
      }
      e.fx.sing = false; this.confetti(40); x("love"); await this.tiltWiggle(8, 4, 300, w); this.hearts(6);
      await w(900);
    };
    A.dance = async (w) => {
      this.startDj("own", 122);
      snd.startBeat(122);
      if (this.ownTimeout) clearTimeout(this.ownTimeout);
      this.ownTimeout = window.setTimeout(() => this.stopDj(), 24000);
      await w(10);
    };
    A.musicOwn = async (w) => {
      this.startDj("own", 118);
      snd.startBeat(118);
      if (this.ownTimeout) clearTimeout(this.ownTimeout);
      this.ownTimeout = window.setTimeout(() => this.stopDj(), 90000);
      await w(10);
    };
    A.poke = async (w) => {
      x("squint"); snd.chirp("poke"); e.bump(-350); e.head.tilt.t = pick([-7, 7]); await w(400);
      x(pick(["laugh", "wink", "surprised", "happy"])); snd.chirp("laugh"); await w(1300);
    };
    A.handsup = async (w) => {
      this.released = false;
      x("terrified"); e.autoGaze = false; e.look(0, -0.15); snd.chirp("scared");
      e.emit("bang", 1, { text: "!", x: 400, y: 170, vy: -25, max: 1.4, size: 1.1 });
      e.hands.t = 1; e.fx.tremble = 2; e.head.y.v -= 520; e.head.sy.v -= 4; e.head.sx.v += 2.5;
      for (let i = 0; i < 24 && !this.released; i++) {
        if (i % 3 === 1) this.sweat(1);
        if (i % 6 === 3) { snd.chirp("scared"); e.look(rnd(-0.5, 0.5), rnd(-0.35, 0.15)); }
        await w(450);
      }
      e.fx.tremble = 0; e.hands.t = 0; await w(450);
      x("relief"); snd.chirp("phew"); this.sweat(2); await w(1500);
      x("happy"); await w(900);
    };
    A.shoot = async (w, alive) => { await this.dodgeSeq(Math.random() < 0.2, w, alive); };
    A.dodge = async (w, alive) => { await this.dodgeSeq(false, w, alive); };

    /* --- helper apps --- */
    A.clock = async (w) => {
      const now = new Date();
      const t = now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
      e.display("clock"); snd.chirp("ding"); e.autoGaze = false;
      this.say(`It's ${t}.`);
      await w(5500);
    };
    A.date = async (w) => {
      const now = new Date();
      e.display("date"); snd.chirp("ding"); e.autoGaze = false;
      this.say(`Today is ${now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })}.`);
      await w(5500);
    };
    A.timerShow = async (w) => {
      if (!this.timer) { x("curious"); this.say("There's no timer running."); await w(1500); return; }
      const left = Math.max(0, Math.ceil((this.timer.end - Date.now()) / 1000));
      e.display("timer", { ...this.timer });
      this.say(`${fmtDur(left)} left.`);
      await w(4500);
    };
    A.timerSet = async (w) => {
      const t = this.timer;
      if (!t) return;
      e.display("timer", { ...t }); snd.chirp("happy");
      this.say(`${t.label ? t.label + " set" : "Timer set"} for ${fmtDur(t.total)}.`);
      await w(3000); x("happy"); await w(700);
    };
    A.alarm = async (w) => {
      const label = this.lastTimerLabel;
      snd.alarm(30); this.say(label ? `${label} is going off!` : "Time's up!", true);
      e.display("number", { text: "TIME!", label: label || "timer done" }); e.autoGaze = false;
      for (let i = 0; i < 6; i++) { e.head.y.v -= 180; await w(500); }
      e.display("none");
      x("excited"); e.fx.tremble = 1.5;
      for (let i = 0; i < 24; i++) { e.head.tilt.t = i % 2 ? -9 : 9; e.bump(-300); if (i % 4 === 0) this.sparks(5); await w(450); }
    };
    A.dice = async (w) => {
      e.autoGaze = false; snd.chirp("curious");
      const n = this.diceN;
      const d: any = { values: Array(n).fill(1), rot: 0 };
      e.display("dice", d);
      await w(380); // let the face fade out before the dice start tumbling
      const final = Array.from({ length: n }, () => 1 + Math.floor(Math.random() * 6));
      for (let i = 0; i < 14; i++) {
        d.values = Array.from({ length: n }, () => 1 + Math.floor(Math.random() * 6));
        d.rot = rnd(-0.5, 0.5) * (1 - i / 16); e.head.y.v -= 120; if (i % 3 === 0) snd.chirp("tick");
        await w(70 + i * 18);
      }
      d.values = final; d.rot = 0;
      const sum = final.reduce((a, b) => a + b, 0);
      if (n > 1) d.label = `TOTAL ${sum}`;
      snd.chirp("ding");
      this.say(n > 1 ? `You rolled ${final.join(" and ")}. That's ${sum}.` : `You rolled a ${final[0]}.`);
      await w(2800);
    };
    A.coin = async (w) => {
      e.autoGaze = false; snd.chirp("whoosh");
      const d: any = { angle: 0, face: "H" }; e.display("coin", d);
      await w(380);
      const res = Math.random() < 0.5 ? "H" : "T";
      const steps = 30;
      for (let i = 0; i <= steps; i++) { d.angle = (i / steps) * Math.PI * 7 + (res === "T" ? 0 : Math.PI); d.face = Math.cos(d.angle) >= 0 ? "H" : "T"; await w(45); }
      d.angle = 0; d.face = res; d.label = res === "H" ? "HEADS" : "TAILS"; e.head.y.v -= 200; snd.chirp("ding");
      this.say(res === "H" ? "It's heads!" : "It's tails!");
      await w(2600);
    };
    A.number = async (w) => {
      const { min, max } = this.numReq;
      const v = min + Math.floor(Math.random() * (max - min + 1));
      e.autoGaze = false; snd.chirp("curious");
      const d: any = { text: "?", label: `Between ${min} and ${max}` };
      e.display("number", d);
      await w(400);
      for (let i = 0; i < 10; i++) { d.text = String(min + Math.floor(Math.random() * (max - min + 1))); snd.chirp("tick"); await w(60 + i * 20); }
      d.text = String(v); snd.chirp("ding"); e.head.y.v -= 160;
      this.say(`${v}.`);
      await w(3000);
    };
    A.calc = async (w) => {
      e.autoGaze = false; snd.chirp("hmm");
      x("thinking"); e.look(-0.6, -0.6); await w(700);
      const txt = this.numReq.text;
      e.display("number", { text: txt, label: this.numReq.label });
      snd.chirp("ding");
      this.say(`${this.numReq.label.replace(/ x /g, " times ").replace("÷", "divided by").replace("−", "minus").replace("×", "times")} is ${txt}.`);
      await w(4200);
    };
    A.rps = async (w) => {
      e.autoGaze = false; snd.chirp("curious");
      const opts = ["rock", "paper", "scissors"];
      const me = pick(opts);
      const d: any = { choice: "rock", bounce: 0 };
      e.display("rps", d);
      await w(400);
      for (let i = 0; i < 3; i++) { d.bounce = -50; snd.chirp("tick"); await w(180); d.bounce = 0; await w(260); }
      d.choice = me; d.label = `I pick ${me}`; snd.chirp("ding");
      const you = this.rpsReq;
      let res = "";
      if (you) {
        const beats: Record<string, string> = { rock: "scissors", paper: "rock", scissors: "paper" };
        res = you === me ? "tie" : beats[me] === you ? "win" : "lose";
        d.label = `${me} vs ${you}`;
      }
      this.say(res === "win" ? `I picked ${me}. I win!` : res === "lose" ? `I picked ${me}. You win!` : res === "tie" ? `We both picked ${me}. A tie!` : `I pick ${me}!`);
      await w(2600);
      e.display("none"); await w(450);
      if (res === "win") { x("proud"); snd.chirp("proud"); this.sparks(6); await w(1800); }
      else if (res === "lose") { x("sad"); snd.chirp("sad"); await w(1800); }
      else if (res === "tie") { x("surprised"); snd.chirp("surprised"); await w(1500); }
    };
    A.stopwatch = async (w) => {
      const s = this.stopwatch;
      if (!s) return;
      e.display("stopwatch", s); snd.chirp("ding"); e.autoGaze = false;
      await w(4500);
    };
    A.joke = async (w) => {
      const [setup, punch] = JOKES[this.jokeIdx++ % JOKES.length];
      x("curious"); snd.chirp("curious"); e.look(0, -0.2); this.say(setup);
      await w(Math.max(2600, setup.length * 75));
      x("think"); e.autoGaze = false; await w(700);
      x("laugh"); snd.chirp("laugh"); this.say(punch);
      for (let i = 0; i < 8; i++) { e.head.tilt.t = i % 2 ? -5 : 5; e.bump(-240); e.tweak({ open: i % 2 ? 0.6 : 1 }); await w(260); }
      await w(Math.max(0, punch.length * 60 - 1500));
      this.mood = clamp(this.mood + 0.1, -1, 1);
    };
    A.ask = async (w) => {
      const id = this.askId;
      x("happy"); snd.chirp("hello"); this.sparks(3);
      if (id === "name") this.say("I'm Emo, your little desk buddy!");
      else if (id === "age") this.say("I was switched on just a moment ago, so I'm brand new!");
      else this.say("I can tell the time, weather and temperature, set timers and alarms, roll dice, play music, and show lots of feelings.");
      await w(3200);
    };

    /* --- weather --- */
    A.weather = async (w, alive) => {
      const req = this.wReq;
      x("dots"); e.look(0, -0.4); e.autoGaze = false; snd.chirp("curious");
      const res = await (this.hooks.getWeather?.(req.place) ?? Promise.resolve({ error: "I can't check the weather right now." }));
      if (!alive()) return;
      if ("error" in res) { x("sad"); snd.chirp("sad"); this.say(res.error); await w(2500); return; }
      await this.showWeather(res, req.topic, w);
    };
    A.found = async (w) => { x("happy"); snd.chirp("happy"); e.look(0, 0.8); this.sparks(3); await w(1400); x("curious"); e.look(0, 0.8); e.autoGaze = false; await w(1200); };
    A.notfound = async (w) => { x("sad"); snd.chirp("sad"); await w(2000); };
    A.searching = async (w) => { x("dots"); e.look(0, -0.5); snd.chirp("curious"); await w(30000); };
    A.remembered = async (w) => { x("love"); snd.chirp("love"); this.hearts(10); await w(2500); };
    A.perk = async (w) => { await w(10); };
    A.peekaboo = async (w) => { x("surprised"); snd.chirp("surprised"); e.bump(-500); await w(500); x("laugh"); snd.chirp("laugh"); this.sparks(6); this.hearts(2); await this.tiltWiggle(7, 5, 240, w); };
    A.greetOwner = async (w) => { x("love"); snd.chirp("love"); this.hearts(8); e.head.y.v -= 400; await w(600); x("happy"); await this.tiltWiggle(8, 4, 260, w); await w(500); };
    A.greetStranger = async (w) => {
      x("suspicious"); e.autoGaze = false; e.look(0, 0); snd.chirp("curious"); await w(1500);
      x("curious"); e.head.tilt.t = 9; await w(1100); x("happy"); snd.chirp("hello"); e.head.tilt.t = 0; await w(1100);
    };

    /** "Hey Emo!" — he perks up, one eye lifts ("what?"), leans toward you and listens with sound rings. */
    A.heard = async (w, alive) => {
      if (this.listenUntil < performance.now() + 3000) this.listenUntil = performance.now() + 4000;
      x("listening"); e.autoGaze = false; e.look(0, -0.05); snd.chirp("wake"); e.bump(-300);
      e.head.rotX.t = -5; e.head.tilt.t = 5; e.listen.t = 1;
      await w(350);
      e.head.tilt.t = 3;
      let i = 0;
      while (performance.now() < this.listenUntil && alive()) {
        if (++i % 14 === 0) { e.look(rnd(-0.12, 0.12), rnd(-0.1, 0.05)); }
        await w(120);
      }
      e.listen.t = 0;
    };

    /** carried around: looks where he's being taken; only dizzy if he was actually shaken */
    A.carried = async (w) => {
      this.shook = false;
      x("carried"); snd.chirp("curious"); e.autoGaze = false;
      let dizzy = false;
      while (this.dragging) {
        const v = this.dragVec;
        e.look(clamp(v.x * 1.1, -1, 1), clamp(v.y * 0.9, -0.8, 0.8));
        if (this.shook && !dizzy) { dizzy = true; x("dizzy"); snd.chirp("dizzy"); }
        await w(60);
      }
      e.head.x.t = 0; e.head.y.t = 0; e.head.tilt.t = 0;
      if (dizzy || this.shook) { this.shook = false; await A.dizzy(w, () => true); return; }
      // set back down gently
      e.look(0, 0.1); x("surprised"); e.bump(-220); await w(350);
      x("relief"); snd.chirp("phew"); await w(900);
      if (Math.random() < 0.5) { x("happy"); await w(700); }
    };
    A.pet = async (w, alive) => {
      x("content", { blush: 1 }); snd.chirp("pet"); e.look(0, 0.2);
      while (this.petting && alive()) { this.hearts(1); e.pulse(0.6); await w(520); }
      x("happy", { blush: 0.8 }); snd.chirp("happy"); await w(1100); this.mood = clamp(this.mood + 0.2, -1, 1);
    };
    A.djend = async (w) => { x("proud"); snd.chirp("proud"); this.sparks(4); await w(1400); };
    A.lookAround = async (w) => {
      e.autoGaze = false;
      e.look(-0.9, 0); await w(600); e.look(0.9, 0); await w(700); e.look(0, 0); await w(300);
    };
    A.hum = async (w) => {
      x("content"); snd.chirp("pet");
      for (let i = 0; i < 6; i++) { this.notes(1); e.head.tilt.t = i % 2 ? -5 : 5; await w(500); }
    };
    A.worried = async (w) => { x("worried"); snd.chirp("sad"); e.head.tilt.t = -6; await w(2200); };
    A.colorChange = async (w) => { x("happy"); snd.chirp("sparkle"); this.sparks(6); await w(1400); };
  }

  askId: "name" | "help" | "age" = "name";
  lastTimerLabel = "";

  /* ---------- weather ---------- */
  async showWeather(info: WeatherInfo, topic: WeatherTopic, w: W) {
    const e = this.e;
    const u = this.units();
    const d = describeWeather(info, topic, u);
    this.hooks.showWeather?.(info, d.sentence);
    this.say(d.sentence);
    e.setScene(info.kind, { intensity: info.intensity, day: info.isDay, full: true });
    e.display("weather", { big: d.big, small: d.small, place: info.place });
    e.autoGaze = false;
    snd.chirp("ding");
    await w(7200);
    // the face comes back while the weather keeps playing in the background
    e.display("none");
    e.sceneFull(false);
    await w(700);
    await this.weatherReact(info, w);
    this.restoreAmbient();
    await w(500);
  }

  private async weatherReact(info: WeatherInfo, w: W) {
    const e = this.e;
    const k = info.kind;
    const hot = info.tempC >= 31, cold = info.tempC <= 0;
    e.autoGaze = false;
    if (k === "storm") {
      this.x("scared", { color: WEATHER_TINT.storm }); snd.chirp("scared"); e.fx.tremble = 2.2; e.look(0, -0.5);
      for (let i = 0; i < 10; i++) { this.sweat(1); e.look(rnd(-0.6, 0.6), rnd(-0.5, -0.1)); await w(650); }
    } else if (k === "rain" || k === "drizzle") {
      this.x(info.intensity > 0.8 ? "worried" : "sad", { color: WEATHER_TINT.rain }); snd.chirp("sad"); e.look(0, -0.6); e.head.tilt.t = -3;
      for (let i = 0; i < 6; i++) { e.look(rnd(-0.3, 0.3), -0.6 + rnd(0, 0.2)); await w(1100); if (i === 2) snd.chirp("sigh"); }
    } else if (k === "snow" || k === "sleet" || cold) {
      this.x("cold", { color: WEATHER_TINT.snow }); snd.chirp("shiver"); e.fx.tremble = 1.4; e.look(0, -0.3);
      for (let i = 0; i < 9; i++) { e.head.x.t = i % 2 ? -4 : 4; if (i % 3 === 1) this.puff(); await w(700); }
    } else if (k === "fog") {
      this.x("sleepy", { color: WEATHER_TINT.fog }); e.look(-0.4, 0); snd.chirp("hmm"); await w(2200); e.look(0.4, 0); await w(2200); e.look(0, 0);
      this.x("curious", { color: WEATHER_TINT.fog }); await w(1800);
    } else if (k === "cloudy") {
      this.x("content"); e.look(0, -0.6); await w(2500); e.look(0.5, -0.5); await w(2200); e.look(-0.4, -0.5); await w(2200);
    } else if (k === "clear" && !info.isDay) {
      this.x("content", { color: WEATHER_TINT.night }); e.look(0.5, -0.6); snd.chirp("pet"); await w(3000); this.x("sleepy", { color: WEATHER_TINT.night }); await w(3500);
    } else if (hot) {
      this.x("hot"); snd.chirp("pant"); for (let i = 0; i < 8; i++) { e.tweak({ open: i % 2 ? 0.45 : 0.95 }); this.sweat(1); await w(800); }
    } else {
      // sunny / partly cloudy
      this.x(k === "clear" ? "cool" : "happy", { color: k === "clear" ? undefined : WEATHER_TINT.sun }); snd.chirp("happy"); this.sparks(5); e.look(0, -0.3);
      e.head.rotX.t = 6;
      for (let i = 0; i < 6; i++) { if (i % 2 === 0) this.sparks(2); e.head.tilt.t = i % 2 ? -4 : 4; await w(1100); }
    }
    e.fx.tremble = 0;
  }

  /** a persistent, softer weather backdrop (Settings → live weather) */
  setAmbient(info: WeatherInfo | null) {
    this.ambientInfo = info;
    if (this.cur !== "weather") this.restoreAmbient();
  }
  private restoreAmbient() {
    const i = this.ambientInfo;
    if (i && !this.sleeping) this.e.setScene(i.kind, { intensity: i.intensity * 0.7, day: i.isDay, full: false });
    else this.e.clearScene();
  }
  private clearAmbient() { this.e.clearScene(); }

  /** test mode: run the full weather show for a made-up forecast */
  previewWeather(info: WeatherInfo, topic: WeatherTopic = "general") {
    this.wReq = { topic };
    this.run("weather", async (w) => { await this.showWeather(info, topic, w); });
  }

  private onLightning(strength: number) {
    snd.thunder(rnd(0.25, 1.0), strength);
    if (this.sleeping) return;
    if (this.cur === "weather" || !this.busy) {
      const e = this.e;
      e.bump(-380); e.head.sx.v += 2.5; e.head.sy.v -= 3;
      if (e.disp.a < 0.5) { this.sweat(1); e.tweak({ w: 170, h: 215 }); }
    }
  }

  private async dodgeSeq(hit: boolean, w: W, alive: () => boolean) {
    const e = this.e;
    this.released = true;
    e.autoGaze = false;
    this.x("focus"); e.look(-0.9, 0); snd.chirp("curious"); e.head.tilt.t = 2;
    await w(650);
    this.x("suspicious"); await w(350);
    e.bullet.x = -140; e.bullet.y = 395; e.bullet.vx = 1500; e.bullet.on = true;
    snd.chirp("whoosh");
    e.look(-0.5, 0);
    while (alive() && e.bullet.x < 40) await w(16);
    if (!alive()) return;
    this.x("surprised", { w: 190, h: 235 }); snd.chirp("surprised");
    e.fx.timeScale = 0.16;
    if (!hit) {
      e.head.tilt.t = -34; e.head.rotX.t = 30; e.head.y.t = 44; e.head.x.t = 26;
      while (alive() && e.bullet.x < 560) { e.look(clamp((e.bullet.x - 400) / 300, -1, 1), 0); await w(16); }
    } else {
      while (alive() && e.bullet.x < 330) await w(16);
      e.bullet.on = false; e.fx.timeScale = 1; e.fx.flash = 1; snd.chirp("bang");
      e.head.x.v += 900; e.head.tilt.v += 500; this.x("dead"); await w(900);
      this.x("dizzy"); snd.chirp("dizzy"); await w(1500);
      this.x("angry"); snd.chirp("angry"); e.emit("anger", 1, { x: 640, y: 170, vy: -10, max: 2.4, size: 1.2 }); await w(1800);
      return;
    }
    if (!alive()) return;
    e.fx.timeScale = 0.6; await w(250);
    e.fx.timeScale = 1;
    e.head.tilt.t = 0; e.head.rotX.t = 0; e.head.y.t = 0; e.head.x.t = 0;
    await w(900);
    this.x("relief"); snd.chirp("phew"); this.sweat(3); e.look(0, 0);
    await w(1500);
    this.x("cool"); snd.chirp("proud"); this.sparks(8); e.head.rotX.t = 6;
    await w(2200);
  }

  /* ---------- DJ ---------- */
  startDj(src: "yt" | "own", bpm = 118) {
    const e = this.e;
    this.sleeping = false;
    if (src === "yt") { snd.stopBeat(); if (this.ownTimeout) clearTimeout(this.ownTimeout); }
    const wasOn = this.musicOn;
    this.musicOn = true;
    this.djSrc = src;
    e.djStart(bpm);
    e.hp.t = 1;
    // take over from whatever action is running
    if (this.cur === "weather") { e.sceneFull(false); this.restoreAmbient(); }
    this.token++;
    this.busy = false;
    this.cur = "";
    e.resetFx();
    if (!wasOn) {
      this.djModeIdx = 0;
      this.djColorIdx = 0;
      this.confetti(25);
      snd.chirp("happy");
    }
    this.applyDjMode();
  }

  stopDj() {
    if (!this.musicOn) return;
    this.musicOn = false;
    this.djSrc = "";
    snd.stopBeat();
    if (this.ownTimeout) clearTimeout(this.ownTimeout);
    this.e.djStop();
    this.e.hp.t = 0;
    this.run("djend", this.actions.djend);
  }

  private applyDjMode() {
    const e = this.e;
    const m = DJ_MODES[this.djModeIdx % DJ_MODES.length];
    const col = m.id === "love" ? [255, 96, 168] as [number, number, number] : DJ_COLORS[this.djColorIdx % DJ_COLORS.length];
    e.autoGaze = false;
    e.look(0, 0);
    e.setExpr(m.expr, { color: m.expr === "love" ? col : col });
    e.fx.sing = m.sing;
    if (!m.sing) e.tweak({ mouth: 0 });
    e.fx.hue = (this.djColorIdx * 55 + 190) % 360;
    e.fx.flash = 0.7;
  }

  private onBeat(n: number) {
    if (!this.musicOn || this.busy) return;
    const e = this.e;
    const m = DJ_MODES[this.djModeIdx % DJ_MODES.length];
    if (n % 12 === 0) {
      this.djModeIdx = (this.djModeIdx + 1 + Math.floor(Math.random() * 2)) % DJ_MODES.length;
      this.djColorIdx++;
      this.applyDjMode();
    }
    const dir = n % 2 ? 1 : -1;
    e.head.tilt.t = dir * m.tilt;
    e.bump(m.bang ? -380 : -240);
    if (m.scratch) { e.head.tilt.v += dir * 700; e.head.rotY.t = dir * 12; }
    else e.head.rotY.t = dir * 6;
    if (m.nod) e.head.rotX.t = n % 2 ? 12 : -3;
    if (m.bang) { e.head.rotX.t = n % 2 ? 16 : 0; e.head.x.t = dir * 18; }
    else e.head.x.t = dir * 6;
    if (n % 3 === 0) this.notes(1);
    if (m.confetti && n % 2 === 0) this.confetti(6);
    if (n % 4 === 0) this.sparks(2);
  }

  /* ---------- timers ---------- */
  startTimer(secs: number, label?: string) {
    this.timer = { end: Date.now() + secs * 1000, total: secs, label };
    this.lastTimerLabel = label || "";
    this.onTimerChange?.({ remaining: secs, total: secs, label });
    this.act("timerSet");
  }
  cancelTimer() { this.timer = null; this.onTimerChange?.(null); }

  /* ---------- tick ---------- */
  private tick() {
    const now = performance.now();
    const e = this.e;
    if (this.timer) {
      const remaining = Math.max(0, (this.timer.end - Date.now()) / 1000);
      this.onTimerChange?.({ remaining: Math.ceil(remaining), total: this.timer.total, label: this.timer.label });
      if (remaining <= 0) {
        this.lastTimerLabel = this.timer.label || "";
        this.timer = null; this.onTimerChange?.(null);
        this.sleeping = false;
        this.act("alarm");
      }
    }
    if (this.sleeping && !this.busy) {
      if (now - this.lastZzz > 1900) {
        this.lastZzz = now;
        e.emit("zzz", 1, { text: "Z", x: 590, y: 280, vx: 22, vy: -34, max: 3.4, size: rnd(0.8, 1.2) });
      }
      e.head.sy.t = 1 + Math.sin(now / 900) * 0.012;
      return;
    }
    // slowly decay mood when ignored
    if (now - this.lastInteract > 45000 && !this.vis.present) this.mood = Math.max(-0.8, this.mood - 0.0008);
    if (this.busy || this.musicOn) return;

    // auto sleep
    if (now - this.lastInteract > 150000 && !this.vis.present && !this.timer) { this.act("sleep"); return; }

    if (now > this.nextIdle) {
      this.nextIdle = now + rnd(5500, 11000);
      const engaged = this.vis.present;
      const pool: string[] = engaged
        ? ["happy", "wink", "curious", "hum", "lookAround", "think", "silly", "love", "proud", "whistle", "dreamy"]
        : ["lookAround", "curious", "hum", "bored", "yawn", "think", "suspicious", "wink", "sneezeRare", "glitchRare", "happy", "stretch", "whistle", "eyeroll", "confused"];
      if (this.mood < -0.35) pool.push("sad", "sad", "bored");
      if (this.mood > 0.5) pool.push("happy", "hum", "love");
      let id = pick(pool);
      if (id === "sneezeRare") id = Math.random() < 0.4 ? "sick" : "lookAround";
      if (id === "glitchRare") id = Math.random() < 0.3 ? "glitch" : "curious";
      const f = this.actions[id];
      if (f) this.run(id, f);
    }
  }

  /* ---------- user input ---------- */
  exec(c: Cmd) {
    this.lastInteract = performance.now();
    this.mood = clamp(this.mood + 0.03, -1, 1);
    this.listenUntil = 0;
    const h = this.hooks;
    switch (c.t) {
      case "act":
        if (c.id === "sleep" || this.actions[c.id]) this.act(c.id);
        break;
      case "play":
        this.act("searching");
        Promise.resolve(h.search?.(c.q, true) ?? 0).then((n) => this.act(n > 0 ? "found" : "notfound")).catch(() => this.act("notfound"));
        break;
      case "music-own": this.stopYtOnly(); this.act("musicOwn"); break;
      case "stop":
        this.timer = null; this.onTimerChange?.(null);
        snd.stopAlarm();
        h.stopMusic?.();
        if (this.musicOn) this.stopDj(); else this.act("happy");
        break;
      case "pause": h.pauseMusic?.(); break;
      case "resume": h.resumeMusic?.(); break;
      case "next": h.nextTrack?.(); break;
      case "prev": h.prevTrack?.(); break;
      case "vol": h.volume?.(c.dir); break;
      case "pick": h.pick?.(c.n); break;
      case "timer": this.startTimer(c.secs, c.label); break;
      case "timer-show": this.act("timerShow"); break;
      case "timer-cancel":
        if (this.timer) { this.cancelTimer(); this.say("Timer cancelled."); } else this.say("There's no timer running.");
        this.act("happy"); break;
      case "stopwatch": {
        const s = this.stopwatch;
        if (c.op === "start") this.stopwatch = { start: Date.now(), running: true, elapsed: 0 };
        else if (c.op === "reset") this.stopwatch = { start: Date.now(), running: false, elapsed: 0 };
        else if (c.op === "stop" && s?.running) this.stopwatch = { start: s.start, running: false, elapsed: (Date.now() - s.start) / 1000 };
        if (!this.stopwatch) { this.say("Say \"start the stopwatch\" first."); this.act("curious"); break; }
        if (c.op === "stop" && this.stopwatch.elapsed > 0) this.say(`Stopped at ${fmtDur(Math.round(this.stopwatch.elapsed))}.`);
        else if (c.op === "start") this.say("Stopwatch started.", false);
        else if (c.op === "show" && this.stopwatch.running) this.say(`${fmtDur(Math.round((Date.now() - this.stopwatch.start) / 1000))} so far.`);
        this.act("stopwatch");
        break;
      }
      case "clock": this.act("clock"); break;
      case "date": this.act("date"); break;
      case "weather": this.wReq = { topic: c.topic, place: c.place }; this.act("weather"); break;
      case "dice": this.diceN = c.n; this.act("dice"); break;
      case "coin": this.act("coin"); break;
      case "rps": this.rpsReq = c.you; this.act("rps"); break;
      case "number": this.numReq = { min: c.min, max: c.max, text: "", label: "" }; this.act("number"); break;
      case "calc": {
        const r = c.op === "+" ? c.a + c.b : c.op === "-" ? c.a - c.b : c.op === "*" ? c.a * c.b : c.b === 0 ? NaN : c.a / c.b;
        const sym = { "+": "+", "-": "−", "*": "×", "/": "÷" }[c.op];
        const text = Number.isFinite(r) ? String(Math.round(r * 1000) / 1000) : "ERR";
        this.numReq = { min: 0, max: 0, text, label: `${c.a} ${sym} ${c.b}` };
        if (!Number.isFinite(r)) { this.say("I can't divide by zero!"); this.act("confused"); break; }
        this.act("calc");
        break;
      }
      case "joke": this.act("joke"); break;
      case "ask": this.askId = c.id; this.act("ask"); break;
      case "color":
        this.e.theme = c.rgb;
        this.e.tweak({ color: c.rgb ?? [62, 244, 255] });
        this.act("colorChange");
        break;
      case "mute": h.setMute?.(c.on); this.say(c.on ? "Okay, I'll stay quiet." : "Sounds are back on!", !c.on); this.act(c.on ? "curious" : "happy"); break;
      case "camera": h.camera?.(c.on); this.act(c.on ? "hello" : "curious"); break;
      case "remember":
        this.act("lookAround");
        h.remember?.()?.then((ok) => this.act(ok ? "remembered" : "notfound"));
        break;
      case "forget": h.forget?.(); this.act("sad"); break;
      case "release": this.released = true; break;
      case "unknown": this.act("huh"); break;
    }
  }
  private stopYtOnly() { if (this.djSrc === "yt") this.hooks.stopMusic?.(); }

  /** "Hey Emo!" heard (interim result): he reacts straight away, then waits for the command. */
  wakeHeard(listenMs = 7000) {
    const now = performance.now();
    this.lastInteract = now;
    this.listenUntil = now + listenMs;
    if (now - this.perkAt < 1500) return;
    this.perkAt = now;
    const e = this.e;
    if (this.sleeping) { this.act("wake"); return; }
    if (this.cur === "heard") return;
    // some moments shouldn't be interrupted by a wake word
    if (["handsup", "alarm", "dodge", "shoot", "carried", "pet"].includes(this.cur) || this.dragging) { snd.chirp("heard"); e.pulse(0.7); return; }
    if (this.musicOn) {
      snd.chirp("heard"); e.pulse(1); e.bump(-300); e.listen.t = 1;
      setTimeout(() => { if (performance.now() >= this.listenUntil) e.listen.t = 0; }, listenMs + 100);
      return;
    }
    this.act("heard");
  }
  /** called when the command is done or the listening window ends */
  stopListening() { this.listenUntil = 0; if (this.cur === "heard") { this.token++; this.busy = false; this.cur = ""; this.after(); } this.e.listen.t = 0; }

  touch(kind: "tap" | "pet-start" | "pet-end" | "drag-start" | "drag-end" | "shake") {
    const now = performance.now();
    this.lastInteract = now;
    switch (kind) {
      case "tap": {
        if (this.sleeping) { this.act("wake"); return; }
        this.taps = this.taps.filter((t) => now - t < 1400); this.taps.push(now);
        if (this.taps.length >= 5) { this.taps = []; this.act("angry"); }
        else if (this.taps.length >= 3) this.act("annoyed");
        else this.act("poke");
        break;
      }
      case "pet-start": this.petting = true; if (this.sleeping) this.act("wake"); else this.act("pet"); break;
      case "pet-end": this.petting = false; break;
      case "drag-start": this.dragging = true; this.petting = false; this.dragVec = { x: 0, y: 0 }; this.act("carried"); break;
      case "drag-end": this.dragging = false; break;
      case "shake":
        if (this.dragging) this.shook = true;
        else if (!this.busy || this.cur === "poke") this.act("dizzy");
        break;
    }
  }
  /** pointer offset while being carried (in px) */
  drag(dx: number, dy: number) { this.dragVec = { x: dx / 220, y: dy / 220 }; }

  /* ---------- camera ---------- */
  onVision(f: FaceInfo) {
    const now = performance.now();
    const v = this.vis;
    const e = this.e;
    if (f.present) {
      if (!v.present) {
        v.away = now - v.lastSeen;
        v.present = true; v.since = now; v.greeted = false;
      }
      v.lastSeen = now;
      this.lastInteract = now;
      if (!this.sleeping && !this.busy) {
        e.autoGaze = false;
        e.lookFor(f.x * 0.95, f.y * 0.8 + 0.05, 700);
        if (!this.musicOn) {
          e.head.tilt.t = clamp(-f.roll * 0.55, -14, 14);
          e.head.x.t = f.x * 14;
        }
      }
      if (this.busy) return;
      // greeting
      if (!v.greeted && now - v.since > (f.count ? 1300 : 500)) {
        v.greeted = true;
        if (this.sleeping) { this.act("wake"); return; }
        if (v.everSeen && v.away > 800 && v.away < 7000) this.act("peekaboo");
        else if (f.known) this.act("greetOwner");
        else if (f.identity === -1 && f.blinkL === 0 && f.smile === 0 && f.jaw === 0) this.act("hello"); // motion-only tracking
        else this.act(this.knownCount > 0 ? "greetStranger" : "hello");
        v.everSeen = true;
        return;
      }
      if (this.sleeping || this.musicOn) return;
      // mimic expressions
      const h = v.hold;
      const hit = (k: string, cond: boolean, frames: number) => {
        h[k] = cond ? (h[k] || 0) + 1 : 0;
        return h[k] >= frames;
      };
      if (now - v.lastMimic < 4500 || !v.greeted) return;
      const trig = (id: string) => { v.lastMimic = now; for (const k in h) h[k] = 0; this.act(id); };
      if (hit("tongue", f.tongue > 0.5, 4)) trig("silly");
      else if (hit("pucker", f.pucker > 0.65, 4)) trig("kiss");
      else if (hit("wink", Math.abs(f.blinkL - f.blinkR) > 0.55 && Math.max(f.blinkL, f.blinkR) > 0.65, 4)) trig("wink");
      else if (hit("jaw", f.jaw > 0.6 && f.smile < 0.5, 4)) trig("surprised");
      else if (hit("smile", f.smile > 0.55, 5)) trig(Math.random() < 0.35 ? "love" : "happy");
      else if (hit("frown", f.frown > 0.4 && f.smile < 0.2, 8)) trig("worried");
      else if (hit("brow", f.brow > 0.75, 5)) trig("curious");
      else if (f.size > 0.62 && now - v.lastClose > 25000) { v.lastClose = now; trig("shy"); }
    } else if (v.present && now - v.lastSeen > 1600) {
      v.present = false;
      if (!this.busy && !this.musicOn && !this.sleeping) {
        e.head.tilt.t = 0; e.head.x.t = 0;
        if (now - v.since > 5000) this.act("lookAround");
      }
    }
  }
  knownCount = 0;
}
