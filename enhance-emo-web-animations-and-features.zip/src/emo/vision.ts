import type { FaceLandmarker } from "@mediapipe/tasks-vision";

export interface FaceInfo {
  present: boolean;
  count: number;
  x: number; // -1..1 (mirrored, like a mirror)
  y: number;
  size: number; // face width / frame width
  smile: number; jaw: number; tongue: number; pucker: number;
  blinkL: number; blinkR: number; frown: number; brow: number;
  roll: number; // degrees
  identity: number; // -1 unknown/none, otherwise index of remembered person
  known: boolean;
}

export const EMPTY_FACE: FaceInfo = {
  present: false, count: 0, x: 0, y: 0, size: 0, smile: 0, jaw: 0, tongue: 0, pucker: 0,
  blinkL: 0, blinkR: 0, frown: 0, brow: 0, roll: 0, identity: -1, known: false,
};

const SIG_IDX = [1, 33, 263, 61, 291, 152, 10, 234, 454, 168, 98, 327, 70, 300, 105, 334, 133, 362, 199];
const STORE = "emo.faces.v1";
const WASM = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.2.3/wasm";
const MODEL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";

export class Vision {
  video: HTMLVideoElement | null = null;
  stream: MediaStream | null = null;
  lm: FaceLandmarker | null = null;
  mode: "off" | "loading" | "mediapipe" | "motion" = "off";
  onFace?: (f: FaceInfo) => void;
  onBox?: (box: { x: number; y: number; w: number; h: number } | null) => void;
  private timer: number | null = null;
  private faces: number[][] = [];
  private enrolling: { samples: number[][]; done: (ok: boolean) => void; t0: number } | null = null;
  private matchHist: number[] = [];
  private prevFrame: Uint8ClampedArray | null = null;
  private mc = document.createElement("canvas");
  private lastMotion = 0;
  private lastTs = 0;

  constructor() {
    try { this.faces = JSON.parse(localStorage.getItem(STORE) || "[]"); } catch { this.faces = []; }
    this.mc.width = 48; this.mc.height = 36;
  }

  get remembered() { return this.faces.length; }
  forget() { this.faces = []; localStorage.removeItem(STORE); }

  async start(video: HTMLVideoElement): Promise<boolean> {
    this.video = video;
    this.mode = "loading";
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user", width: 640, height: 480 }, audio: false });
    } catch { this.mode = "off"; return false; }
    video.srcObject = this.stream;
    video.muted = true;
    video.playsInline = true;
    await video.play().catch(() => {});
    // start with the motion tracker immediately, upgrade to landmarks when the model is ready
    this.mode = "motion";
    this.loop();
    this.loadModel();
    return true;
  }

  private async loadModel() {
    try {
      const { FaceLandmarker: FL, FilesetResolver } = await import("@mediapipe/tasks-vision");
      const fileset = await FilesetResolver.forVisionTasks(WASM);
      const make = (delegate: "GPU" | "CPU") =>
        FL.createFromOptions(fileset, {
          baseOptions: { modelAssetPath: MODEL, delegate },
          runningMode: "VIDEO",
          numFaces: 2,
          outputFaceBlendshapes: true,
        });
      try { this.lm = await make("GPU"); } catch { this.lm = await make("CPU"); }
      if (this.stream) this.mode = "mediapipe";
    } catch (e) {
      console.warn("EMO: face model unavailable, using motion tracking", e);
    }
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    if (this.video) this.video.srcObject = null;
    this.mode = "off";
    this.onFace?.(EMPTY_FACE);
    this.onBox?.(null);
  }

  private loop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = window.setInterval(() => {
      const v = this.video;
      if (!v || v.readyState < 2) return;
      if (this.mode === "mediapipe" && this.lm) this.runLandmarker(v);
      else this.runMotion(v);
    }, 66);
  }

  private runLandmarker(v: HTMLVideoElement) {
    let ts = performance.now();
    if (ts <= this.lastTs) ts = this.lastTs + 1;
    this.lastTs = ts;
    let res;
    try { res = this.lm!.detectForVideo(v, ts); } catch { return; }
    const faces = res.faceLandmarks || [];
    if (!faces.length) { this.onFace?.(EMPTY_FACE); this.onBox?.(null); return; }
    // biggest face
    let bi = 0, bw = 0;
    const boxes = faces.map((lm, i) => {
      let minx = 1, maxx = 0, miny = 1, maxy = 0;
      for (const p of lm) { if (p.x < minx) minx = p.x; if (p.x > maxx) maxx = p.x; if (p.y < miny) miny = p.y; if (p.y > maxy) maxy = p.y; }
      if (maxx - minx > bw) { bw = maxx - minx; bi = i; }
      return { minx, maxx, miny, maxy };
    });
    const b = boxes[bi];
    const lm = faces[bi];
    const bs: Record<string, number> = {};
    for (const c of res.faceBlendshapes?.[bi]?.categories || []) bs[c.categoryName] = c.score;
    const cx = (b.minx + b.maxx) / 2, cy = (b.miny + b.maxy) / 2;
    const vw = v.videoWidth || 640, vh = v.videoHeight || 480;
    const l = lm[33], r = lm[263];
    const roll = (Math.atan2((r.y - l.y) * vh, (r.x - l.x) * vw) * 180) / Math.PI;

    const sig = this.signature(lm, vw, vh);
    let identity = -1;
    if (sig) {
      if (this.enrolling) {
        this.enrolling.samples.push(sig);
        if (this.enrolling.samples.length >= 24) this.finishEnroll(true);
        else if (performance.now() - this.enrolling.t0 > 12000) this.finishEnroll(false);
      }
      identity = this.match(sig);
    }
    this.onBox?.({ x: 1 - b.maxx, y: b.miny, w: b.maxx - b.minx, h: b.maxy - b.miny });
    this.onFace?.({
      present: true, count: faces.length,
      x: (1 - cx) * 2 - 1, y: (cy - 0.5) * 2, size: b.maxx - b.minx,
      smile: ((bs.mouthSmileLeft || 0) + (bs.mouthSmileRight || 0)) / 2,
      jaw: bs.jawOpen || 0, tongue: bs.tongueOut || 0, pucker: bs.mouthPucker || 0,
      blinkL: bs.eyeBlinkLeft || 0, blinkR: bs.eyeBlinkRight || 0,
      frown: ((bs.mouthFrownLeft || 0) + (bs.mouthFrownRight || 0)) / 2,
      brow: bs.browInnerUp || 0, roll,
      identity, known: identity >= 0,
    });
  }

  private signature(lm: { x: number; y: number; z: number }[], vw: number, vh: number): number[] | null {
    // only use near-frontal faces
    const nose = lm[1], cl = lm[234], cr = lm[454];
    const yaw = (nose.x - (cl.x + cr.x) / 2) / Math.max(0.001, Math.abs(cr.x - cl.x));
    if (Math.abs(yaw) > 0.1) return null;
    const pts = SIG_IDX.map((i) => [lm[i].x * vw, lm[i].y * vh, lm[i].z * vw]);
    const iod = Math.hypot(pts[1][0] - pts[2][0], pts[1][1] - pts[2][1]);
    if (iod < 20) return null;
    const out: number[] = [];
    for (let i = 0; i < pts.length; i++)
      for (let j = i + 1; j < pts.length; j++)
        out.push(Math.hypot(pts[i][0] - pts[j][0], pts[i][1] - pts[j][1], (pts[i][2] - pts[j][2]) * 0.5) / iod);
    return out;
  }

  private dist(a: number[], b: number[]) {
    let s = 0;
    for (let i = 0; i < a.length; i++) s += Math.abs(a[i] - b[i]) / (b[i] + 0.05);
    return s / a.length;
  }

  private match(sig: number[]): number {
    if (!this.faces.length) return -1;
    let best = -1, bd = 1;
    this.faces.forEach((f, i) => { const d = this.dist(sig, f); if (d < bd) { bd = d; best = i; } });
    this.matchHist.push(bd < 0.075 ? best : -1);
    if (this.matchHist.length > 10) this.matchHist.shift();
    const votes = this.matchHist.filter((m) => m === best).length;
    return votes >= 5 ? best : -1;
  }

  enroll(): Promise<boolean> {
    return new Promise((done) => {
      this.enrolling = { samples: [], done, t0: performance.now() };
    });
  }
  private finishEnroll(ok: boolean) {
    const e = this.enrolling;
    if (!e) return;
    this.enrolling = null;
    if (ok && e.samples.length) {
      const n = e.samples[0].length;
      const avg = new Array(n).fill(0);
      for (const s of e.samples) for (let i = 0; i < n; i++) avg[i] += s[i] / e.samples.length;
      this.faces.push(avg);
      if (this.faces.length > 10) this.faces.shift();
      localStorage.setItem(STORE, JSON.stringify(this.faces));
      this.matchHist = [];
    }
    e.done(ok);
  }

  private runMotion(v: HTMLVideoElement) {
    const c = this.mc.getContext("2d", { willReadFrequently: true })!;
    c.drawImage(v, 0, 0, 48, 36);
    const d = c.getImageData(0, 0, 48, 36).data;
    if (this.prevFrame) {
      let sx = 0, sy = 0, n = 0;
      for (let i = 0; i < d.length; i += 4) {
        const diff = Math.abs(d[i] - this.prevFrame[i]) + Math.abs(d[i + 1] - this.prevFrame[i + 1]) + Math.abs(d[i + 2] - this.prevFrame[i + 2]);
        if (diff > 60) { const p = i / 4; sx += p % 48; sy += Math.floor(p / 48); n++; }
      }
      const now = performance.now();
      if (n > 14) {
        this.lastMotion = now;
        const x = 1 - sx / n / 48, y = sy / n / 36;
        this.onFace?.({ ...EMPTY_FACE, present: true, count: 1, x: x * 2 - 1, y: (y - 0.5) * 2, size: Math.min(0.6, n / 300) });
        this.onBox?.({ x: x - 0.12, y: y - 0.15, w: 0.24, h: 0.3 });
      } else if (now - this.lastMotion > 2500) {
        this.onFace?.(EMPTY_FACE);
        this.onBox?.(null);
      }
    }
    this.prevFrame = new Uint8ClampedArray(d);
  }
}
