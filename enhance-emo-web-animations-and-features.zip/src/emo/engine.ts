import { DEF, PRESETS, type Expr, type Kind } from "./expressions";
import type { SceneKind } from "./weather";

class Spring {
  x: number; v = 0; t: number;
  constructor(x: number, public k = 260, public c = 24) { this.x = x; this.t = x; }
  step(dt: number) {
    const n = Math.max(1, Math.ceil(dt / 0.008));
    const h = dt / n;
    for (let i = 0; i < n; i++) {
      this.v += ((this.t - this.x) * this.k - this.v * this.c) * h;
      this.x += this.v * h;
    }
  }
  snap(x: number) { this.x = x; this.t = x; this.v = 0; }
}

const NUM_KEYS = [
  "w", "h", "r", "gap", "y", "tilt", "slant", "topLid", "botLid", "hR", "lidR", "yR",
  "mouth", "open", "smile", "mw", "tongue", "blush", "bright",
] as const;
type NumKey = (typeof NUM_KEYS)[number];

interface KindState { cur: Kind; target: Kind; s: Spring; }

type PType = "heart" | "note" | "zzz" | "tear" | "sweat" | "spark" | "bang" | "question" | "anger" | "confetti" | "drop" | "dot" | "puff" | "star";
interface Particle {
  type: PType; x: number; y: number; vx: number; vy: number; g: number;
  life: number; max: number; size: number; rot: number; vr: number; text?: string; hue?: number;
}

export interface FrameInfo {
  tilt: number; x: number; y: number; sx: number; sy: number; rotX: number; rotY: number;
  beat: number; hp: number; djOn: boolean; energy: number; hue: number; flash: number;
  color: [number, number, number]; bright: number;
  sky: SceneKind | "none"; skyA: number; bolt: number; day: boolean;
}

export type DisplayType = "none" | "clock" | "timer" | "weather" | "dice" | "coin" | "date" | "stopwatch" | "number" | "rps";

interface Cloud { ax: number; ay: number; as: number; fx: number; fy: number; fs: number; dark: number; sp: number }
interface Drop { x: number; y: number; vx: number; vy: number; len: number; w: number }
interface Flake { x: number; y: number; vy: number; ph: number; r: number; vx: number }
interface Ripple { x: number; y: number; t: number }
interface Bolt { pts: [number, number][]; branches: [number, number][][]; t: number }

const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const smooth = (k: number) => { const x = clamp(k, 0, 1); return x * x * (3 - 2 * x); };

export class EmoEngine {
  cv: HTMLCanvasElement;
  c: CanvasRenderingContext2D;
  W = 800;
  dpr = 1;
  P = {} as Record<NumKey, Spring>;
  col = [new Spring(62, 80, 14), new Spring(244, 80, 14), new Spring(255, 80, 14)];
  kL: KindState = { cur: "rect", target: "rect", s: new Spring(1, 520, 34) };
  kR: KindState = { cur: "rect", target: "rect", s: new Spring(1, 520, 34) };
  base: Expr = { ...DEF };
  lx = new Spring(0, 170, 20);
  ly = new Spring(0, 170, 20);
  gazeLock = 0;
  nextSaccade = 0;
  autoGaze = true;
  head = {
    tilt: new Spring(0, 120, 11), x: new Spring(0, 140, 13), y: new Spring(0, 140, 13),
    sx: new Spring(1, 200, 12), sy: new Spring(1, 200, 12), rotX: new Spring(0, 100, 12), rotY: new Spring(0, 100, 12),
  };
  hands = new Spring(0, 90, 11);
  hp = new Spring(0, 70, 11);
  beatPulse = new Spring(0, 180, 13);
  /** a: 0 = face, 1 = display. Face fades out first, then the display fades in (never both at once). */
  disp = { type: "none" as DisplayType, a: 0, target: 0, data: {} as any };
  listen = new Spring(0, 90, 13);
  theme: [number, number, number] | null = null;
  scene = {
    kind: "none" as SceneKind | "none", a: 0, target: 0, full: 0, fullT: 0, intensity: 0.6, day: true,
    clouds: [] as Cloud[], drops: [] as Drop[], flakes: [] as Flake[], ripples: [] as Ripple[],
    bolt: null as Bolt | null, nextBolt: 0, flash: 0, acc: 0, stars: [] as { x: number; y: number; p: number; s: number }[],
  };
  onLightning?: (strength: number) => void;
  fx = { glitch: 0, flash: 0, tremble: 0, timeScale: 1, blinkOn: true, sing: false, hue: 190 };
  parts: Particle[] = [];
  bullet: { x: number; y: number; vx: number; on: boolean } = { x: -100, y: 360, vx: 0, on: false };
  dj = {
    on: false, bpm: 120, energy: 0, bars: [0.3, 0.5, 0.7, 0.5, 0.3], tgt: [0, 0, 0, 0, 0],
    nextBeat: 0, lastBeat: 0, beat: 0, external: 0,
  };
  t = 0;
  last = 0;
  raf = 0;
  blink = 0;
  blinkPhase = -1;
  nextBlink = 2000;
  onFrame?: (f: FrameInfo) => void;
  onBeat?: (n: number) => void;
  blur = 0;

  constructor(cv: HTMLCanvasElement) {
    this.cv = cv;
    this.c = cv.getContext("2d")!;
    for (const k of NUM_KEYS) this.P[k] = new Spring((DEF as any)[k]);
    this.P.bright.k = 60; this.P.bright.c = 14;
    this.P.tilt.k = 160; this.P.tilt.c = 16;
    this.resize();
  }

  resize() {
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    const px = 800 * this.dpr;
    if (this.cv.width !== px) { this.cv.width = px; this.cv.height = px; }
  }

  start() {
    this.last = performance.now();
    const loop = (now: number) => {
      this.raf = requestAnimationFrame(loop);
      this.frame(now);
    };
    this.raf = requestAnimationFrame(loop);
  }
  stop() { cancelAnimationFrame(this.raf); }

  /* ---------- state API ---------- */
  setExpr(name: string | Partial<Expr>, extra?: Partial<Expr>) {
    const p = typeof name === "string" ? PRESETS[name] || {} : name;
    const ex = extra ? (Object.fromEntries(Object.entries(extra).filter(([, v]) => v !== undefined)) as Partial<Expr>) : undefined;
    const e: Expr = { ...DEF, ...p, ...ex };
    if (this.theme && !(p as Partial<Expr>).color && !ex?.color) e.color = this.theme;
    this.base = e;
    for (const k of NUM_KEYS) this.P[k].t = (e as any)[k];
    for (let i = 0; i < 3; i++) this.col[i].t = e.color[i];
    this.setKind(this.kL, e.kind);
    this.setKind(this.kR, e.kindR || e.kind);
  }
  tweak(p: Partial<Expr>) {
    for (const k of NUM_KEYS) if ((p as any)[k] !== undefined) this.P[k].t = (p as any)[k];
    if (p.color) for (let i = 0; i < 3; i++) this.col[i].t = p.color[i];
  }
  private setKind(s: KindState, k: Kind) { s.target = k; }
  look(x: number, y: number) { this.lx.t = clamp(x, -1.2, 1.2); this.ly.t = clamp(y, -1.2, 1.2); }
  lookFor(x: number, y: number, ms: number) { this.look(x, y); this.gazeLock = performance.now() + ms; }
  display(type: DisplayType, data: any = {}) {
    if (type !== "none") { this.disp.type = type; this.disp.data = data; }
    this.disp.target = type === "none" ? 0 : 1;
  }
  get displayShown() { return this.disp.target > 0 || this.disp.a > 0.02; }

  /* ---------- weather scene ---------- */
  setScene(kind: SceneKind, o: { intensity?: number; day?: boolean; full?: boolean } = {}) {
    const sc = this.scene;
    const changed = sc.kind !== kind;
    sc.kind = kind; sc.target = 1; sc.intensity = o.intensity ?? 0.6; sc.day = o.day ?? true;
    sc.fullT = o.full ? 1 : 0;
    if (changed) {
      sc.drops = []; sc.flakes = []; sc.ripples = []; sc.bolt = null;
      sc.nextBolt = performance.now() + 900;
      const mk = (ax: number, ay: number, as: number, fx: number, fy: number, fs: number, dark: number, sp: number): Cloud => ({ ax, ay, as, fx, fy, fs, dark, sp });
      const wet = kind === "drizzle" || kind === "rain" || kind === "snow" || kind === "sleet";
      sc.clouds =
        kind === "cloudy" ? [mk(150, 90, 1.0, 280, 235, 1.5, 0.12, 8), mk(430, 62, 1.25, 480, 300, 1.7, 0.08, 5), mk(690, 110, 0.9, 360, 190, 1.35, 0.18, 10), mk(310, 150, 0.8, 560, 235, 1.15, 0.1, 6)]
        : kind === "partly" ? [mk(560, 130, 1.0, 500, 300, 1.55, 0.08, 6), mk(200, 80, 0.7, 250, 210, 1.0, 0.1, 9)]
        : kind === "storm" ? [mk(120, 60, 1.35, 290, 235, 1.9, 0.82, 6), mk(400, 38, 1.55, 490, 262, 2.1, 0.88, 4), mk(690, 70, 1.3, 400, 190, 1.75, 0.78, 7), mk(270, 128, 1.0, 540, 215, 1.5, 0.72, 5)]
        : wet ? [mk(170, 70, 1.15, 320, 235, 1.75, kind === "snow" ? 0.12 : 0.4, 7), mk(440, 48, 1.35, 480, 258, 1.95, kind === "snow" ? 0.1 : 0.45, 5), mk(700, 80, 1.1, 400, 195, 1.5, kind === "snow" ? 0.16 : 0.32, 8)]
        : [];
      sc.stars = Array.from({ length: 16 }, () => ({ x: rnd(40, 760), y: rnd(40, 330), p: rnd(0, 6), s: rnd(0.5, 1.2) }));
    }
  }
  sceneFull(on: boolean) { this.scene.fullT = on ? 1 : 0; }
  clearScene() { this.scene.target = 0; this.scene.fullT = 0; }
  emit(type: PType, n = 1, o: Partial<Particle> = {}) {
    for (let i = 0; i < n; i++) {
      const base: Particle = {
        type, x: 400, y: 400, vx: 0, vy: -60, g: 0, life: 0, max: 2, size: 1, rot: 0, vr: 0,
      };
      this.parts.push(Object.assign(base, o));
    }
  }
  pulse(amount = 1) { this.beatPulse.x = Math.max(this.beatPulse.x, amount); this.beatPulse.v = 0; }
  bump(dy = -420) { this.head.y.v += dy; this.head.sy.v -= 3; this.head.sx.v += 2; }
  resetFx() {
    this.fx.timeScale = 1; this.fx.glitch = 0; this.fx.tremble = 0; this.fx.sing = false;
    this.hands.t = 0; this.bullet.on = false;
    this.head.tilt.t = 0; this.head.x.t = 0; this.head.y.t = 0; this.head.rotX.t = 0; this.head.rotY.t = 0;
    this.head.sx.t = 1; this.head.sy.t = 1;
    this.disp.target = 0;
    this.listen.t = 0;
  }

  /* ---------- DJ ---------- */
  djStart(bpm = 120) {
    this.dj.on = true; this.dj.bpm = bpm; this.dj.nextBeat = performance.now() + 200; this.dj.beat = 0;
  }
  djStop() { this.dj.on = false; this.dj.energy = 0; this.fx.sing = false; }
  djOnset(now = performance.now()) {
    if (!this.dj.on) return;
    this.dj.external = now;
    if (now - this.dj.lastBeat > 280) { this.fireBeat(now); this.dj.nextBeat = now + 60000 / this.dj.bpm; }
  }
  private fireBeat(now: number) {
    this.dj.lastBeat = now;
    this.dj.beat++;
    this.pulse(1);
    this.onBeat?.(this.dj.beat);
  }

  /* ---------- frame ---------- */
  private frame(now: number) {
    const real = clamp((now - this.last) / 1000, 0, 0.05);
    this.last = now;
    const dt = real * this.fx.timeScale;
    this.t += dt;
    this.update(dt, real, now);
    this.draw();
    const h = this.head;
    const breath = Math.sin(this.t * 1.7) * 3;
    this.onFrame?.({
      tilt: h.tilt.x, x: h.x.x, y: h.y.x + breath, sx: h.sx.x, sy: h.sy.x, rotX: h.rotX.x, rotY: h.rotY.x,
      beat: this.beatPulse.x, hp: this.hp.x, djOn: this.dj.on, energy: this.dj.energy, hue: this.fx.hue,
      flash: this.fx.flash, color: [this.col[0].x, this.col[1].x, this.col[2].x], bright: this.P.bright.x,
      sky: this.scene.kind, skyA: this.scene.a, bolt: this.scene.flash, day: this.scene.day,
    });
  }

  private update(dt: number, real: number, now: number) {
    for (const k of NUM_KEYS) this.P[k].step(dt);
    for (const s of this.col) s.step(dt);
    for (const s of Object.values(this.head)) s.step(dt);
    this.lx.step(dt); this.ly.step(dt); this.hands.step(dt); this.hp.step(dt); this.listen.step(real);
    this.beatPulse.t = 0; this.beatPulse.step(real);
    {
      const d = this.disp;
      const step = real / 0.34; // face out + display in take ~0.34s in total
      d.a = d.target > d.a ? Math.min(d.target, d.a + step) : Math.max(d.target, d.a - step);
    }
    this.updateScene(real, now);
    this.fx.flash = Math.max(0, this.fx.flash - real * 3);
    for (const ks of [this.kL, this.kR]) {
      if (ks.cur !== ks.target) {
        ks.s.t = 0;
        if (ks.s.x < 0.14) { ks.cur = ks.target; ks.s.t = 1; }
      } else ks.s.t = 1;
      ks.s.step(real);
    }

    // idle gaze saccades
    if (this.autoGaze && now > this.gazeLock && now > this.nextSaccade) {
      this.nextSaccade = now + rnd(1400, 4200);
      this.lx.t = rnd(-0.35, 0.35); this.ly.t = rnd(-0.2, 0.2);
    }
    // blinking
    if (this.fx.blinkOn) {
      if (this.blinkPhase < 0 && now > this.nextBlink) { this.blinkPhase = 0; }
      if (this.blinkPhase >= 0) {
        this.blinkPhase += real / 0.2;
        this.blink = Math.sin(clamp(this.blinkPhase, 0, 1) * Math.PI);
        if (this.blinkPhase >= 1) {
          this.blinkPhase = -1; this.blink = 0;
          this.nextBlink = now + (Math.random() < 0.2 ? 250 : rnd(2200, 5600));
        }
      }
    } else this.blink = 0;

    // DJ clock + bars + singing
    const d = this.dj;
    if (d.on) {
      if (now - d.external > 900 && now >= d.nextBeat) {
        this.fireBeat(now);
        d.nextBeat += 60000 / d.bpm;
        if (d.nextBeat < now) d.nextBeat = now + 60000 / d.bpm;
      }
      for (let i = 0; i < 5; i++) {
        if (Math.random() < 0.18 + this.beatPulse.x * 0.5) d.tgt[i] = clamp(0.2 + Math.random() * 0.55 + d.energy * 0.5 + this.beatPulse.x * 0.3, 0.12, 1);
        d.bars[i] += (d.tgt[i] - d.bars[i]) * Math.min(1, real * 14);
      }
      if (this.fx.sing) {
        const syl = (Math.sin(this.t * 11) + Math.sin(this.t * 7.3 + 1)) * 0.25 + 0.5;
        this.P.mouth.t = 1;
        this.P.open.t = clamp(0.12 + syl * 0.8 + d.energy * 0.5 + this.beatPulse.x * 0.2, 0.05, 1.2);
        this.P.mw.t = 70 + syl * 55;
        this.P.smile.t = 0.5 + Math.sin(this.t * 3) * 0.3;
      }
    } else if (this.fx.sing) {
      // singing without DJ (birthday etc)
      const syl = (Math.sin(this.t * 10) + Math.sin(this.t * 6.1 + 1)) * 0.25 + 0.5;
      this.P.mouth.t = 1;
      this.P.open.t = 0.15 + syl * 0.9;
      this.P.mw.t = 70 + syl * 50;
    }

    // particles
    for (const p of this.parts) {
      p.life += dt;
      p.vy += p.g * dt;
      p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt;
      if (p.type === "heart" || p.type === "note" || p.type === "zzz") p.x += Math.sin(p.life * 3 + p.rot) * 0.6;
    }
    this.parts = this.parts.filter((p) => p.life < p.max);
    if (this.parts.length > 160) this.parts.splice(0, this.parts.length - 160);

    if (this.bullet.on) {
      this.bullet.x += this.bullet.vx * dt;
      if (this.bullet.x > 950) this.bullet.on = false;
    }
  }

  /* ---------- drawing ---------- */
  private rgba(a = 1) {
    return `rgba(${this.col[0].x | 0},${this.col[1].x | 0},${this.col[2].x | 0},${clamp(a, 0, 1)})`;
  }

  private draw() {
    const c = this.c;
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.clearRect(0, 0, this.cv.width, this.cv.height);
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const bright = clamp(this.P.bright.x, 0, 1.2);
    const handsA = this.hands.x;
    // face and display never show together: the face fades out first, then the display fades in
    const da = this.disp.a;
    const faceA = 1 - smooth(da / 0.5);
    const dispA = smooth((da - 0.5) / 0.5);
    c.globalAlpha = bright;
    c.lineCap = "round"; c.lineJoin = "round";

    if (this.scene.a > 0.01) this.drawSceneBack();

    // tremble / shake
    const tr = this.fx.tremble;
    c.save();
    if (tr > 0) c.translate(rnd(-tr, tr), rnd(-tr, tr) * 0.6);

    if (faceA > 0.01) {
      c.save();
      c.globalAlpha = bright * faceA;
      this.drawEye(1);
      this.drawEye(-1);
      if (this.kL.cur === "glass" && this.kR.cur === "glass") this.drawBridge();
      this.drawMouth();
      this.drawBlush();
      c.restore();
    }
    if (dispA > 0.01) {
      c.save();
      c.globalAlpha = bright * dispA;
      const pop = 0.94 + 0.06 * dispA;
      c.translate(400, 400); c.scale(pop, pop); c.translate(-400, -400);
      this.drawDisplay();
      c.restore();
    }
    c.restore();

    if (this.listen.x > 0.02 && faceA > 0.3) this.drawListening();
    this.drawParticles();
    if (this.bullet.on) this.drawBullet();
    if (handsA > 0.02) this.drawHands(handsA);
    if (this.scene.a > 0.01) this.drawSceneFront();

    // glitch post-process
    if (this.fx.glitch > 0.02) {
      const g = this.fx.glitch;
      c.setTransform(1, 0, 0, 1, 0, 0);
      c.globalAlpha = 1;
      const n = 3 + Math.floor(g * 8);
      for (let i = 0; i < n; i++) {
        const sy = Math.floor(rnd(0, this.cv.height - 40));
        const sh = Math.floor(rnd(6, 60 * this.dpr));
        const dx = Math.floor(rnd(-80, 80) * g * this.dpr);
        c.drawImage(this.cv, 0, sy, this.cv.width, sh, dx, sy, this.cv.width, sh);
      }
      if (Math.random() < g * 0.5) {
        c.fillStyle = this.rgba(0.8);
        for (let i = 0; i < 6; i++) c.fillRect(rnd(0, this.cv.width), rnd(0, this.cv.height), rnd(4, 24) * this.dpr, 3 * this.dpr);
      }
    }
  }

  /** soft sound-wave rings while EMO is listening for a command */
  private drawListening() {
    const c = this.c;
    const k = clamp(this.listen.x, 0, 1);
    c.save();
    c.lineWidth = 6;
    for (let i = 0; i < 3; i++) {
      const p = ((this.t * 0.9 + i / 3) % 1);
      const r = 200 + p * 190;
      c.globalAlpha = k * (1 - p) * 0.38 * clamp(this.P.bright.x, 0, 1);
      c.strokeStyle = this.rgba(1);
      c.beginPath(); c.arc(400, 400, r, 0, Math.PI * 2); c.stroke();
    }
    c.restore();
  }

  private eyeBox(side: 1 | -1) {
    const right = side === -1;
    const P = this.P;
    const ks = right ? this.kR : this.kL;
    const lx = this.lx.x, ly = this.ly.x;
    const w = P.w.x * (1 - 0.08 * Math.abs(lx));
    const h = P.h.x * (right ? P.hR.x : 1);
    const cx = 400 - side * P.gap.x * 0.5 + lx * 55;
    const cy = 385 + P.y.x + (right ? P.yR.x : 0) + ly * 42 + Math.sin(this.t * 1.7) * 2;
    return { right, ks, w, h, cx, cy };
  }

  private drawEye(side: 1 | -1) {
    const c = this.c;
    const { right, ks, w, h: h0, cx, cy } = this.eyeBox(side);
    const P = this.P;
    const sc = clamp(ks.s.x, 0, 1.15);
    if (sc < 0.02) return;
    const kind = ks.cur;
    const solid = kind === "rect" || kind === "glass";
    const h = solid ? Math.max(6, h0 * (1 - this.blink * 0.94)) : h0;
    const col = this.rgba(1);

    c.save();
    c.translate(cx, cy);
    c.rotate((side * P.tilt.x * Math.PI) / 180);
    c.scale(side * (0.5 + 0.5 * sc), sc);
    c.fillStyle = col;
    c.strokeStyle = col;
    const thick = 28;
    const lx = () => this.lx.x, ly = () => this.ly.x;

    switch (kind) {
      case "rect": {
        const r = Math.min(P.r.x, w / 2, h / 2);
        c.beginPath(); c.roundRect(-w / 2, -h / 2, w, h, r); c.clip();
        const lid = clamp(P.topLid.x + (right ? P.lidR.x : 0), 0, 0.95);
        const sl = P.slant.x;
        const yi = -h / 2 + h * (lid + sl * 0.5);
        const yo = -h / 2 + h * (lid - sl * 0.5);
        const yAt = (x: number) => yo + ((yi - yo) * (x + w / 2)) / w;
        c.beginPath(); c.moveTo(-w, yAt(-w)); c.lineTo(w, yAt(w)); c.lineTo(w, h); c.lineTo(-w, h); c.closePath(); c.clip();
        if (P.botLid.x > 0.01) {
          const edge = h / 2 - h * P.botLid.x * 0.25;
          const mid = h / 2 - h * P.botLid.x * 1.1;
          c.beginPath(); c.moveTo(-w, -h); c.lineTo(w, -h); c.lineTo(w, edge); c.quadraticCurveTo(0, 2 * mid - edge, -w, edge); c.closePath(); c.clip();
        }
        c.fillRect(-w, -h, w * 2, h * 2);
        break;
      }
      case "glass": {
        c.beginPath();
        c.roundRect(-w / 2, -h * 0.3 * (1 - this.blink * 0.5), w, h * 0.62, [14, 14, w * 0.38, w * 0.38]);
        c.fill();
        c.save();
        c.clip();
        c.strokeStyle = "rgba(0,0,0,0.75)";
        c.lineWidth = 12;
        const o = ((this.t * 40) % 120) - 60;
        for (let i = -1; i < 2; i++) { c.beginPath(); c.moveTo(-w / 2 + i * 55 + o * 0.3 + 10, h * 0.35); c.lineTo(-w / 2 + i * 55 + o * 0.3 + 80, -h * 0.35); c.stroke(); }
        c.restore();
        break;
      }
      case "arc": {
        c.lineWidth = thick;
        c.beginPath(); c.ellipse(0, h * 0.5, w / 2 - thick / 2, h, 0, Math.PI * 1.04, Math.PI * 1.96); c.stroke();
        break;
      }
      case "arcDown": {
        c.lineWidth = thick - 4;
        c.beginPath(); c.ellipse(0, -h * 0.5, w / 2 - thick / 2, h, 0, Math.PI * 0.04, Math.PI * 0.96); c.stroke();
        break;
      }
      case "line": {
        c.lineWidth = 18; c.beginPath(); c.moveTo(-w / 2, 0); c.lineTo(w / 2, 0); c.stroke();
        break;
      }
      case "heart": {
        const s = (w / 2) * (1 + this.beatPulse.x * 0.18 + Math.sin(this.t * 6) * 0.05);
        c.beginPath();
        c.moveTo(0, s * 0.9);
        c.bezierCurveTo(-s * 1.35, s * 0.1, -s * 0.95, -s * 0.95, 0, -s * 0.38);
        c.bezierCurveTo(s * 0.95, -s * 0.95, s * 1.35, s * 0.1, 0, s * 0.9);
        c.fill();
        break;
      }
      case "star": {
        const R = (w / 2) * (1 + Math.sin(this.t * 7 + side) * 0.08 + this.beatPulse.x * 0.1);
        c.rotate(Math.sin(this.t * 2) * 0.15);
        c.beginPath();
        for (let i = 0; i < 4; i++) {
          const a = (i * Math.PI) / 2 - Math.PI / 2;
          const nxt = a + Math.PI / 2;
          const mid = a + Math.PI / 4;
          if (i === 0) c.moveTo(Math.cos(a) * R, Math.sin(a) * R);
          c.quadraticCurveTo(Math.cos(mid) * R * 0.16, Math.sin(mid) * R * 0.16, Math.cos(nxt) * R, Math.sin(nxt) * R);
        }
        c.closePath();
        c.fill();
        break;
      }
      case "x": {
        c.lineWidth = 30;
        const s = w * 0.36;
        c.beginPath(); c.moveTo(-s, -s); c.lineTo(s, s); c.moveTo(s, -s); c.lineTo(-s, s); c.stroke();
        break;
      }
      case "spiral": {
        c.rotate(this.t * 7 * -side);
        c.lineWidth = 15;
        c.beginPath();
        const R = w / 2;
        for (let a = 0; a < Math.PI * 5; a += 0.15) {
          const r = (a / (Math.PI * 5)) * R;
          const x = Math.cos(a) * r, y = Math.sin(a) * r;
          if (a === 0) c.moveTo(x, y); else c.lineTo(x, y);
        }
        c.stroke();
        break;
      }
      case "bars": {
        const n = 5, bw = w / (n * 1.55);
        for (let i = 0; i < n; i++) {
          const bh = Math.max(bw, this.dj.bars[(i + (right ? 2 : 0)) % 5] * h);
          c.beginPath();
          c.roundRect(-w / 2 + i * (w / n) + (w / n - bw) / 2, -bh / 2, bw, bh, bw / 2);
          c.fill();
        }
        break;
      }
      case "vinyl": {
        const R = w / 2;
        const a = this.t * 5 * -side;
        c.lineWidth = 10;
        c.beginPath(); c.arc(0, 0, R - 5, 0, Math.PI * 2); c.stroke();
        c.globalAlpha *= 0.18; c.fill(); c.globalAlpha /= 0.18;
        c.lineWidth = 8;
        c.beginPath(); c.arc(0, 0, R * 0.72, a, a + 1.7); c.stroke();
        c.beginPath(); c.arc(0, 0, R * 0.72, a + Math.PI, a + Math.PI + 1.7); c.stroke();
        c.beginPath(); c.arc(0, 0, R * 0.5, a + 1, a + 2.8); c.stroke();
        c.beginPath(); c.arc(0, 0, R * 0.5, a + 1 + Math.PI, a + 2.8 + Math.PI); c.stroke();
        c.beginPath(); c.arc(0, 0, R * 0.24, 0, Math.PI * 2); c.fill();
        c.fillStyle = "#000"; c.beginPath(); c.arc(0, 0, R * 0.06, 0, Math.PI * 2); c.fill();
        break;
      }
      case "dots": {
        for (let i = -1; i <= 1; i++) {
          const y = -Math.abs(Math.sin(this.t * 6 + i * 0.9)) * 36 + 10;
          c.beginPath(); c.arc(i * 50, y, 15, 0, Math.PI * 2); c.fill();
        }
        break;
      }
      case "orb": {
        const R = w / 2;
        c.beginPath(); c.arc(0, 0, R, 0, Math.PI * 2); c.fill();
        c.fillStyle = "rgba(2,10,16,.9)";
        c.beginPath(); c.arc(lx() * 0.1, ly() * 0.1 + 4, R * 0.7, 0, Math.PI * 2); c.fill();
        c.fillStyle = col;
        c.beginPath(); c.arc(-R * 0.26, -R * 0.26, R * 0.2, 0, Math.PI * 2); c.fill();
        c.beginPath(); c.arc(R * 0.2, R * 0.22, R * 0.09, 0, Math.PI * 2); c.fill();
        break;
      }
      case "squeeze": {
        c.lineWidth = 26;
        const s = Math.min(w, h) * 0.34;
        c.beginPath(); c.moveTo(-s, -s); c.lineTo(s * 0.9, 0); c.lineTo(-s, s); c.stroke();
        break;
      }
      case "ring": {
        c.lineWidth = 18;
        const a = this.t * 7;
        c.beginPath(); c.arc(0, 0, w / 2 - 14, a, a + 4.2); c.stroke();
        break;
      }
    }
    c.restore();
  }

  private drawBridge() {
    const c = this.c;
    const L = this.eyeBox(1), R = this.eyeBox(-1);
    c.strokeStyle = this.rgba(1); c.lineWidth = 14;
    c.beginPath();
    c.moveTo(L.cx - L.w / 2 - 30, L.cy - L.h * 0.28); c.lineTo(R.cx + R.w / 2 + 30, R.cy - R.h * 0.28);
    c.stroke();
  }

  private drawMouth() {
    const vis = this.P.mouth.x;
    if (vis < 0.03) return;
    const c = this.c, P = this.P;
    const open = Math.max(0, P.open.x) * 66;
    const mw = Math.max(12, P.mw.x);
    const sm = clamp(P.smile.x, -1.2, 1.2);
    const cx = 400 + this.lx.x * 26;
    const y0 = 612 + P.y.x * 0.3 + this.ly.x * 16;
    const yC = y0 - sm * 26; // mouth corners
    const round = clamp((92 - mw) / 62, 0, 1); // narrow mouths become ovals
    const yT = y0 + sm * 20 - open * 0.5 * round; // top edge, centre
    const col = this.rgba(1);
    c.save();
    c.globalAlpha *= clamp(vis, 0, 1);
    c.lineCap = "round"; c.lineJoin = "round";
    c.strokeStyle = col; c.fillStyle = col; c.lineWidth = 14;

    if (open < 5) {
      c.beginPath();
      c.moveTo(cx - mw, yC);
      c.quadraticCurveTo(cx, 2 * yT - yC, cx + mw, yC);
      c.stroke();
      c.restore();
      return;
    }

    const yB = Math.max(yT + open, lerp(yC, (yT + yT + open) / 2, round) + open * 0.55);
    const yCo = lerp(yC, (yT + yB) / 2, round);
    const K = 0.552;
    const path = () => {
      c.beginPath();
      c.moveTo(cx - mw, yCo);
      c.bezierCurveTo(cx - mw, yCo + (yT - yCo) * K, cx - mw * K, yT, cx, yT);
      c.bezierCurveTo(cx + mw * K, yT, cx + mw, yCo + (yT - yCo) * K, cx + mw, yCo);
      c.bezierCurveTo(cx + mw, yCo + (yB - yCo) * K, cx + mw * K, yB, cx, yB);
      c.bezierCurveTo(cx - mw * K, yB, cx - mw, yCo + (yB - yCo) * K, cx - mw, yCo);
      c.closePath();
    };
    const tongue = P.tongue.x;
    const hollow = clamp((open - 30) / 26, 0, 1);

    // tongue hanging out of a small mouth (blep)
    if (tongue > 0.1 && hollow < 0.6) {
      c.save();
      c.globalAlpha *= tongue;
      c.fillStyle = "rgb(255,120,165)";
      c.beginPath(); c.roundRect(cx + mw * 0.05, yB - 6, mw * 0.55, 34 + open * 0.4, 18); c.fill();
      c.strokeStyle = "rgba(160,30,80,.55)"; c.lineWidth = 4;
      c.beginPath(); c.moveTo(cx + mw * 0.33, yB + 6); c.lineTo(cx + mw * 0.33, yB + 22); c.stroke();
      c.restore();
    }
    path();
    c.fill();
    c.lineWidth = 9; c.stroke();

    if (hollow > 0.02) {
      const ym = (yT + yB) / 2, H = yB - yT;
      c.save();
      c.translate(cx, ym);
      c.scale(Math.max(0.2, (mw - 11) / mw), Math.max(0.2, (H - 16) / H));
      c.translate(-cx, -ym);
      path();
      c.fillStyle = `rgba(2,8,14,${0.94 * hollow})`;
      c.fill();
      if (tongue > 0.1 || open > 70) {
        c.clip();
        c.globalAlpha *= hollow;
        c.fillStyle = tongue > 0.1 ? "rgba(255,115,165,.95)" : "rgba(255,110,150,.45)";
        c.beginPath(); c.ellipse(cx, yB - H * 0.12, mw * 0.55, H * 0.34, 0, 0, Math.PI * 2); c.fill();
      }
      c.restore();
    }
    c.restore();
  }

  private drawBlush() {
    const b = this.P.blush.x;
    if (b < 0.03) return;
    const c = this.c;
    c.save();
    c.strokeStyle = `rgba(255,120,180,${b})`; c.lineWidth = 9;
    for (const s of [1, -1] as const) {
      const e = this.eyeBox(s);
      for (let i = 0; i < 3; i++) {
        const x = e.cx + (i - 1) * 24, y = e.cy + e.h / 2 + 34;
        c.beginPath(); c.moveTo(x - 6, y + 12); c.lineTo(x + 8, y - 10); c.stroke();
      }
    }
    c.restore();
  }

  private drawParticles() {
    const c = this.c;
    for (const p of this.parts) {
      const k = p.life / p.max;
      const a = k < 0.12 ? k / 0.12 : 1 - Math.pow((k - 0.12) / 0.88, 2);
      c.save();
      c.globalAlpha = clamp(a, 0, 1) * clamp(this.P.bright.x + 0.2, 0, 1);
      c.translate(p.x, p.y);
      c.rotate(p.rot);
      const s = p.size;
      c.fillStyle = p.hue !== undefined ? `hsl(${p.hue},95%,62%)` : this.rgba(1);
      c.strokeStyle = c.fillStyle;
      switch (p.type) {
        case "heart": {
          const r = 16 * s;
          if (p.hue === undefined) c.fillStyle = "rgb(255,110,175)";
          c.beginPath(); c.moveTo(0, r * 0.9);
          c.bezierCurveTo(-r * 1.35, r * 0.1, -r * 0.95, -r * 0.95, 0, -r * 0.38);
          c.bezierCurveTo(r * 0.95, -r * 0.95, r * 1.35, r * 0.1, 0, r * 0.9); c.fill();
          break;
        }
        case "note": case "zzz": case "bang": case "question": {
          c.font = `800 ${(p.type === "zzz" ? 44 : p.type === "note" ? 56 : 90) * s}px Orbitron, ui-sans-serif, system-ui, sans-serif`;
          c.textAlign = "center"; c.textBaseline = "middle";
          c.fillText(p.text || "", 0, 0);
          break;
        }
        case "tear": case "sweat": case "drop": {
          const r = (p.type === "tear" ? 13 : 10) * s;
          c.fillStyle = p.type === "tear" ? "rgb(120,210,255)" : "rgb(170,235,255)";
          c.beginPath(); c.moveTo(0, -r * 2.2); c.quadraticCurveTo(r * 1.3, -r * 0.2, 0, r); c.quadraticCurveTo(-r * 1.3, -r * 0.2, 0, -r * 2.2); c.fill();
          break;
        }
        case "spark": {
          const R = 20 * s * (0.6 + 0.4 * Math.sin(p.life * 12));
          c.beginPath();
          for (let i = 0; i < 4; i++) {
            const ang = (i * Math.PI) / 2;
            c.lineTo(Math.cos(ang) * R, Math.sin(ang) * R);
            c.lineTo(Math.cos(ang + Math.PI / 4) * R * 0.22, Math.sin(ang + Math.PI / 4) * R * 0.22);
          }
          c.closePath(); c.fill();
          break;
        }
        case "anger": {
          c.strokeStyle = "rgb(255,70,50)"; c.lineWidth = 9 * s;
          for (let i = 0; i < 4; i++) {
            c.save(); c.rotate((i * Math.PI) / 2);
            c.beginPath(); c.arc(22 * s, 22 * s, 18 * s, Math.PI, Math.PI * 1.5); c.stroke(); c.restore();
          }
          break;
        }
        case "puff": {
          c.globalAlpha *= 0.55;
          c.fillStyle = "rgb(210,235,255)";
          c.beginPath(); c.arc(0, 0, (10 + p.life * 38) * s, 0, Math.PI * 2); c.fill();
          break;
        }
        case "star": {
          const R = 18 * s * (0.7 + 0.3 * Math.sin(p.life * 9));
          c.fillStyle = "rgb(255,222,110)";
          c.beginPath();
          for (let i = 0; i < 5; i++) {
            const a1 = (i * 2 * Math.PI) / 5 - Math.PI / 2, a2 = a1 + Math.PI / 5;
            c.lineTo(Math.cos(a1) * R, Math.sin(a1) * R); c.lineTo(Math.cos(a2) * R * 0.45, Math.sin(a2) * R * 0.45);
          }
          c.closePath(); c.fill();
          break;
        }
        case "confetti": c.fillRect(-6 * s, -3 * s, 12 * s, 6 * s); break;
        case "dot": c.beginPath(); c.arc(0, 0, 5 * s, 0, Math.PI * 2); c.fill(); break;
      }
      c.restore();
    }
  }

  private drawBullet() {
    const c = this.c, b = this.bullet;
    const slow = this.fx.timeScale < 0.6;
    c.save();
    c.translate(b.x, b.y);
    const grad = c.createLinearGradient(-320, 0, 0, 0);
    grad.addColorStop(0, "rgba(255,230,160,0)"); grad.addColorStop(1, "rgba(255,230,160,0.9)");
    c.fillStyle = grad;
    c.beginPath(); c.moveTo(-320, 0); c.lineTo(-10, -9); c.lineTo(-10, 9); c.closePath(); c.fill();
    c.fillStyle = "rgb(255,220,140)";
    c.beginPath(); c.roundRect(-40, -13, 62, 26, 12); c.fill();
    c.fillStyle = "rgb(255,255,255)";
    c.beginPath(); c.roundRect(-34, -8, 40, 7, 4); c.fill();
    if (slow) {
      c.strokeStyle = "rgba(255,230,160,0.45)"; c.lineWidth = 5;
      for (let i = 1; i <= 3; i++) { c.beginPath(); c.arc(30, 0, i * 38 + (this.t * 90) % 38, -0.9, 0.9); c.stroke(); }
    }
    c.restore();
  }

  private capsule(x1: number, y1: number, x2: number, y2: number, r: number) {
    const c = this.c;
    const a = Math.atan2(y2 - y1, x2 - x1);
    c.beginPath();
    c.arc(x1, y1, r, a + Math.PI / 2, a + (3 * Math.PI) / 2);
    c.arc(x2, y2, r, a - Math.PI / 2, a + Math.PI / 2);
    c.closePath();
  }

  /** One raised hand: a clean mitten silhouette with a single neon outline (no overlapping strokes). */
  private drawHand(x: number, y: number, mirror: number, wob: number, spread: number) {
    const c = this.c;
    c.save();
    c.translate(x, y);
    c.rotate(wob + mirror * 0.05);
    c.scale(mirror, 1);
    const shapes: (() => void)[] = [];
    shapes.push(() => { c.beginPath(); c.roundRect(-27, 30, 54, 760, 14); });          // forearm
    shapes.push(() => { c.beginPath(); c.roundRect(-46, -52, 92, 104, 30); });          // palm
    const bx = [-32, -11, 11, 32], len = [62, 80, 86, 68], base = [-0.2, -0.065, 0.065, 0.2];
    for (let i = 0; i < 4; i++) {
      const a = base[i] * spread + Math.sin(this.t * 6.5 + i * 1.3) * 0.035;
      shapes.push(() => this.capsule(bx[i], -40, bx[i] + Math.sin(a) * len[i], -40 - Math.cos(a) * len[i], 11));
    }
    const ta = 0.95 + (spread - 1) * 0.6;
    shapes.push(() => this.capsule(38, 0, 38 + Math.sin(ta) * 52, 0 - Math.cos(ta) * 52, 12));  // thumb
    c.lineJoin = "round";
    c.strokeStyle = this.rgba(1);
    c.lineWidth = 15;
    for (const s of shapes) { s(); c.stroke(); }
    c.fillStyle = "#04060b";
    for (const s of shapes) { s(); c.fill(); }
    // neon cuff + status LED
    c.lineWidth = 5;
    c.beginPath(); c.roundRect(-33, 130, 66, 24, 8); c.stroke();
    c.fillStyle = this.rgba(0.5 + 0.5 * Math.sin(this.t * 8));
    c.beginPath(); c.arc(0, 15, 7, 0, Math.PI * 2); c.fill();
    c.restore();
  }

  private drawHands(a: number) {
    const c = this.c;
    const e = clamp(a, 0, 1.08);
    const y = 1040 - 480 * e;
    const wob = Math.sin(this.t * 24) * 0.02 * clamp(e, 0, 1);
    const sp = 1 + Math.sin(this.t * 5) * 0.08;
    c.save();
    c.globalAlpha = clamp(e * 2.5, 0, 1);
    this.drawHand(112, y, 1, wob, sp);
    this.drawHand(688, y, -1, -wob, sp);
    c.restore();
  }

  /* ---------- weather scene ---------- */
  private updateScene(real: number, now: number) {
    const sc = this.scene;
    if (sc.kind === "none") return;
    sc.a = sc.target > sc.a ? Math.min(1, sc.a + real / 0.9) : Math.max(0, sc.a - real / 0.9);
    sc.full = sc.fullT > sc.full ? Math.min(1, sc.full + real / 0.6) : Math.max(0, sc.full - real / 0.6);
    if (sc.a <= 0 && sc.target === 0) { sc.kind = "none"; sc.drops = []; sc.flakes = []; sc.ripples = []; sc.bolt = null; sc.flash = 0; return; }
    const k = sc.kind, I = sc.intensity;
    const floorY = lerp(792, 590, sc.full);
    const rainy = k === "drizzle" || k === "rain" || k === "storm" || k === "sleet";
    const snowy = k === "snow" || k === "sleet";

    // spawn rain
    if (rainy) {
      const base = k === "drizzle" ? 35 + 70 * I : k === "storm" ? 240 + 260 * I : k === "sleet" ? 60 + 90 * I : 90 + 330 * I;
      sc.acc += base * real * sc.a;
      while (sc.acc >= 1 && sc.drops.length < 520) {
        sc.acc -= 1;
        const full = Math.random() < sc.full;
        const wind = k === "storm" ? -90 - 120 * I : -20 - 40 * I;
        const sp = (k === "drizzle" ? 520 : 760) + 480 * I + rnd(0, 160);
        sc.drops.push({
          x: full ? rnd(400 - 190, 400 + 190) : rnd(-60, 860), y: full ? rnd(320, 350) : rnd(-30, 160),
          vx: wind, vy: sp, len: (k === "drizzle" ? 14 : 22) + rnd(0, 20) * (0.5 + I), w: k === "drizzle" ? 2.5 : 3.5,
        });
      }
    } else sc.acc = 0;
    if (snowy && sc.flakes.length < 220 && Math.random() < (k === "sleet" ? 0.25 : 0.4 + I * 0.6) * sc.a * real * 60) {
      const full = Math.random() < sc.full;
      sc.flakes.push({ x: full ? rnd(400 - 200, 400 + 200) : rnd(-20, 820), y: full ? rnd(320, 350) : rnd(-20, 120), vy: rnd(45, 110) * (0.7 + I * 0.5), ph: rnd(0, 6), r: rnd(2.5, 6.5), vx: rnd(-14, 6) });
    }
    for (const d of sc.drops) {
      d.x += d.vx * real; d.y += d.vy * real;
      if (d.y >= floorY && sc.ripples.length < 50 && Math.random() < 0.55) sc.ripples.push({ x: d.x, y: floorY - rnd(0, 6), t: 0 });
    }
    sc.drops = sc.drops.filter((d) => d.y < floorY && d.x > -120);
    for (const f of sc.flakes) { f.y += f.vy * real; f.x += (f.vx + Math.sin(this.t * 1.6 + f.ph) * 22) * real; }
    sc.flakes = sc.flakes.filter((f) => f.y < floorY + 10);
    for (const r of sc.ripples) r.t += real / 0.45;
    sc.ripples = sc.ripples.filter((r) => r.t < 1);

    // lightning
    if (k === "storm") {
      if (!sc.bolt && now > sc.nextBolt && sc.a > 0.6) {
        const baseY = lerp(150, 345, sc.full);
        const x0 = lerp(rnd(90, 710), rnd(260, 540), sc.full);
        const y1 = lerp(rnd(560, 760), rnd(540, 590), sc.full);
        const pts: [number, number][] = [[x0, baseY]];
        const n = 9;
        let x = x0;
        for (let i = 1; i <= n; i++) { x += rnd(-52, 52); pts.push([x, baseY + ((y1 - baseY) * i) / n]); }
        const branches: [number, number][][] = [];
        for (let b = 0; b < 2; b++) {
          const i = 2 + Math.floor(Math.random() * 5);
          let [bx, by] = pts[i];
          const dir = Math.random() < 0.5 ? -1 : 1;
          const br: [number, number][] = [[bx, by]];
          for (let j = 0; j < 4; j++) { bx += dir * rnd(14, 38); by += rnd(26, 52); br.push([bx, by]); }
          branches.push(br);
        }
        sc.bolt = { pts, branches, t: 0 };
        this.onLightning?.(rnd(0.7, 1));
        sc.nextBolt = now + rnd(2800, 6500) / (0.6 + I * 0.6);
      }
    }
    if (sc.bolt) {
      sc.bolt.t += real;
      const t = sc.bolt.t;
      sc.flash = t < 0.07 ? 1 : t < 0.13 ? 0.15 : t < 0.2 ? 0.9 : Math.max(0, 0.6 - (t - 0.2) / 0.35);
      if (t > 0.6) { sc.bolt = null; sc.flash = 0; }
    } else sc.flash = Math.max(0, sc.flash - real * 4);
  }

  private cloud(x: number, y: number, s: number, dark: number, flash: number, alpha: number) {
    const c = this.c;
    const mix = (a: number[], b: number[], k: number) => a.map((v, i) => Math.round(lerp(v, b[i], k)));
    const f = clamp(flash * 0.75, 0, 1);
    const top = mix(mix([210, 226, 244], [82, 92, 122], dark), [236, 240, 255], f);
    const bot = mix(mix([150, 174, 208], [44, 50, 78], dark), [190, 200, 235], f);
    const g = c.createLinearGradient(0, y - 90 * s, 0, y + 55 * s);
    g.addColorStop(0, `rgb(${top})`); g.addColorStop(1, `rgb(${bot})`);
    c.save();
    c.globalAlpha *= alpha;
    c.fillStyle = g;
    c.beginPath();
    c.moveTo(x - 10 * s, y + 10 * s); c.arc(x - 55 * s, y + 10 * s, 45 * s, 0, Math.PI * 2);
    c.moveTo(x + 62 * s, y - 25 * s); c.arc(x, y - 25 * s, 62 * s, 0, Math.PI * 2);
    c.moveTo(x + 108 * s, y + 10 * s); c.arc(x + 60 * s, y + 10 * s, 48 * s, 0, Math.PI * 2);
    c.moveTo(x - 20 * s, y - 10 * s); c.arc(x - 20 * s, y - 2 * s, 38 * s, 0, Math.PI * 2);
    c.roundRect(x - 55 * s, y + 10 * s, 115 * s, 45 * s, 4 * s);
    c.fill();
    c.restore();
  }

  private sun(cx: number, cy: number, r: number, alpha: number) {
    const c = this.c;
    c.save();
    c.globalAlpha *= alpha;
    const glow = c.createRadialGradient(cx, cy, r * 0.6, cx, cy, r * 3.4);
    glow.addColorStop(0, "rgba(255,205,70,.45)"); glow.addColorStop(1, "rgba(255,205,70,0)");
    c.fillStyle = glow; c.beginPath(); c.arc(cx, cy, r * 3.4, 0, Math.PI * 2); c.fill();
    c.strokeStyle = "rgb(255,208,80)"; c.lineWidth = r * 0.14; c.lineCap = "round";
    const n = 12;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + this.t * 0.35;
      const r0 = r * 1.3, r1 = r * (i % 2 ? 1.62 : 1.85) + Math.sin(this.t * 2.6 + i * 1.7) * r * 0.08;
      c.beginPath(); c.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); c.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1); c.stroke();
    }
    const g = c.createRadialGradient(cx - r * 0.3, cy - r * 0.35, r * 0.1, cx, cy, r);
    g.addColorStop(0, "rgb(255,243,170)"); g.addColorStop(1, "rgb(255,176,32)");
    c.fillStyle = g; c.beginPath(); c.arc(cx, cy, r, 0, Math.PI * 2); c.fill();
    c.restore();
  }

  private moon(cx: number, cy: number, r: number, alpha: number) {
    const c = this.c;
    c.save();
    c.globalAlpha *= alpha;
    const glow = c.createRadialGradient(cx, cy, r * 0.5, cx, cy, r * 3);
    glow.addColorStop(0, "rgba(255,244,200,.28)"); glow.addColorStop(1, "rgba(255,244,200,0)");
    c.fillStyle = glow; c.beginPath(); c.arc(cx, cy, r * 3, 0, Math.PI * 2); c.fill();
    c.beginPath(); c.arc(cx, cy, r, 0, Math.PI * 2); c.clip();
    c.fillStyle = "rgb(255,244,200)";
    c.beginPath(); c.rect(cx - r * 2, cy - r * 2, r * 4, r * 4); c.arc(cx + r * 0.52, cy - r * 0.2, r * 0.9, 0, Math.PI * 2);
    c.fill("evenodd");
    c.restore();
  }

  private drawSceneBack() {
    const sc = this.scene, c = this.c;
    const k = sc.kind;
    if (k === "none") return;
    const A = sc.a, F = smooth(sc.full);
    c.save();
    c.globalAlpha = A * clamp(this.P.bright.x + 0.15, 0, 1);
    const fl = sc.flash;
    // sun / moon
    if (k === "clear" || k === "partly") {
      if (sc.day) {
        const x = lerp(k === "partly" ? 90 : 650, k === "partly" ? 330 : 400, F), y = lerp(k === "partly" ? 120 : 150, k === "partly" ? 260 : 285, F);
        this.sun(x, y, lerp(k === "partly" ? 34 : 46, k === "partly" ? 70 : 92, F), 1);
      } else {
        const x = lerp(k === "partly" ? 90 : 650, 400, F), y = lerp(150, 285, F);
        for (const s of sc.stars) {
          c.save();
          c.globalAlpha *= (0.3 + 0.7 * Math.abs(Math.sin(this.t * 1.4 + s.p))) * lerp(0.7, 1, F);
          c.fillStyle = "rgb(255,246,215)";
          const R = 9 * s.s;
          c.translate(s.x, lerp(s.y * 0.5, s.y, F));
          c.beginPath();
          for (let i = 0; i < 4; i++) { const a = (i * Math.PI) / 2; c.lineTo(Math.cos(a) * R, Math.sin(a) * R); c.lineTo(Math.cos(a + Math.PI / 4) * R * 0.2, Math.sin(a + Math.PI / 4) * R * 0.2); }
          c.closePath(); c.fill();
          c.restore();
        }
        this.moon(x, y, lerp(38, 85, F), 1);
      }
    }
    // clouds
    sc.clouds.forEach((cl, i) => {
      const x = lerp(cl.ax, cl.fx, F) + Math.sin(this.t * cl.sp * 0.07 + i * 2) * lerp(26, 10, F);
      const y = lerp(cl.ay, cl.fy, F) + Math.sin(this.t * 0.6 + i) * 3;
      this.cloud(x, y, lerp(cl.as, cl.fs, F), cl.dark, fl, 1);
    });
    // fog
    if (k === "fog") {
      for (let i = 0; i < 5; i++) {
        const y = lerp(150 + i * 120, 250 + i * 70, F);
        const x = 400 + Math.sin(this.t * 0.25 + i * 1.4) * 90;
        const g = c.createRadialGradient(x, y, 10, x, y, 380);
        g.addColorStop(0, "rgba(225,235,245,.30)"); g.addColorStop(1, "rgba(225,235,245,0)");
        c.save(); c.translate(0, y); c.scale(1, 0.2); c.translate(0, -y);
        c.fillStyle = g; c.beginPath(); c.arc(x, y, 380, 0, Math.PI * 2); c.fill();
        c.restore();
      }
    }
    c.restore();
  }

  private drawSceneFront() {
    const sc = this.scene, c = this.c;
    const A = sc.a;
    c.save();
    c.lineCap = "round"; c.lineJoin = "round";
    const bright = clamp(this.P.bright.x + 0.15, 0, 1);
    // rain
    if (sc.drops.length) {
      c.globalAlpha = A * lerp(0.5, 0.65, sc.full) * bright;
      c.strokeStyle = sc.kind === "sleet" ? "rgb(190,225,255)" : "rgb(130,196,255)";
      c.lineWidth = sc.drops[0].w;
      c.beginPath();
      for (const d of sc.drops) {
        const k = d.len / Math.hypot(d.vx, d.vy);
        c.moveTo(d.x, d.y); c.lineTo(d.x - d.vx * k, d.y - d.vy * k);
      }
      c.stroke();
    }
    // splashes
    if (sc.ripples.length) {
      c.strokeStyle = "rgb(150,208,255)"; c.lineWidth = 2.5;
      for (const r of sc.ripples) {
        c.globalAlpha = A * (1 - r.t) * 0.55 * bright;
        c.beginPath(); c.ellipse(r.x, r.y, 3 + r.t * 20, 1 + r.t * 5.5, 0, 0, Math.PI * 2); c.stroke();
      }
    }
    // snow
    if (sc.flakes.length) {
      c.fillStyle = "rgb(245,250,255)";
      c.globalAlpha = A * 0.92 * bright;
      for (const f of sc.flakes) { c.beginPath(); c.arc(f.x, f.y, f.r, 0, Math.PI * 2); c.fill(); }
    }
    // lightning
    const b = sc.bolt;
    if (b) {
      const t = b.t;
      const vis = t < 0.07 ? 1 : t < 0.13 ? 0.15 : t < 0.2 ? 1 : Math.max(0, 1 - (t - 0.2) / 0.3);
      const draw = (pts: [number, number][], w: number) => {
        c.beginPath(); pts.forEach(([x, y], i) => (i ? c.lineTo(x, y) : c.moveTo(x, y))); c.stroke();
        void w;
      };
      c.globalAlpha = vis * bright;
      c.strokeStyle = "rgba(255,236,150,.4)"; c.lineWidth = 26;
      draw(b.pts, 26); for (const br of b.branches) draw(br, 14);
      c.strokeStyle = "rgb(255,252,225)"; c.lineWidth = 8;
      draw(b.pts, 8);
      c.lineWidth = 4; for (const br of b.branches) draw(br, 4);
    }
    if (sc.flash > 0.02) {
      c.globalAlpha = sc.flash * 0.3;
      c.fillStyle = "rgb(225,232,255)";
      c.fillRect(0, 0, 800, 800);
    }
    c.restore();
  }

  /* ---------- on-screen displays ---------- */
  private die(x: number, y: number, size: number, v: number, rot: number) {
    const c = this.c;
    c.save(); c.translate(x, y); c.rotate(rot);
    c.lineWidth = Math.max(10, size * 0.055);
    c.beginPath(); c.roundRect(-size / 2, -size / 2, size, size, size * 0.18); c.stroke();
    const pos: Record<number, [number, number][]> = {
      1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]],
      5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]],
    };
    const sp = size * 0.28;
    for (const [px, py] of pos[clamp(v, 1, 6)]) { c.beginPath(); c.arc(px * sp, py * sp, size * 0.085, 0, Math.PI * 2); c.fill(); }
    c.restore();
  }

  private drawDisplay() {
    const c = this.c, d = this.disp;
    const data = d.data || {};
    c.fillStyle = this.rgba(1); c.strokeStyle = this.rgba(1);
    c.textAlign = "center"; c.textBaseline = "middle";
    c.lineCap = "round"; c.lineJoin = "round";
    const font = (s: number) => `800 ${Math.round(s)}px Orbitron, ui-monospace, Menlo, monospace`;
    const dim = (fn: () => void, a = 0.6) => { c.save(); c.globalAlpha *= a; fn(); c.restore(); };
    switch (d.type) {
      case "clock": {
        const now = new Date();
        let hh = now.getHours() % 12; if (hh === 0) hh = 12;
        const mm = String(now.getMinutes()).padStart(2, "0");
        const colon = Math.floor(this.t * 1.6) % 2 === 0 ? ":" : " ";
        c.font = font(hh >= 10 ? 160 : 180);
        c.fillText(`${hh}${colon}${mm}`, 400, 370);
        dim(() => { c.font = font(40); c.fillText(now.getHours() >= 12 ? "PM" : "AM", 400, 500); });
        dim(() => { c.font = font(26); c.fillText(now.toLocaleDateString(undefined, { weekday: "long" }).toUpperCase(), 400, 590); }, 0.4);
        break;
      }
      case "date": {
        const now = new Date();
        dim(() => { c.font = font(46); c.fillText(now.toLocaleDateString(undefined, { weekday: "long" }).toUpperCase(), 400, 215); }, 0.75);
        c.font = font(250); c.fillText(String(now.getDate()), 400, 405);
        dim(() => { c.font = font(46); c.fillText(`${now.toLocaleDateString(undefined, { month: "long" }).toUpperCase()} ${now.getFullYear()}`, 400, 600); }, 0.75);
        break;
      }
      case "timer": {
        const total = Math.max(1, data.total ?? 1);
        const rem = data.end ? Math.max(0, (data.end - Date.now()) / 1000) : Math.max(0, data.remaining ?? total);
        c.lineWidth = 22;
        dim(() => { c.beginPath(); c.arc(400, 400, 255, 0, Math.PI * 2); c.stroke(); }, 0.22);
        if (rem > 0) { c.beginPath(); c.arc(400, 400, 255, -Math.PI / 2, -Math.PI / 2 + clamp(rem / total, 0, 1) * Math.PI * 2); c.stroke(); }
        const sec = Math.ceil(rem);
        const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
        const txt = h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
        c.font = font(txt.length > 5 ? 96 : txt.length > 4 ? 124 : 150);
        c.fillText(txt, 400, 395);
        if (data.label) dim(() => { c.font = font(28); c.fillText(String(data.label).toUpperCase(), 400, 520); }, 0.55);
        break;
      }
      case "stopwatch": {
        const el = (data.running ? (Date.now() - data.start) / 1000 : data.elapsed || 0);
        const m = Math.floor(el / 60), s = Math.floor(el % 60), t = Math.floor((el * 10) % 10);
        c.font = font(130); c.fillText(`${m}:${String(s).padStart(2, "0")}`, 380, 385);
        c.textAlign = "left"; c.font = font(64); c.fillText(`.${t}`, 640, 420); c.textAlign = "center";
        dim(() => { c.font = font(28); c.fillText(data.running ? "STOPWATCH" : "STOPPED", 400, 520); }, 0.55);
        break;
      }
      case "weather": {
        const big = String(data.big ?? "--");
        c.font = font(big.length > 5 ? 100 : big.length > 4 ? 120 : 150);
        c.fillText(big, 400, 662);
        if (data.small) dim(() => { c.font = font(String(data.small).length > 16 ? 26 : 32); c.fillText(String(data.small), 400, 748); }, 0.7);
        break;
      }
      case "dice": {
        const vals: number[] = data.values || [data.value || 1];
        const size = vals.length > 1 ? 250 : 330;
        vals.forEach((v, i) => this.die(vals.length > 1 ? 400 + (i ? 1 : -1) * 150 : 400, 395, size, v, (data.rot || 0) * (i ? -1 : 1)));
        if (data.label) dim(() => { c.font = font(44); c.fillText(String(data.label), 400, 640); });
        break;
      }
      case "coin": {
        const sx = Math.abs(Math.cos(data.angle || 0));
        c.save(); c.translate(400, 395); c.scale(Math.max(0.05, sx), 1);
        c.lineWidth = 20; c.beginPath(); c.arc(0, 0, 170, 0, Math.PI * 2); c.stroke();
        dim(() => { c.lineWidth = 6; c.beginPath(); c.arc(0, 0, 136, 0, Math.PI * 2); c.stroke(); }, 0.4);
        c.font = font(190); c.fillText(data.face === "T" ? "T" : "H", 0, 8);
        c.restore();
        if (data.label) dim(() => { c.font = font(40); c.fillText(String(data.label), 400, 640); });
        break;
      }
      case "number": {
        const txt = String(data.text ?? "");
        c.font = font(clamp(1500 / Math.max(3, txt.length * 1.15), 70, 230));
        c.fillText(txt, 400, 390);
        if (data.label) dim(() => { c.font = font(String(data.label).length > 18 ? 24 : 32); c.fillText(String(data.label).toUpperCase(), 400, 600); }, 0.6);
        break;
      }
      case "rps": {
        const ch = data.choice as string;
        c.save(); c.translate(400, 400 + (data.bounce || 0));
        c.lineWidth = 18;
        if (ch === "paper") {
          c.beginPath(); c.roundRect(-110, -60, 220, 250, 36); c.stroke();
          for (let i = 0; i < 4; i++) { c.beginPath(); c.roundRect(-100 + i * 52, -190 + (i === 0 || i === 3 ? 40 : 0), 44, 150, 22); c.stroke(); }
          c.beginPath(); c.roundRect(100, 20, 90, 44, 22); c.stroke();
        } else if (ch === "scissors") {
          c.lineWidth = 22;
          c.beginPath(); c.moveTo(-18, 70); c.lineTo(-110, -190); c.moveTo(18, 70); c.lineTo(110, -190); c.stroke();
          c.lineWidth = 16;
          c.beginPath(); c.arc(-62, 140, 54, 0, Math.PI * 2); c.stroke();
          c.beginPath(); c.arc(62, 140, 54, 0, Math.PI * 2); c.stroke();
        } else {
          c.beginPath(); c.roundRect(-130, -110, 260, 250, 70); c.stroke();
          c.lineWidth = 12;
          for (let i = 0; i < 3; i++) { c.beginPath(); c.moveTo(-88 + i * 58, -110); c.lineTo(-88 + i * 58, -30); c.stroke(); }
        }
        c.restore();
        if (data.label) dim(() => { c.font = font(40); c.fillText(String(data.label).toUpperCase(), 400, 690); });
        break;
      }
    }
  }
}
