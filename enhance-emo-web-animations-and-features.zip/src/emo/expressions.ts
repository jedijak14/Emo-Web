export type Kind =
  | "rect" | "arc" | "arcDown" | "line" | "heart" | "star" | "x"
  | "spiral" | "bars" | "vinyl" | "dots" | "ring" | "glass" | "orb" | "squeeze";

export interface Expr {
  kind: Kind;
  kindR?: Kind;
  w: number; h: number; r: number; gap: number; y: number;
  tilt: number; slant: number; topLid: number; botLid: number;
  hR: number; lidR: number; yR: number;
  mouth: number; open: number; smile: number; mw: number; tongue: number;
  blush: number;
  color: [number, number, number];
  bright: number;
}

export const CYAN: [number, number, number] = [62, 244, 255];

export const DEF: Expr = {
  kind: "rect", w: 150, h: 175, r: 46, gap: 310, y: 0,
  tilt: 0, slant: 0, topLid: 0, botLid: 0, hR: 1, lidR: 0, yR: 0,
  mouth: 0, open: 0, smile: 0.5, mw: 90, tongue: 0, blush: 0,
  color: CYAN, bright: 1,
};

export const PRESETS: Record<string, Partial<Expr>> = {
  neutral: {},
  happy: { kind: "arc", w: 140, h: 70, y: 25 },
  joy: { kind: "arc", w: 150, h: 90, y: 5, mouth: 1, open: 0.45, smile: 1, mw: 110 },
  laugh: { kind: "arc", w: 150, h: 90, y: 5, mouth: 1, open: 0.95, smile: 1, mw: 120 },
  content: { kind: "arcDown", w: 140, h: 60, y: -5 },
  sad: { slant: -0.95, h: 150, w: 140, y: 35, topLid: 0.08 },
  cry: { slant: -1, h: 140, w: 140, y: 35, topLid: 0.12, mouth: 1, open: 0.3, smile: -1, mw: 70 },
  angry: { slant: 1, topLid: 0.1, h: 150, w: 155, y: 10, color: [255, 84, 60], gap: 300 },
  furious: { slant: 1, topLid: 0.2, h: 150, w: 170, y: 5, color: [255, 50, 40], gap: 290, mouth: 1, open: 0.5, smile: -1, mw: 110 },
  surprised: { w: 175, h: 225, r: 72, gap: 335, y: -12 },
  scared: { w: 105, h: 135, r: 40, gap: 290, slant: -0.5, y: 25, mouth: 1, open: 0.12, smile: -0.8, mw: 70 },
  terrified: { w: 95, h: 150, r: 45, gap: 280, slant: -0.7, y: 15, mouth: 1, open: 0.5, smile: -0.9, mw: 75 },
  sleepy: { topLid: 0.5, h: 165, y: 22, slant: -0.25 },
  sleep: { kind: "arcDown", w: 140, h: 36, y: 20, bright: 0.55 },
  bored: { topLid: 0.5, slant: 0, h: 160, y: 18 },
  suspicious: { topLid: 0.42, slant: 0.35, h: 160, lidR: 0.12, y: 12 },
  smug: { topLid: 0.38, slant: 0, h: 160, y: 10, mouth: 1, open: 0, smile: 0.9, mw: 90 },
  love: { kind: "heart", w: 200, h: 200, color: [255, 96, 168] },
  excited: { kind: "star", w: 210, h: 210, gap: 330 },
  dizzy: { kind: "spiral", w: 190, h: 190 },
  dead: { kind: "x", w: 150, h: 150 },
  wink: { kindR: "arc", hR: 0.4, yR: 25 },
  cool: { kind: "glass", w: 215, h: 190, gap: 330, y: 0 },
  sick: { color: [150, 255, 120], slant: -0.5, topLid: 0.3, h: 160, y: 30 },
  shy: { w: 120, h: 140, y: 20, blush: 1, slant: -0.45, topLid: 0.1 },
  curious: { hR: 1.35, yR: -18, h: 150, tilt: 6 },
  thinking: { topLid: 0.18, h: 150, w: 140, slant: 0.2 },
  focus: { topLid: 0.42, slant: 0.5, h: 150, w: 150, y: 5 },
  relief: { kind: "arcDown", w: 140, h: 60, y: 0 },
  loading: { kind: "ring", w: 150, h: 150 },
  dots: { kind: "dots", w: 150, h: 150 },
  kiss: { kind: "arcDown", w: 130, h: 50, mouth: 1, open: 0.3, smile: 0, mw: 26, blush: 0.8 },
  silly: { kind: "arc", w: 140, h: 75, y: 15, mouth: 1, open: 0.6, smile: 0.9, mw: 90, tongue: 1 },
  blep: { kind: "arcDown", w: 130, h: 50, mouth: 1, open: 0.35, smile: 0.7, mw: 70, tongue: 1 },
  yawn: { topLid: 0.6, h: 160, y: 25, mouth: 1, open: 1.2, smile: -0.3, mw: 70 },
  squint: { kind: "arc", w: 130, h: 40, y: 20 },
  sneeze: { kind: "arcDown", w: 120, h: 30, y: 15, mouth: 1, open: 1, smile: -0.3, mw: 60 },
  worried: { slant: -0.7, h: 165, y: 22 },
  proud: { kind: "arc", w: 150, h: 80, y: 10, mouth: 1, open: 0, smile: 0.9, mw: 100 },
  eq: { kind: "bars", w: 170, h: 190, gap: 320 },
  vinyl: { kind: "vinyl", w: 190, h: 190, gap: 345 },
  sing: { kind: "arc", w: 150, h: 85, y: 0, mouth: 1, open: 0.6, smile: 0.7, mw: 100 },
  none: {},
  // --- more expressions ---
  listening: { w: 165, h: 200, r: 62, gap: 318, y: -4, hR: 1.28, yR: -24, tilt: 3 },
  carried: { w: 160, h: 195, r: 60, gap: 318, y: 0, mouth: 1, open: 0.32, smile: -0.1, mw: 30 },
  yawnPeak: { kind: "squeeze", w: 150, h: 140, y: 18, mouth: 1, open: 1.75, smile: -0.15, mw: 52 },
  cold: { color: [150, 215, 255], w: 140, h: 150, slant: -0.4, y: 18, mouth: 1, open: 0.1, smile: -0.4, mw: 52 },
  hot: { color: [255, 150, 70], topLid: 0.35, h: 165, y: 22, slant: -0.2, mouth: 1, open: 0.75, smile: -0.2, mw: 62 },
  mischief: { color: [200, 130, 255], topLid: 0.36, slant: 0.6, h: 150, w: 150, y: 10, lidR: 0.1, mouth: 1, open: 0, smile: 1, mw: 82 },
  evil: { color: [200, 130, 255], topLid: 0.4, slant: 0.7, h: 150, w: 150, y: 10, mouth: 1, open: 0.8, smile: 1, mw: 100 },
  pleading: { kind: "orb", w: 215, h: 215, gap: 322, y: 5, mouth: 1, open: 0.12, smile: -0.5, mw: 30 },
  wow: { kind: "orb", w: 205, h: 205, gap: 335, y: -6, mouth: 1, open: 0.55, smile: 0, mw: 28 },
  confused: { hR: 0.7, yR: 14, h: 165, tilt: -4, mouth: 1, open: 0, smile: -0.35, mw: 60 },
  nervous: { w: 120, h: 150, slant: -0.6, y: 20, mouth: 1, open: 0, smile: -0.2, mw: 70 },
  dreamy: { kind: "arc", w: 145, h: 80, y: 12, mouth: 1, open: 0, smile: 0.9, mw: 58, blush: 0.8 },
  disgusted: { color: [170, 235, 120], topLid: 0.42, slant: 0.15, h: 150, y: 15, mouth: 1, open: 0, smile: -1, mw: 92 },
  annoyed: { color: [255, 150, 90], topLid: 0.44, slant: 0.65, h: 140, y: 14, mouth: 1, open: 0, smile: -0.7, mw: 80 },
  whistle: { kind: "arcDown", w: 135, h: 55, y: 0, mouth: 1, open: 0.32, smile: 0, mw: 20 },
  hungry: { kind: "orb", w: 190, h: 190, gap: 320, y: 8, mouth: 1, open: 0.5, smile: 0.6, mw: 60, tongue: 1 },
};

export interface MenuItem { id: string; label: string; group: string; }
const G = (group: string, items: [string, string][]): MenuItem[] => items.map(([id, label]) => ({ id, label, group }));
export const MENU: MenuItem[] = [
  ...G("Happy", [["hello", "Hello"], ["happy", "Happy"], ["laugh", "Laugh"], ["love", "Love"], ["excited", "Excited"], ["wink", "Wink"], ["kiss", "Kiss"], ["silly", "Silly"], ["cool", "Cool"], ["proud", "Proud"], ["shy", "Shy"], ["dreamy", "Dreamy"], ["pleading", "Puppy eyes"], ["whistle", "Whistle"], ["mischief", "Mischief"]]),
  ...G("Thinking", [["curious", "Curious"], ["think", "Thinking"], ["suspicious", "Suspicious"], ["confused", "Confused"], ["bored", "Bored"], ["eyeroll", "Eye roll"], ["heard", "Wake word"]]),
  ...G("Big feelings", [["surprised", "Surprised"], ["scared", "Scared"], ["nervous", "Nervous"], ["handsup", "Hands up"], ["dodge", "Dodge"], ["angry", "Angry"], ["annoyed", "Annoyed"], ["disgusted", "Disgusted"], ["sad", "Sad"], ["cry", "Cry"]]),
  ...G("Body", [["sick", "Sneeze"], ["dizzy", "Dizzy"], ["dead", "Play dead"], ["yawn", "Yawn"], ["stretch", "Stretch"], ["sleep", "Sleep"], ["cold", "Cold"], ["hot", "Hot"], ["glitch", "Glitch"]]),
  ...G("Shows", [["birthday", "Birthday"], ["dance", "Dance"]]),
];
