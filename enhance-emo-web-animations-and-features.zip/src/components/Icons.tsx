import type { ReactNode } from "react";

// A small hand-drawn icon set (one consistent 24px line style) instead of emoji.
const P: Record<string, ReactNode> = {
  mic: <><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3" /></>,
  micOff: <><path d="M9 6.2V6a3 3 0 0 1 6 0v5.5M9 9.5V11a3 3 0 0 0 4.6 2.5" /><path d="M5.5 11.5a6.5 6.5 0 0 0 10.2 5.3M18.5 11.5c0 .9-.2 1.7-.5 2.5M12 18v3M4 4l16 16" /></>,
  camera: <><path d="M4 8.5A1.5 1.5 0 0 1 5.5 7H8l1.3-2h5.4L16 7h2.5A1.5 1.5 0 0 1 20 8.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 17.5z" /><circle cx="12" cy="13" r="3.4" /></>,
  cameraOff: <><path d="M9.3 5h5.4L16 7h2.5A1.5 1.5 0 0 1 20 8.5v8M7 7H5.5A1.5 1.5 0 0 0 4 8.5v9A1.5 1.5 0 0 0 5.5 19h12" /><path d="M10 10.2a3.4 3.4 0 0 0 4.3 4.3M4 4l16 16" /></>,
  music: <><path d="M9 18V6l10-2v12" /><circle cx="6.5" cy="18" r="2.5" /><circle cx="16.5" cy="16" r="2.5" /></>,
  weather: <><circle cx="8" cy="8" r="2.8" /><path d="M8 2.6V3.8M2.6 8h1.2M4.2 4.2l.8.8M11.8 4.2l-.8.8" /><path d="M8.5 19.5h9a3.3 3.3 0 0 0 .4-6.6 4.8 4.8 0 0 0-9.2 1.1 2.8 2.8 0 0 0-.2 5.5z" /></>,
  flask: <><path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 18l-5-9V3" /><path d="M7.4 15h9.2" /></>,
  help: <><circle cx="12" cy="12" r="9" /><path d="M9.5 9.4a2.6 2.6 0 0 1 5 .9c0 1.7-2.5 2.2-2.5 3.8M12 17.3v.1" /></>,
  settings: <><path d="M4 7h9M17 7h3M4 17h3M11 17h9" /><circle cx="15" cy="7" r="2" /><circle cx="9" cy="17" r="2" /></>,
  expand: <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />,
  play: <path d="M8 5.5v13l11-6.5z" fill="currentColor" />,
  pause: <><rect x="7" y="5" width="3.6" height="14" rx="1" fill="currentColor" /><rect x="13.4" y="5" width="3.6" height="14" rx="1" fill="currentColor" /></>,
  prev: <><path d="M18 5.5v13L8.5 12z" fill="currentColor" /><path d="M6 5.5v13" /></>,
  next: <><path d="M6 5.5v13L15.5 12z" fill="currentColor" /><path d="M18 5.5v13" /></>,
  close: <path d="M6 6l12 12M18 6L6 18" />,
  timer: <><circle cx="12" cy="13.5" r="7" /><path d="M12 10v3.8l2.3 1.4M9.5 3h5" /></>,
  search: <><circle cx="11" cy="11" r="6" /><path d="M16 16l4.5 4.5" /></>,
  pin: <><path d="M12 21s6-5.6 6-11a6 6 0 0 0-12 0c0 5.4 6 11 6 11z" /><circle cx="12" cy="10" r="2.2" /></>,
  sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M18.7 5.3l-1.6 1.6M6.9 17.1l-1.6 1.6" /></>,
  moon: <path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z" />,
  cloud: <path d="M7 18.5h10.2a3.8 3.8 0 0 0 .5-7.6 5.6 5.6 0 0 0-10.7 1.4A3.1 3.1 0 0 0 7 18.5z" />,
  partly: <><circle cx="8.5" cy="8.5" r="2.8" /><path d="M8.5 3v1.2M3 8.5h1.2M4.6 4.6l.9.9M12.4 4.6l-.9.9" /><path d="M9 19h8a3.2 3.2 0 0 0 .4-6.4 4.6 4.6 0 0 0-8.8 1A2.7 2.7 0 0 0 9 19z" /></>,
  rain: <><path d="M7 14.5h10.2a3.6 3.6 0 0 0 .5-7.2 5.4 5.4 0 0 0-10.3 1.3A3 3 0 0 0 7 14.5z" /><path d="M8.5 17.5l-1 2.5M12.5 17.5l-1 2.5M16.5 17.5l-1 2.5" /></>,
  storm: <><path d="M7 13.5h10.2a3.6 3.6 0 0 0 .5-7.2 5.4 5.4 0 0 0-10.3 1.3A3 3 0 0 0 7 13.5z" /><path d="M12.8 14.5l-2.3 3.4h3l-2 3.6" /></>,
  snow: <><path d="M7 14h10.2a3.6 3.6 0 0 0 .5-7.2 5.4 5.4 0 0 0-10.3 1.3A3 3 0 0 0 7 14z" /><path d="M8.5 17.5v.1M12 19.5v.1M15.5 17.5v.1M12 16.5v.1" strokeWidth="2.4" /></>,
  fog: <><path d="M5 9h9M8 13h11M4 17h10M16 17h4M14 9h5" /></>,
  drop: <path d="M12 3.5s6 6.2 6 10.3a6 6 0 0 1-12 0C6 9.7 12 3.5 12 3.5z" />,
  wind: <path d="M3 9h11a3 3 0 1 0-3-3M3 14h15a3 3 0 1 1-3 3M3 19h7" />,
  therm: <path d="M10 14.5V5a2 2 0 0 1 4 0v9.5a4 4 0 1 1-4 0zM12 9v7" />,
  volume: <path d="M4 9.5v5h3.5l4.5 4v-13l-4.5 4zM15.5 9a4 4 0 0 1 0 6M17.8 6.7a7.3 7.3 0 0 1 0 10.6" />,
  stopwatch: <><circle cx="12" cy="13.5" r="7" /><path d="M12 13.5L15 10M10 3h4M12 3v3.5" /></>,
  check: <path d="M5 12.5l4.5 4.5L19 7.5" />,
  face: <><rect x="3.5" y="4.5" width="17" height="15" rx="4.5" /><path d="M8.5 10v2.2M15.5 10v2.2M9.5 15.5q2.5 1.6 5 0" /></>,
};

export function Icon({ name, size = 20, className = "", stroke = 1.7 }: { name: keyof typeof P | string; size?: number; className?: string; stroke?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      {P[name] ?? null}
    </svg>
  );
}

export function weatherIcon(kind: string, day = true): string {
  if (kind === "clear") return day ? "sun" : "moon";
  if (kind === "partly") return "partly";
  if (kind === "drizzle" || kind === "rain") return "rain";
  if (kind === "sleet") return "snow";
  return kind in P ? kind : "cloud";
}
