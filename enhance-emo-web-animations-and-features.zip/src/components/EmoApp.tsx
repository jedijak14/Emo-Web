"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { EmoHead, type TouchKind } from "./EmoHead";
import { Icon, weatherIcon } from "./Icons";
import { EmoEngine } from "../emo/engine";
import { Brain } from "../emo/brain";
import { MusicPlayer, searchTracks, type PlayerState, type Track } from "../emo/music";
import { MicMeter, SpeechListener } from "../emo/voice";
import { Vision, EMPTY_FACE } from "../emo/vision";
import { hasWake, parse, setWakeWord, wakeWord as initialWake, type Cmd } from "../emo/commands";
import { MENU } from "../emo/expressions";
import { SAMPLE, fmtTemp, fmtWind, resolveUnits, type Units, type WeatherInfo } from "../emo/weather";
import * as snd from "../emo/sound";
import * as tts from "../emo/speak";

type Panel = "none" | "music" | "weather" | "lab" | "help" | "settings";

function fmt(n: number) { const h = Math.floor(n / 3600), m = Math.floor((n % 3600) / 60), s = Math.floor(n % 60); return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`; }

function useStored<T>(key: string, init: T): [T, (v: T) => void] {
  const [v, setV] = useState<T>(() => {
    try { const s = localStorage.getItem(key); return s === null ? init : (JSON.parse(s) as T); } catch { return init; }
  });
  const set = useCallback((n: T) => { setV(n); try { localStorage.setItem(key, JSON.stringify(n)); } catch { /* ignore */ } }, [key]);
  return [v, set];
}

interface Home { lat: number; lon: number; name: string }

export default function EmoApp() {
  const [started, setStarted] = useState(false);
  const [wantMic, setWantMic] = useState(true);
  const [wantCam, setWantCam] = useState(true);
  const [micOn, setMicOn] = useState(false);
  const [listening, setListening] = useState(false);
  const [camOn, setCamOn] = useState(false);
  const [visionMode, setVisionMode] = useState("off");
  const [showCam, setShowCam] = useStored("emo.showcam", true);
  const [panel, setPanel] = useState<Panel>("none");
  const [panelH, setPanelH] = useState(0);
  const [uiVisible, setUiVisible] = useState(true);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Track[]>([]);
  const [searching, setSearching] = useState(false);
  const [ps, setPs] = useState<PlayerState>({ status: "idle", full: false });
  const [prog, setProg] = useState({ pos: 0, dur: 0 });
  const [apiKey, setApiKey] = useStored("emo.ytkey", "");
  const [muted, setMuted] = useStored("emo.muted", false);
  const [voiceReplies, setVoiceReplies] = useStored("emo.voice", true);
  const [units, setUnits] = useStored<Units>("emo.units", "auto");
  const [testMode, setTestMode] = useStored("emo.test", false);
  const [liveWeather, setLiveWeather] = useStored("emo.live", false);
  const [wakeSaved, setWakeSaved] = useStored("emo.wake", initialWake);
  const [wakeInput, setWakeInput] = useState(wakeSaved);
  const [home, setHome] = useStored<Home | null>("emo.home", null);
  const [placeInput, setPlaceInput] = useState("");
  const [wBusy, setWBusy] = useState(false);
  const [wCard, setWCard] = useState<{ info: WeatherInfo; text: string } | null>(null);
  const [vol, setVol] = useState(80);
  const [timerInfo, setTimerInfo] = useState<{ remaining: number; total: number; label?: string } | null>(null);
  const [toast, setToast] = useState("");
  const [box, setBox] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [known, setKnown] = useState(0);
  const [djOn, setDjOn] = useState(false);

  const engineRef = useRef<EmoEngine | null>(null);
  const brainRef = useRef<Brain | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const panelEl = useRef<HTMLDivElement>(null);
  const resultsRef = useRef<Track[]>([]);
  const panelRef = useRef<Panel>("none");
  const apiRef = useRef(apiKey);
  const homeRef = useRef(home);
  const unitsRef = useRef(units);
  const voiceRef = useRef(voiceReplies);
  const awakeUntil = useRef(0);
  const duckT = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const toastT = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const cardT = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const prevStatus = useRef("idle");
  const boxT = useRef(0);
  const wCache = useRef<{ key: string; at: number; info: WeatherInfo } | null>(null);

  const music = useMemo(() => new MusicPlayer(), []);
  const vision = useMemo(() => new Vision(), []);
  const mic = useMemo(() => new MicMeter(), []);
  const speech = useMemo(() => new SpeechListener(), []);

  resultsRef.current = results;
  panelRef.current = panel;
  apiRef.current = apiKey;
  homeRef.current = home;
  unitsRef.current = units;
  voiceRef.current = voiceReplies;

  const say = useCallback((t: string, speak = true) => {
    setToast(t);
    clearTimeout(toastT.current);
    toastT.current = setTimeout(() => setToast((c) => (c === t ? "" : c)), Math.min(10000, Math.max(3800, t.length * 75)));
    if (speak && voiceRef.current) {
      tts.speak(t);
      speech.ignoreUntil = performance.now() + 1500 + t.length * 80;
    }
  }, [speech]);

  /* ---------- weather ---------- */
  const fetchWeather = useCallback(async (q: { place?: string; lat?: number; lon?: number; name?: string }): Promise<WeatherInfo | { error: string }> => {
    const qs = q.place ? `q=${encodeURIComponent(q.place)}` : q.lat !== undefined ? `lat=${q.lat}&lon=${q.lon}${q.name ? `&name=${encodeURIComponent(q.name)}` : ""}` : "";
    const key = qs || "ip";
    const c = wCache.current;
    if (c && c.key === key && Date.now() - c.at < 5 * 60_000) return c.info;
    try {
      const r = await fetch(`/api/weather${qs ? `?${qs}` : ""}`);
      const j = await r.json();
      if (!r.ok) return { error: j.message || "I couldn't get the weather." };
      wCache.current = { key, at: Date.now(), info: j as WeatherInfo };
      return j as WeatherInfo;
    } catch {
      return { error: "I can't reach the weather service. Check your connection." };
    }
  }, []);

  const geolocate = useCallback(() => new Promise<{ lat: number; lon: number } | null>((res) => {
    if (!navigator.geolocation) return res(null);
    navigator.geolocation.getCurrentPosition((p) => res({ lat: p.coords.latitude, lon: p.coords.longitude }), () => res(null), { timeout: 4500, maximumAge: 600_000 });
  }), []);

  /** Weather for a place name, else the saved home, else GPS, else a guess from the network. */
  const getWeather = useCallback(async (place?: string): Promise<WeatherInfo | { error: string }> => {
    if (place) return fetchWeather({ place });
    const h = homeRef.current;
    if (h) return fetchWeather({ lat: h.lat, lon: h.lon, name: h.name });
    const g = await geolocate();
    if (g) {
      const r = await fetchWeather({ lat: g.lat, lon: g.lon });
      if (!("error" in r)) setHome({ lat: g.lat, lon: g.lon, name: r.place });
      return r;
    }
    return fetchWeather({});
  }, [fetchWeather, geolocate, setHome]);

  const showWeatherCard = useCallback((info: WeatherInfo | null, text?: string) => {
    clearTimeout(cardT.current);
    if (!info) { setWCard(null); return; }
    setWCard({ info, text: text || "" });
    cardT.current = setTimeout(() => setWCard(null), 16000);
  }, []);

  /* ---------- camera / mic ---------- */
  const enableCam = useCallback(async () => {
    if (!videoRef.current) return false;
    setVisionMode("loading");
    const ok = await vision.start(videoRef.current);
    if (!ok) { setVisionMode("off"); say("Camera permission was blocked.", false); return false; }
    setCamOn(true);
    setKnown(vision.remembered);
    return true;
  }, [vision, say]);

  const disableCam = useCallback(() => {
    vision.stop();
    setCamOn(false);
    setVisionMode("off");
    setBox(null);
    brainRef.current?.onVision(EMPTY_FACE);
  }, [vision]);

  const enableMic = useCallback(async () => {
    const ok = await mic.start();
    if (!ok) { say("Microphone permission was blocked.", false); return false; }
    setMicOn(true);
    if (speech.supported) speech.start();
    else say("Voice commands need Chrome, Edge or Safari. You can type commands instead.", false);
    return true;
  }, [mic, speech, say]);

  const disableMic = useCallback(() => {
    speech.stop(); mic.stop(); setMicOn(false); setListening(false);
  }, [mic, speech]);

  /* ---------- music ---------- */
  const playTrack = useCallback((t: Track) => {
    const b = brainRef.current;
    music.play(t, resultsRef.current);
    if (b && !b.musicOn) b.act("searching");
  }, [music]);

  const doSearch = useCallback(async (q: string, autoplay = false) => {
    setSearching(true);
    try {
      const tracks = await searchTracks(q, apiRef.current);
      setResults(tracks);
      resultsRef.current = tracks;
      if (autoplay && tracks.length) { music.play(tracks[0], tracks); }
      return tracks.length;
    } catch {
      setResults([]);
      say("I couldn't reach the music catalogue.", false);
      return 0;
    } finally { setSearching(false); }
  }, [say, music]);

  /* ---------- engine ready ---------- */
  const onEngine = useCallback((engine: EmoEngine) => {
    engineRef.current = engine;
    const brain = new Brain(engine);
    brainRef.current = brain;
    brain.sleeping = true;
    engine.setExpr("sleep");
    engine.look(0, 0.3);
    brain.onTimerChange = setTimerInfo;
    brain.hooks = {
      search: doSearch,
      stopMusic: () => music.stop(),
      pauseMusic: () => music.pause(),
      resumeMusic: () => music.resume(),
      nextTrack: () => music.next(),
      prevTrack: () => music.prev(),
      volume: (d) => { const v = Math.max(0, Math.min(100, music.volume + d * 20)); music.setVolume(v); setVol(v); },
      pick: (n) => { const t = resultsRef.current[n - 1]; if (t) playTrack(t); },
      camera: (on) => { if (on) enableCam(); else disableCam(); },
      remember: async () => {
        if (!vision.stream) { const ok = await enableCam(); if (!ok) return false; await new Promise((r) => setTimeout(r, 2500)); }
        const ok = await vision.enroll();
        setKnown(vision.remembered);
        return ok;
      },
      forget: () => { vision.forget(); setKnown(0); },
      getWeather,
      showWeather: showWeatherCard,
      say,
      units: () => resolveUnits(unitsRef.current),
      setMute: (on) => setMuted(on),
    };
    brain.start();
    mic.onLevel = (energy, onset) => {
      if (brain.djSrc === "yt") { engine.dj.energy = energy; if (onset) engine.djOnset(); }
      else engine.dj.energy = 0.45;
    };
    vision.onFace = (f) => { brain.knownCount = vision.remembered; brain.onVision(f); };
    vision.onBox = (b) => {
      const n = performance.now();
      if (n - boxT.current > 100) { boxT.current = n; setBox(b); }
    };
    const t = setInterval(() => { setVisionMode(vision.mode); setDjOn(brain.musicOn); }, 500);
    (engine as unknown as { __cleanup: () => void }).__cleanup = () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doSearch, music, playTrack, enableCam, disableCam, vision, mic, getWeather, showWeatherCard, say]);

  useEffect(() => {
    music.onChange = (s) => {
      setPs(s);
      const b = brainRef.current;
      const prev = prevStatus.current;
      prevStatus.current = s.status;
      if (s.status === "paused" && s.note) say(s.note, false);
      if (!b) return;
      if (s.status === "playing") b.startDj("yt", 118);
      else if ((s.status === "paused" || s.status === "idle") && b.musicOn && b.djSrc === "yt") b.stopDj();
      if (prev === "loading" && s.status === "idle" && !b.musicOn) { b.act("notfound"); if (s.note) say(s.note, false); }
    };
    music.onEnded = () => music.next();
    speech.onState = (l, err) => {
      setListening(l);
      if (err === "denied") { setMicOn(false); say("Speech recognition was blocked.", false); }
    };
    // "Hey Emo": react the moment the wake word shows up in the live transcript
    speech.onInterim = (t) => {
      if (!hasWake(t)) return;
      brainRef.current?.wakeHeard(7000);
      if (music.state.status === "playing") {
        music.duck(true);
        clearTimeout(duckT.current);
        duckT.current = setTimeout(() => music.duck(false), 6000);
      }
    };
    speech.onFinal = (t) => {
      const b = brainRef.current;
      if (!b) return;
      const now = Date.now();
      const { woke, cmd } = parse(t, {
        requireWake: now > awakeUntil.current,
        hasResults: resultsRef.current.length > 0 && panelRef.current === "music",
      });
      if (cmd) {
        awakeUntil.current = 0;
        b.exec(cmd);
        clearTimeout(duckT.current);
        duckT.current = setTimeout(() => music.duck(false), 2200);
      } else if (woke) {
        // only the wake word: keep listening for the actual request
        awakeUntil.current = now + 7000;
        b.wakeHeard(7000);
      }
    };
    return () => { music.stop(); };
  }, [music, speech, say]);

  useEffect(() => { music.apiKey = apiKey; }, [apiKey, music]);
  useEffect(() => { snd.setMuted(muted); }, [muted]);
  useEffect(() => { tts.setSpeakEnabled(voiceReplies); }, [voiceReplies]);
  useEffect(() => { setWakeWord(wakeSaved); }, [wakeSaved]);

  // live weather backdrop
  useEffect(() => {
    const b = brainRef.current;
    if (!started || !b) return;
    if (!liveWeather) { b.setAmbient(null); return; }
    let dead = false;
    const load = async () => {
      const r = await getWeather();
      if (!dead && !("error" in r)) b.setAmbient(r);
    };
    load();
    const t = setInterval(load, 20 * 60_000);
    return () => { dead = true; clearInterval(t); };
  }, [liveWeather, started, getWeather, units]);

  // song progress
  useEffect(() => {
    if (ps.status !== "playing") return;
    const t = setInterval(() => setProg({ pos: music.position, dur: music.duration }), 500);
    return () => clearInterval(t);
  }, [ps.status, music]);

  // keep EMO clear of whichever panel is open
  useEffect(() => {
    const el = panelEl.current;
    if (!el || panel === "none") { setPanelH(0); return; }
    const ro = new ResizeObserver(() => setPanelH(el.offsetHeight));
    ro.observe(el);
    setPanelH(el.offsetHeight);
    return () => ro.disconnect();
  }, [panel, started]);

  // auto hide UI
  useEffect(() => {
    let t: ReturnType<typeof setTimeout>;
    const show = () => { setUiVisible(true); clearTimeout(t); t = setTimeout(() => setUiVisible(false), 6000); };
    show();
    window.addEventListener("pointermove", show);
    window.addEventListener("pointerdown", show);
    window.addEventListener("keydown", show);
    return () => { window.removeEventListener("pointermove", show); window.removeEventListener("pointerdown", show); window.removeEventListener("keydown", show); clearTimeout(t); };
  }, []);

  // real shaking of a phone/tablet: needs several hard spikes in a row
  useEffect(() => {
    const spikes: number[] = [];
    let last = 0;
    const h = (e: DeviceMotionEvent) => {
      const a = e.accelerationIncludingGravity;
      if (!a) return;
      const m = Math.abs(Math.hypot(a.x || 0, a.y || 0, a.z || 0) - 9.8);
      const n = Date.now();
      if (m > 16) spikes.push(n);
      while (spikes.length && n - spikes[0] > 900) spikes.shift();
      if (spikes.length >= 4 && n - last > 3500) { last = n; spikes.length = 0; brainRef.current?.touch("shake"); }
    };
    window.addEventListener("devicemotion", h);
    return () => window.removeEventListener("devicemotion", h);
  }, []);

  // default: hide the camera preview on small screens
  useEffect(() => { if (window.innerWidth < 640 && localStorage.getItem("emo.showcam") === null) setShowCam(false); }, [setShowCam]);

  // if Test Mode is switched off while the lab is open, close it
  useEffect(() => { if (!testMode && panel === "lab") setPanel("none"); }, [testMode, panel]);

  /* ---------- start ---------- */
  const wake = async () => {
    snd.initAudio();
    setStarted(true);
    brainRef.current?.act("wake");
    if (wantMic) await enableMic();
    if (wantCam) await enableCam();
  };

  const submit = (text: string) => {
    const b = brainRef.current;
    const q = text.trim();
    if (!b || !q) return;
    snd.initAudio();
    const { cmd } = parse(q, { requireWake: false, hasResults: resultsRef.current.length > 0 });
    if (cmd && cmd.t === "act" && !testMode) {
      say("I only do that when you ask out loud, or turn on Test Mode in Settings.", false);
      return;
    }
    if (cmd && cmd.t !== "unknown") b.exec(cmd);
    else b.exec({ t: "play", q: q.replace(new RegExp(`^(${wakeWord()}[, ]*)`, "i"), "") } as Cmd);
  };
  const wakeWord = () => wakeSaved.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  const exec = (c: Cmd) => { snd.initAudio(); brainRef.current?.exec(c); };
  const toggle = (p: Panel) => setPanel((cur) => (cur === p ? "none" : p));
  const fullscreen = () => { if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen?.(); };

  const askWeather = async (place?: string, useGps = false) => {
    snd.initAudio();
    if (useGps) {
      setWBusy(true);
      const g = await geolocate();
      setWBusy(false);
      if (!g) { say("I couldn't get your location. Type a city instead.", false); return; }
      const r = await fetchWeather({ lat: g.lat, lon: g.lon });
      if ("error" in r) { say(r.error, false); return; }
      setHome({ lat: g.lat, lon: g.lon, name: r.place });
      exec({ t: "weather", topic: "general" });
      return;
    }
    if (place) {
      setWBusy(true);
      const r = await fetchWeather({ place });
      setWBusy(false);
      if ("error" in r) { say(r.error, false); brainRef.current?.act("sad"); return; }
      setHome({ lat: r.lat ?? 0, lon: r.lon ?? 0, name: r.place });
      exec({ t: "weather", topic: "general" });
      return;
    }
    exec({ t: "weather", topic: "general" });
  };

  const playing = ps.status === "playing" || ps.status === "paused" || ps.status === "loading";
  const dockShown = uiVisible || panel !== "none" || !started;
  const u = resolveUnits(units);
  const DOCK = 84;
  const bottomInset = DOCK + (panel !== "none" && started ? panelH + 14 : 0);

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#05060a] text-cyan-50">
      <EmoHead
        onEngine={onEngine}
        onTouch={(k: TouchKind) => { snd.initAudio(); brainRef.current?.touch(k); }}
        onDrag={(dx, dy) => brainRef.current?.drag(dx, dy)}
        bottomInset={bottomInset}
        topInset={56}
      />

      {/* top bar: status · now playing · (camera is its own card below) */}
      <div className={`pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start gap-2 p-3 transition-opacity duration-500 ${started && !uiVisible && !playing ? "opacity-0" : "opacity-100"}`}>
        <div className="pointer-events-auto flex shrink-0 flex-wrap items-center gap-1.5">
          <span title="Microphone" className={`flex h-8 items-center gap-1.5 rounded-full px-2.5 text-[11px] glass ${micOn ? "text-cyan-200" : "text-white/40"}`}>
            <span className={`h-2 w-2 rounded-full ${micOn && listening ? "animate-pulse bg-cyan-300 shadow-[0_0_8px_#3ef4ff]" : micOn ? "bg-cyan-700" : "bg-white/20"}`} />
            <span className="hidden sm:inline">mic</span>
          </span>
          <span title="Camera" className={`flex h-8 items-center gap-1.5 rounded-full px-2.5 text-[11px] glass ${camOn ? "text-cyan-200" : "text-white/40"}`}>
            <span className={`h-2 w-2 rounded-full ${camOn ? "bg-cyan-300 shadow-[0_0_8px_#3ef4ff]" : "bg-white/20"}`} />
            <span className="hidden sm:inline">cam</span>
          </span>
          {timerInfo && (
            <button onClick={() => exec({ t: "timer-show" })} className="flex h-8 items-center gap-1.5 rounded-full px-2.5 text-[11px] text-cyan-200 glass">
              <Icon name="timer" size={14} /> {fmt(timerInfo.remaining)}
            </button>
          )}
          {testMode && <span className="flex h-8 items-center rounded-full border border-amber-300/40 bg-amber-300/10 px-2.5 text-[10px] font-semibold uppercase tracking-wider text-amber-200">Test mode</span>}
        </div>

        <div className="pointer-events-none flex min-w-0 flex-1 flex-col items-center gap-2">
          {playing && ps.track && (
            <div className="emo-fade-up pointer-events-auto flex w-full max-w-md items-center gap-2.5 rounded-2xl p-2 pr-2.5 glass">
              {ps.track.art && /* eslint-disable-next-line @next/next/no-img-element */ <img src={ps.track.art} alt="" className="h-10 w-10 shrink-0 rounded-lg object-cover" />}
              <div className="min-w-0 flex-1">
                <div className="truncate text-xs font-semibold">{ps.track.title}</div>
                <div className="truncate text-[11px] text-cyan-100/60">
                  {ps.track.artist}{ps.status === "loading" ? " · loading…" : ps.note ? ` · ${ps.note}` : ""}
                </div>
                {ps.status !== "loading" && prog.dur > 0 && (
                  <div className="mt-1 h-1 cursor-pointer overflow-hidden rounded-full bg-white/10" onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); music.seek((e.clientX - r.left) / r.width); }}>
                    <div className="h-full rounded-full bg-cyan-300" style={{ width: `${Math.min(100, (prog.pos / prog.dur) * 100)}%` }} />
                  </div>
                )}
              </div>
              <div className="flex shrink-0 items-center">
                <IconBtn label="Previous" onClick={() => music.prev()}><Icon name="prev" size={16} /></IconBtn>
                <IconBtn label={ps.status === "playing" ? "Pause" : "Play"} onClick={() => (ps.status === "playing" ? music.pause() : music.resume())}><Icon name={ps.status === "playing" ? "pause" : "play"} size={18} /></IconBtn>
                <IconBtn label="Next" onClick={() => music.next()}><Icon name="next" size={16} /></IconBtn>
                <IconBtn label="Stop" onClick={() => music.stop()}><Icon name="close" size={16} /></IconBtn>
              </div>
            </div>
          )}
          {!playing && djOn && (
            <div className="emo-fade-up pointer-events-auto flex items-center gap-2 rounded-full py-1 pl-3 pr-1.5 text-xs glass">
              <Icon name="music" size={14} className="text-cyan-300" /> EMO&apos;s own beat
              <IconBtn label="Stop" onClick={() => exec({ t: "stop" })}><Icon name="close" size={14} /></IconBtn>
            </div>
          )}
          {toast && <div className="emo-fade-up pointer-events-auto max-w-md rounded-xl px-4 py-2 text-center text-xs leading-snug glass">{toast}</div>}
        </div>

        <div className="hidden w-[7.5rem] shrink-0 sm:block" aria-hidden />
      </div>

      {/* weather card (left) */}
      {wCard && (
        <div className="emo-fade-up absolute left-3 top-14 z-20 w-[min(17rem,70vw)] rounded-2xl p-3 glass">
          <div className="flex items-start gap-3">
            <Icon name={weatherIcon(wCard.info.kind, wCard.info.isDay)} size={38} stroke={1.4} className="shrink-0 text-cyan-300" />
            <div className="min-w-0 flex-1">
              <div className="text-2xl font-semibold leading-none" style={{ fontFamily: "Orbitron, ui-sans-serif" }}>{fmtTemp(wCard.info.tempC, u)}<span className="ml-0.5 text-sm text-cyan-100/60">{u.toUpperCase()}</span></div>
              <div className="mt-1 truncate text-xs text-cyan-50/80">{wCard.info.desc}</div>
              {wCard.info.place && <div className="flex items-center gap-1 truncate text-[11px] text-cyan-100/50"><Icon name="pin" size={11} /> {wCard.info.place}</div>}
            </div>
            <IconBtn label="Dismiss" onClick={() => setWCard(null)}><Icon name="close" size={14} /></IconBtn>
          </div>
          <div className="mt-2.5 grid grid-cols-2 gap-x-3 gap-y-1.5 text-[11px] text-cyan-50/70">
            <Stat icon="therm" label={`Feels ${fmtTemp(wCard.info.feelsC, u)}`} />
            <Stat icon="drop" label={`${Math.round(wCard.info.humidity)}% humidity`} />
            <Stat icon="sun" label={`H ${fmtTemp(wCard.info.highC, u)} · L ${fmtTemp(wCard.info.lowC, u)}`} />
            <Stat icon="wind" label={fmtWind(wCard.info.windKmh, u)} />
            <Stat icon="rain" label={`${Math.round(wCard.info.rainChance)}% rain`} />
          </div>
        </div>
      )}

      {/* camera feed (kept in DOM for the vision loop) */}
      <div className={`absolute right-3 top-14 z-20 w-36 overflow-hidden rounded-2xl glass transition-all duration-300 sm:w-44 ${camOn && showCam ? "opacity-100" : "pointer-events-none opacity-0"}`} style={{ height: camOn && showCam ? "auto" : 0 }}>
        <div className="relative aspect-[4/3] bg-black">
          <video ref={videoRef} className="h-full w-full -scale-x-100 object-cover" muted playsInline />
          {box && (
            <div className="absolute rounded-md border-2 border-cyan-300 shadow-[0_0_12px_rgba(62,244,255,.9)] transition-all duration-100" style={{ left: `${box.x * 100}%`, top: `${box.y * 100}%`, width: `${box.w * 100}%`, height: `${box.h * 100}%` }} />
          )}
        </div>
        <div className="flex items-center justify-between gap-1 p-2 text-[10px] text-cyan-100/80">
          <span>{visionMode === "mediapipe" ? "Face tracking" : visionMode === "motion" ? "Motion tracking" : "…"}</span>
          <span>{known ? `${known} known` : ""}</span>
        </div>
        <div className="flex gap-1 px-2 pb-2">
          <button onClick={() => exec({ t: "remember" })} className="flex-1 rounded-lg bg-cyan-400/15 px-2 py-1 text-[11px] hover:bg-cyan-400/30">Remember me</button>
          <button onClick={() => exec({ t: "forget" })} className="rounded-lg bg-white/5 px-2 py-1 text-[11px] hover:bg-white/10">Forget</button>
        </div>
      </div>

      {/* panels (bottom sheet above the dock; EMO moves up and shrinks to stay clear of it) */}
      {panel !== "none" && started && (
        <div ref={panelEl} className="emo-fade-up emo-scroll absolute inset-x-2 z-30 mx-auto max-h-[min(46vh,440px)] max-w-3xl overflow-y-auto rounded-3xl p-4 glass" style={{ bottom: DOCK }}>
          {panel === "music" && (
            <div>
              <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); submit(query); setQuery(""); }}>
                <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Song or artist — or ask: weather in Paris, 5 minute timer…" className="min-w-0 flex-1 rounded-xl border border-cyan-300/20 bg-black/40 px-4 py-2.5 text-sm outline-none placeholder:text-cyan-100/30 focus:border-cyan-300/60" />
                <button className="rounded-xl bg-cyan-400/20 px-4 text-sm font-medium text-cyan-100 hover:bg-cyan-400/35">Ask EMO</button>
              </form>
              <div className="mt-2 flex flex-wrap gap-1.5 text-[11px] text-cyan-100/60">
                {["Blinding Lights by The Weeknd", "Dance Monkey by Tones and I", "Uptown Funk by Bruno Mars", "Take On Me by a-ha"].map((s) => (
                  <button key={s} onClick={() => submit("play " + s)} className="rounded-full border border-cyan-300/15 px-2.5 py-1 hover:bg-cyan-400/15">{s}</button>
                ))}
                <button onClick={() => exec({ t: "music-own" })} className="rounded-full border border-cyan-300/30 px-2.5 py-1 text-cyan-200 hover:bg-cyan-400/15">EMO&apos;s own beat</button>
              </div>
              {searching && <div className="mt-4 text-center text-xs text-cyan-100/50">searching…</div>}
              {results.length > 0 && !searching && (
                <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {results.map((t, i) => (
                    <button key={t.id} onClick={() => playTrack(t)} className={`group relative flex items-center gap-2 rounded-2xl border p-2 text-left transition hover:bg-cyan-400/10 ${ps.track?.id === t.id ? "border-cyan-300/70 bg-cyan-400/10" : "border-cyan-300/10 bg-black/20"}`}>
                      <span className="absolute -left-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-cyan-300 text-[10px] font-bold text-black">{i + 1}</span>
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={t.art} alt="" className="h-12 w-12 shrink-0 rounded-lg object-cover" />
                      <span className="min-w-0">
                        <span className="block truncate text-xs font-semibold">{t.title}</span>
                        <span className="block truncate text-[11px] text-cyan-100/55">{t.artist}</span>
                      </span>
                    </button>
                  ))}
                </div>
              )}
              {results.length > 0 && <p className="mt-2 text-center text-[11px] text-cyan-100/40">Tap a card, or say “{wakeSaved}, number two”.</p>}
            </div>
          )}

          {panel === "weather" && (
            <div className="space-y-3">
              <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); const p = placeInput.trim(); askWeather(p || undefined); setPlaceInput(""); }}>
                <div className="relative min-w-0 flex-1">
                  <Icon name="search" size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-cyan-100/40" />
                  <input value={placeInput} onChange={(e) => setPlaceInput(e.target.value)} placeholder={home?.name ? `City or place — now using ${home.name}` : "Type a city, e.g. Tokyo"} className="w-full rounded-xl border border-cyan-300/20 bg-black/40 py-2.5 pl-9 pr-3 text-sm outline-none placeholder:text-cyan-100/30 focus:border-cyan-300/60" />
                </div>
                <button disabled={wBusy} className="rounded-xl bg-cyan-400/20 px-4 text-sm font-medium text-cyan-100 hover:bg-cyan-400/35 disabled:opacity-50">{wBusy ? "…" : "Check"}</button>
              </form>
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <button onClick={() => askWeather(undefined, true)} className="flex items-center gap-1.5 rounded-full border border-cyan-300/20 px-3 py-1.5 hover:bg-cyan-400/15"><Icon name="pin" size={14} /> Use my location</button>
                <button onClick={() => askWeather()} className="rounded-full border border-cyan-300/20 px-3 py-1.5 hover:bg-cyan-400/15">Weather here</button>
                <Seg value={units} onChange={(v) => setUnits(v as Units)} options={[["auto", "Auto"], ["f", "°F"], ["c", "°C"]]} />
                {home && <button onClick={() => setHome(null)} className="rounded-full px-2 py-1 text-cyan-100/50 hover:text-cyan-100">Forget {home.name || "location"}</button>}
              </div>
              <div className="flex flex-wrap gap-1.5 text-[11px] text-cyan-100/60">
                {[["Temperature", "temp"], ["Will it rain?", "rain"], ["Feels like", "feels"], ["Wind", "wind"], ["Forecast", "forecast"], ["What to wear", "advice"]].map(([l, t]) => (
                  <button key={t} onClick={() => exec({ t: "weather", topic: t as "temp" })} className="rounded-full border border-cyan-300/15 px-2.5 py-1 hover:bg-cyan-400/15">{l}</button>
                ))}
              </div>
              <p className="text-[11px] leading-relaxed text-cyan-100/40">Or just ask out loud: “{wakeSaved}, what’s the weather in London?”, “…what’s the temperature?”, “…do I need an umbrella?”. Rain, thunderstorms, snow, fog and sunshine all play on his screen.</p>
            </div>
          )}

          {panel === "lab" && testMode && (
            <div className="space-y-4 text-xs">
              <div>
                <div className="mb-1.5 font-semibold uppercase tracking-wider text-amber-200/80">Weather simulator</div>
                <div className="flex flex-wrap gap-1.5">
                  {Object.keys(SAMPLE).map((k) => (
                    <button key={k} onClick={() => { snd.initAudio(); brainRef.current?.previewWeather({ ...SAMPLE[k] }); }} className="rounded-full border border-cyan-300/15 bg-black/25 px-3 py-1.5 capitalize hover:bg-cyan-400/15">{k.replace("-", " ")}</button>
                  ))}
                  <button onClick={() => { snd.initAudio(); brainRef.current?.previewWeather({ ...SAMPLE["clear-day"] }, "temp"); }} className="rounded-full border border-cyan-300/15 bg-black/25 px-3 py-1.5 hover:bg-cyan-400/15">Temperature only</button>
                </div>
              </div>
              {["Happy", "Thinking", "Big feelings", "Body", "Shows"].map((g) => (
                <div key={g}>
                  <div className="mb-1.5 font-semibold uppercase tracking-wider text-cyan-300/70">{g}</div>
                  <div className="flex flex-wrap gap-1.5">
                    {MENU.filter((m) => m.group === g).map((m) => (
                      <button key={m.id} onClick={() => exec({ t: "act", id: m.id })} className="rounded-full border border-cyan-300/10 bg-black/25 px-3 py-1.5 hover:bg-cyan-400/15">{m.label}</button>
                    ))}
                  </div>
                </div>
              ))}
              <div>
                <div className="mb-1.5 font-semibold uppercase tracking-wider text-cyan-300/70">Helpers</div>
                <div className="flex flex-wrap gap-1.5">
                  {([
                    ["Clock", { t: "clock" }], ["Date", { t: "date" }], ["10 s timer", { t: "timer", secs: 10 }], ["1 min timer", { t: "timer", secs: 60 }],
                    ["Dice", { t: "dice", n: 1 }], ["Two dice", { t: "dice", n: 2 }], ["Coin", { t: "coin" }], ["Rock paper scissors", { t: "rps" }],
                    ["Random number", { t: "number", min: 1, max: 100 }], ["Stopwatch", { t: "stopwatch", op: "start" }], ["Joke", { t: "joke" }], ["Own beat", { t: "music-own" }], ["Stop", { t: "stop" }],
                  ] as [string, Cmd][]).map(([l, c]) => (
                    <button key={l} onClick={() => exec(c)} className="rounded-full border border-cyan-300/10 bg-black/25 px-3 py-1.5 hover:bg-cyan-400/15">{l}</button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {panel === "help" && (
            <div className="grid gap-4 text-xs sm:grid-cols-2">
              {helpSections(wakeSaved).map((h) => (
                <div key={h.title}>
                  <div className="mb-1 font-semibold text-cyan-300">{h.title}</div>
                  <ul className="space-y-1 text-cyan-50/70">{h.items.map((i) => <li key={i}>{i}</li>)}</ul>
                </div>
              ))}
            </div>
          )}

          {panel === "settings" && (
            <div className="space-y-3.5 text-sm">
              <Row label="Wake word" hint={`Say it before a request. Default “emo” (also “hey emo”).`}>
                <form className="flex gap-1.5" onSubmit={(e) => { e.preventDefault(); const w = wakeInput.trim() || "emo"; setWakeSaved(w); setWakeInput(w); say(`Okay, call me “${w}”.`, false); }}>
                  <input value={wakeInput} onChange={(e) => setWakeInput(e.target.value)} className="w-32 rounded-lg border border-cyan-300/20 bg-black/40 px-2.5 py-1.5 text-sm outline-none focus:border-cyan-300/60" />
                  <button className="rounded-lg bg-cyan-400/20 px-3 text-xs hover:bg-cyan-400/35">Save</button>
                </form>
              </Row>
              <Row label="EMO sounds (chirps)"><Toggle on={!muted} onChange={(v) => setMuted(!v)} /></Row>
              <Row label="Spoken answers" hint="He reads out the time, temperature, dice rolls…"><Toggle on={voiceReplies} onChange={setVoiceReplies} /></Row>
              <Row label="Temperature units"><Seg value={units} onChange={(v) => setUnits(v as Units)} options={[["auto", "Auto"], ["f", "°F"], ["c", "°C"]]} /></Row>
              <Row label="Live weather background" hint="Keeps a gentle rain / sun / snow scene going."><Toggle on={liveWeather} onChange={setLiveWeather} /></Row>
              <Row label="Show camera preview"><Toggle on={showCam} onChange={setShowCam} /></Row>
              <Row label="Music volume">
                <input type="range" min={0} max={100} value={vol} onChange={(e) => { setVol(+e.target.value); music.setVolume(+e.target.value); }} className="w-36 accent-cyan-300" />
              </Row>
              <Row label="Test mode" hint="Unlocks the Test lab: trigger any expression or weather scene by hand. Off = EMO only reacts to you (voice, touch, camera).">
                <Toggle on={testMode} onChange={setTestMode} accent="amber" />
              </Row>
              <div>
                <div className="mb-1">YouTube Data API key <span className="text-cyan-100/40">(optional — exact YouTube results)</span></div>
                <input value={apiKey} onChange={(e) => setApiKey(e.target.value.trim())} type="password" placeholder="AIza…" className="w-full rounded-xl border border-cyan-300/20 bg-black/40 px-3 py-2 text-sm outline-none focus:border-cyan-300/60" />
              </div>
              <div className="flex flex-wrap gap-2">
                <button onClick={() => { vision.forget(); setKnown(0); }} className="rounded-xl border border-cyan-300/20 px-3 py-2 text-xs hover:bg-cyan-400/15">Forget all faces ({known})</button>
                <button onClick={() => exec({ t: "act", id: "sleep" })} className="rounded-xl border border-cyan-300/20 px-3 py-2 text-xs hover:bg-cyan-400/15">Put EMO to sleep</button>
              </div>
              <p className="text-[11px] leading-relaxed text-cyan-100/40">Face recognition runs entirely in your browser (MediaPipe) — video never leaves your device. Face data is stored locally.</p>
            </div>
          )}
        </div>
      )}

      {/* dock */}
      <div className={`absolute inset-x-0 bottom-4 z-40 flex justify-center px-2 transition-all duration-500 ${dockShown ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0"}`}>
        <div className="flex max-w-full items-center gap-0.5 overflow-x-auto rounded-full p-1.5 glass">
          <DockBtn on={micOn} label="Microphone" onClick={() => { snd.initAudio(); micOn ? disableMic() : enableMic(); }}><Icon name={micOn ? "mic" : "micOff"} /></DockBtn>
          <DockBtn on={camOn} label="Camera" onClick={() => { snd.initAudio(); camOn ? disableCam() : enableCam(); }}><Icon name={camOn ? "camera" : "cameraOff"} /></DockBtn>
          <span className="mx-1 h-6 w-px shrink-0 bg-white/10" />
          <DockBtn on={panel === "music"} label="Music" onClick={() => toggle("music")}><Icon name="music" /></DockBtn>
          <DockBtn on={panel === "weather"} label="Weather" onClick={() => toggle("weather")}><Icon name="weather" /></DockBtn>
          {testMode && <DockBtn on={panel === "lab"} label="Test lab" onClick={() => toggle("lab")} tone="amber"><Icon name="flask" /></DockBtn>}
          <DockBtn on={panel === "help"} label="What can EMO do?" onClick={() => toggle("help")}><Icon name="help" /></DockBtn>
          <DockBtn on={panel === "settings"} label="Settings" onClick={() => toggle("settings")}><Icon name="settings" /></DockBtn>
          <DockBtn on={false} label="Fullscreen" onClick={fullscreen}><Icon name="expand" /></DockBtn>
        </div>
      </div>

      {/* start screen */}
      {!started && (
        <div className="absolute inset-0 z-50 flex items-end justify-center bg-gradient-to-t from-black/90 via-black/50 to-black/10 pb-[6vh]">
          <div className="emo-fade-up mx-4 w-full max-w-md rounded-3xl p-6 text-center glass">
            <h1 className="text-2xl font-extrabold tracking-[0.3em] text-cyan-300" style={{ fontFamily: "Orbitron, ui-sans-serif", textShadow: "0 0 18px rgba(62,244,255,.6)" }}>EMO</h1>
            <p className="mt-1 text-sm text-cyan-50/60">Your little desk companion. Say “Hey {wakeSaved}” and he perks right up.</p>
            <div className="mt-5 space-y-2 text-left text-sm">
              <label className="flex items-center gap-3 rounded-xl border border-cyan-300/15 bg-black/25 p-3">
                <input type="checkbox" checked={wantMic} onChange={(e) => setWantMic(e.target.checked)} className="h-4 w-4 accent-cyan-300" />
                <span><b>Microphone</b><br /><span className="text-xs text-cyan-100/50">Wake word, voice commands and feeling the music&apos;s beat</span></span>
              </label>
              <label className="flex items-center gap-3 rounded-xl border border-cyan-300/15 bg-black/25 p-3">
                <input type="checkbox" checked={wantCam} onChange={(e) => setWantCam(e.target.checked)} className="h-4 w-4 accent-cyan-300" />
                <span><b>Camera</b><br /><span className="text-xs text-cyan-100/50">Face tracking, recognition &amp; mirroring your expressions</span></span>
              </label>
            </div>
            <button onClick={wake} className="mt-5 w-full rounded-2xl bg-cyan-300 py-3 text-sm font-bold tracking-widest text-black shadow-[0_0_30px_rgba(62,244,255,.5)] transition hover:bg-cyan-200 active:scale-[.98]">WAKE EMO UP</button>
          </div>
        </div>
      )}
    </div>
  );
}

function helpSections(w: string) {
  return [
    { title: "Wake him up", items: [`“${w}” or “Hey ${w}” — he perks up, one eye lifts and he listens`, "While asleep the same words wake him with a big yawn and stretch", "Pat his head: tap = poke, hold = pet, drag = pick him up (shake him hard and he gets dizzy)"] },
    { title: "Weather & temperature", items: [`“${w}, what's the weather?” · “…in Paris”`, `“${w}, what's the temperature?” · “how hot is it?”`, `“${w}, will it rain today?” · “do I need an umbrella?”`, "Rain, thunderstorms with lightning, snow, fog, sun and moon play on his screen"] },
    { title: "Helpers", items: ["“What time is it?” · “What day is it?”", "“Set a 5 minute timer” · “Set an alarm for 7:30 am”", "“Roll a dice” · “Flip a coin” · “Pick a number”", "“What is 12 times 8?” · “Start the stopwatch”", "“Tell me a joke” · “Rock paper scissors”"] },
    { title: "Music", items: [`“${w}, play Blinding Lights by The Weeknd” — it starts right away`, "“next” · “pause” · “resume” · “louder” · “stop”", "“Number two” picks a different result from the list"] },
    { title: "Fun", items: ["“Hands up!” · “Dodge the bullet” · “Dance for me”", "“It's my birthday” · “Play dead” · “Turn red”", "“I'm cold” · “I'm hot” · “Roll your eyes” · “Stretch”"] },
    { title: "Camera", items: ["He follows your face, greets you, mirrors your smile, surprise, tongue, wink & head tilt, plays peek‑a‑boo and notices strangers.", "“Remember me” teaches him your face (up to 10 people)."] },
  ];
}

function Stat({ icon, label }: { icon: string; label: string }) {
  return <div className="flex items-center gap-1.5"><Icon name={icon} size={13} className="shrink-0 text-cyan-300/70" /><span className="truncate">{label}</span></div>;
}

function IconBtn({ children, label, onClick }: { children: React.ReactNode; label: string; onClick: () => void }) {
  return <button title={label} aria-label={label} onClick={onClick} className="flex h-8 w-8 items-center justify-center rounded-full text-cyan-50/80 transition hover:bg-white/10 hover:text-white">{children}</button>;
}

function DockBtn({ children, on, label, onClick, tone }: { children: React.ReactNode; on: boolean; label: string; onClick: () => void; tone?: "amber" }) {
  const active = tone === "amber" ? "bg-amber-300/20 text-amber-100 shadow-[0_0_14px_rgba(252,211,77,.4)]" : "bg-cyan-400/25 text-cyan-50 shadow-[0_0_14px_rgba(62,244,255,.45)]";
  return (
    <button title={label} aria-label={label} onClick={onClick} className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition ${on ? active : "text-cyan-50/70 hover:bg-white/10 hover:text-white"}`}>
      {children}
    </button>
  );
}

function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="min-w-0"><div>{label}</div>{hint && <div className="text-[11px] leading-snug text-cyan-100/40">{hint}</div>}</div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function Toggle({ on, onChange, accent }: { on: boolean; onChange: (v: boolean) => void; accent?: "amber" }) {
  return (
    <button role="switch" aria-checked={on} onClick={() => onChange(!on)} className={`relative h-6 w-11 rounded-full transition ${on ? (accent === "amber" ? "bg-amber-300" : "bg-cyan-300") : "bg-white/15"}`}>
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-[#06080d] transition-all ${on ? "left-[22px]" : "left-0.5 bg-white/80"}`} />
    </button>
  );
}

function Seg({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: [string, string][] }) {
  return (
    <div className="flex rounded-full border border-cyan-300/20 p-0.5 text-xs">
      {options.map(([v, l]) => (
        <button key={v} onClick={() => onChange(v)} className={`rounded-full px-3 py-1 transition ${value === v ? "bg-cyan-300 text-black" : "text-cyan-100/70 hover:bg-white/10"}`}>{l}</button>
      ))}
    </div>
  );
}

