"use client";
import dynamic from "next/dynamic";

// EMO uses the camera, microphone, canvas and localStorage — browser only.
const EmoApp = dynamic(() => import("./EmoApp"), { ssr: false });

export default function EmoClient() {
  return <EmoApp />;
}
