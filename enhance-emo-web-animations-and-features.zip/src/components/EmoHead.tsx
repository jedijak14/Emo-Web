"use client";
import { useEffect, useRef } from "react";
import { EmoEngine } from "../emo/engine";

export type TouchKind = "tap" | "pet-start" | "pet-end" | "drag-start" | "drag-end" | "shake";

interface Props {
  onEngine: (e: EmoEngine) => void;
  onTouch: (k: TouchKind) => void;
  onDrag?: (dx: number, dy: number) => void;
  /** px kept free at the bottom (dock + open panel) so EMO never sits under the UI */
  bottomInset: number;
  topInset: number;
}

function skyBg(kind: string, day: boolean) {
  switch (kind) {
    case "clear": return day
      ? "radial-gradient(70% 55% at 78% 8%, rgba(255,184,64,.26), transparent 70%), linear-gradient(to bottom, rgba(70,120,200,.16), transparent 60%)"
      : "radial-gradient(60% 50% at 80% 10%, rgba(150,170,255,.16), transparent 70%), linear-gradient(to bottom, rgba(20,24,70,.5), transparent 75%)";
    case "partly": return "radial-gradient(60% 50% at 25% 8%, rgba(255,196,90,.18), transparent 70%), linear-gradient(to bottom, rgba(80,110,160,.2), transparent 65%)";
    case "cloudy": return "linear-gradient(to bottom, rgba(90,105,135,.32), transparent 70%)";
    case "fog": return "linear-gradient(to bottom, rgba(160,170,185,.22), rgba(160,170,185,.12))";
    case "drizzle":
    case "rain": return "linear-gradient(to bottom, rgba(40,75,125,.42), rgba(10,22,45,.12))";
    case "storm": return "linear-gradient(to bottom, rgba(42,26,92,.62), rgba(8,8,22,.25))";
    case "snow":
    case "sleet": return "linear-gradient(to bottom, rgba(120,160,210,.26), rgba(200,225,255,.06))";
    default: return "none";
  }
}

export function EmoHead({ onEngine, onTouch, onDrag, bottomInset, topInset }: Props) {
  const cvRef = useRef<HTMLCanvasElement>(null);
  const headRef = useRef<HTMLDivElement>(null);
  const bandRef = useRef<HTMLDivElement>(null);
  const cupsRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const skyRef = useRef<HTMLDivElement>(null);
  const boltRef = useRef<HTMLDivElement>(null);
  const engRef = useRef<EmoEngine | null>(null);
  const touchRef = useRef(onTouch);
  const dragRef = useRef(onDrag);
  touchRef.current = onTouch;
  dragRef.current = onDrag;
  const skyKey = useRef("");

  useEffect(() => {
    const engine = new EmoEngine(cvRef.current!);
    engRef.current = engine;
    document.fonts?.load("800 40px Orbitron").catch(() => {});
    engine.onFrame = (f) => {
      const h = headRef.current, st = stageRef.current, b = bandRef.current, c = cupsRef.current;
      if (!h || !st || !b || !c) return;
      h.style.transform = `perspective(1100px) translate(${f.x.toFixed(1)}px,${f.y.toFixed(1)}px) rotateX(${f.rotX.toFixed(2)}deg) rotateY(${f.rotY.toFixed(2)}deg) rotate(${f.tilt.toFixed(2)}deg) scale(${f.sx.toFixed(3)},${f.sy.toFixed(3)})`;
      const col = `${f.color[0] | 0},${f.color[1] | 0},${f.color[2] | 0}`;
      h.style.setProperty("--beat", f.beat.toFixed(3));
      h.style.setProperty("--col", col);
      const hp = Math.max(0, Math.min(1, f.hp));
      b.style.opacity = String(hp);
      b.style.transform = `translateY(${(1 - hp) * -18}%) scale(${0.9 + hp * 0.1})`;
      c.style.opacity = String(hp);
      c.style.transform = `scale(${0.7 + hp * 0.3})`;
      st.style.setProperty("--dj", f.djOn ? "1" : "0");
      st.style.setProperty("--hue", String(f.hue));
      st.style.setProperty("--flash", f.flash.toFixed(3));
      st.style.setProperty("--col", col);
      st.style.setProperty("--bright", f.bright.toFixed(2));
      st.style.setProperty("--beat", f.beat.toFixed(3));
      // weather ambience behind EMO + lightning flashes on the whole page
      const sk = skyRef.current, bo = boltRef.current;
      if (sk) {
        const key = `${f.sky}:${f.day}`;
        if (key !== skyKey.current && f.sky !== "none") { skyKey.current = key; sk.style.background = skyBg(f.sky, f.day); }
        sk.style.opacity = f.sky === "none" ? "0" : f.skyA.toFixed(3);
      }
      if (bo) bo.style.opacity = (f.bolt * 0.4).toFixed(3);
    };
    engine.start();
    onEngine(engine);
    const onResize = () => engine.resize();
    window.addEventListener("resize", onResize);
    return () => { engine.stop(); window.removeEventListener("resize", onResize); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // pointer interaction: tap = poke, hold = pet, drag = pick up, whip back and forth = shake
  const ptr = useRef({
    down: false, x0: 0, y0: 0, t0: 0, pet: false, drag: false, timer: 0 as ReturnType<typeof setTimeout> | 0,
    lx: 0, ly: 0, sx: 0, sy: 0, rev: [] as number[], lastShake: 0,
  });
  const down = (ev: React.PointerEvent) => {
    const p = ptr.current;
    (ev.currentTarget as HTMLElement).setPointerCapture(ev.pointerId);
    p.down = true; p.x0 = p.lx = ev.clientX; p.y0 = p.ly = ev.clientY; p.t0 = performance.now(); p.pet = false; p.drag = false;
    p.sx = p.sy = 0; p.rev = [];
    p.timer = setTimeout(() => { if (p.down && !p.drag) { p.pet = true; touchRef.current("pet-start"); } }, 450);
  };
  const move = (ev: React.PointerEvent) => {
    const p = ptr.current;
    if (!p.down) return;
    const dx = ev.clientX - p.x0, dy = ev.clientY - p.y0;
    if (!p.drag && Math.hypot(dx, dy) > 22) {
      if (p.timer) clearTimeout(p.timer);
      if (p.pet) { touchRef.current("pet-end"); p.pet = false; }
      p.drag = true;
      touchRef.current("drag-start");
    }
    if (p.drag && engRef.current) {
      engRef.current.head.x.t = Math.max(-260, Math.min(260, dx * 0.6));
      engRef.current.head.y.t = Math.max(-200, Math.min(200, dy * 0.6));
      engRef.current.head.tilt.t = Math.max(-25, Math.min(25, dx * 0.08));
      dragRef.current?.(dx, dy);
      // shake detection: fast direction reversals (a calm carry never triggers this)
      const vx = ev.clientX - p.lx, vy = ev.clientY - p.ly;
      p.lx = ev.clientX; p.ly = ev.clientY;
      const now = performance.now();
      const rev = (v: number, prev: number) => Math.abs(v) > 14 && prev !== 0 && Math.sign(v) !== Math.sign(prev);
      if (rev(vx, p.sx) || rev(vy, p.sy)) p.rev.push(now);
      if (Math.abs(vx) > 14) p.sx = vx;
      if (Math.abs(vy) > 14) p.sy = vy;
      p.rev = p.rev.filter((t) => now - t < 1000);
      if (p.rev.length >= 4 && now - p.lastShake > 2500) { p.lastShake = now; p.rev = []; touchRef.current("shake"); }
    }
  };
  const up = () => {
    const p = ptr.current;
    if (!p.down) return;
    p.down = false;
    if (p.timer) clearTimeout(p.timer);
    if (p.drag) {
      touchRef.current("drag-end");
      if (engRef.current) { engRef.current.head.x.t = 0; engRef.current.head.y.t = 0; engRef.current.head.tilt.t = 0; }
    } else if (p.pet) touchRef.current("pet-end");
    else touchRef.current("tap");
  };

  return (
    <div ref={stageRef} className="emo-stage absolute inset-0 overflow-hidden" style={{ ["--dj" as string]: 0, ["--hue" as string]: 190, ["--beat" as string]: 0, ["--flash" as string]: 0, ["--col" as string]: "62,244,255" }}>
      {/* ambient glow of the screen */}
      <div className="absolute inset-0" style={{ background: "radial-gradient(60% 55% at 50% 48%, rgba(var(--col),0.10), transparent 70%)" }} />
      {/* weather ambience */}
      <div ref={skyRef} className="pointer-events-none absolute inset-0" style={{ opacity: 0 }} />
      <div ref={boltRef} className="pointer-events-none absolute inset-0" style={{ opacity: 0, background: "rgb(200,215,255)" }} />
      {/* DJ stage lights */}
      <div className="absolute inset-0 transition-opacity duration-1000" style={{ opacity: "var(--dj)" as unknown as number }}>
        <div className="absolute inset-0" style={{ background: "radial-gradient(50% 50% at 50% 50%, hsl(var(--hue) 100% 55% / calc(.18 + var(--beat) * .35)), transparent 70%)" }} />
        {[0, 1].map((i) => (
          <div key={i} className="absolute left-1/2 top-1/2 emo-beam" style={{ width: "170vmax", height: "170vmax", animationDuration: `${i ? 19 : 13}s`, animationDirection: i ? "reverse" : "normal", background: `conic-gradient(from ${i * 40}deg, transparent 0deg, hsl(var(--hue) 100% 60% / .20) 7deg, transparent 16deg, transparent 100deg, hsl(calc(var(--hue) + 90) 100% 62% / .18) 107deg, transparent 116deg, transparent 200deg, hsl(calc(var(--hue) + 200) 100% 60% / .18) 208deg, transparent 218deg, transparent 290deg, hsl(calc(var(--hue) + 40) 100% 60% / .16) 297deg, transparent 306deg)` }} />
        ))}
        <div className="absolute inset-x-0 bottom-0 h-1/3" style={{ background: "linear-gradient(to top, hsl(var(--hue) 100% 50% / calc(.12 + var(--beat) * .2)), transparent)" }} />
      </div>
      <div className="pointer-events-none absolute inset-0" style={{ background: "hsl(var(--hue) 100% 70%)", opacity: "calc(var(--flash) * .22)" as unknown as number }} />

      {/* EMO's own region: sits between the top bar and the dock / open panel, so nothing overlaps him */}
      <div className="absolute inset-x-0 flex items-center justify-center transition-[top,bottom] duration-500 ease-out" style={{ top: topInset, bottom: bottomInset, containerType: "size" }}>
        <div ref={headRef} className="relative touch-none select-none" style={{ width: "min(90cqw, 92cqh)", aspectRatio: "1", cursor: "grab", willChange: "transform" }}
          onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}>
          {/* headphone band (behind head) */}
          <div ref={bandRef} className="absolute pointer-events-none" style={{ left: "-9%", width: "118%", top: "-13%", height: "62%", opacity: 0, transformOrigin: "50% 100%", zIndex: 0 }}>
            <svg viewBox="0 0 118 62" className="h-full w-full overflow-visible">
              <path d="M 5 58 C 3 -10 115 -10 113 58" fill="none" stroke="#2a1d63" strokeWidth="6.5" strokeLinecap="round" />
              <path d="M 5 58 C 3 -10 115 -10 113 58" fill="none" stroke="#5b46c7" strokeWidth="4" strokeLinecap="round" />
              <path d="M 12 40 C 14 4 104 4 106 40" fill="none" stroke="#9a86ff" strokeOpacity=".5" strokeWidth="1" strokeLinecap="round" />
            </svg>
          </div>

          {/* body shell */}
          <div className="absolute inset-0" style={{ zIndex: 1, borderRadius: "17%", background: "linear-gradient(150deg,#262a3a 0%,#11131c 55%,#0a0b11 100%)", boxShadow: "0 30px 80px rgba(0,0,0,.65), inset 0 2px 3px rgba(255,255,255,.14), inset 0 -8px 20px rgba(0,0,0,.6), 0 0 90px rgba(var(--col),.10)" }}>
            {/* silver bezel */}
            <div className="absolute" style={{ inset: "5.5%", borderRadius: "13%", background: "linear-gradient(145deg,#e4e7ee 0%,#8d919d 38%,#4b4e59 70%,#9da1ad 100%)", boxShadow: "inset 0 0 0 2px rgba(0,0,0,.35), 0 3px 8px rgba(0,0,0,.5)", padding: "2.4%" }}>
              <div className="relative h-full w-full overflow-hidden" style={{ borderRadius: "10.5%", background: "#020306", boxShadow: "inset 0 0 30px rgba(0,0,0,.95), inset 0 0 0 3px #050608" }}>
                <canvas ref={cvRef} className="absolute inset-0 h-full w-full" style={{ filter: "drop-shadow(0 0 14px rgba(var(--col),.75)) drop-shadow(0 0 4px rgba(var(--col),.9))" }} />
                {/* subtle pixel grid + glass */}
                <div className="pointer-events-none absolute inset-0" style={{ backgroundImage: "linear-gradient(rgba(0,0,0,.18) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,.18) 1px, transparent 1px)", backgroundSize: "5px 5px", opacity: 0.35 }} />
                <div className="pointer-events-none absolute inset-0" style={{ background: "linear-gradient(125deg, rgba(255,255,255,.10) 0%, rgba(255,255,255,.02) 28%, transparent 40%)" }} />
              </div>
            </div>
          </div>

          {/* headphone cups (in front) */}
          <div ref={cupsRef} className="absolute inset-0 pointer-events-none" style={{ zIndex: 2, opacity: 0 }}>
            {[0, 1].map((i) => (
              <div key={i} className="absolute" style={{ [i ? "right" : "left"]: "-9.5%", top: "31%", width: "17%", height: "36%", borderRadius: "50%", background: "radial-gradient(circle at 35% 30%, #5846b8, #251a5c 70%)", boxShadow: "0 8px 20px rgba(0,0,0,.6), inset 0 2px 4px rgba(255,255,255,.2)" }}>
                <div className="absolute" style={{ inset: "14%", borderRadius: "50%", border: "0.9vmin solid rgb(var(--col))", boxShadow: "0 0 calc(1vmin + var(--beat) * 3vmin) rgb(var(--col)), inset 0 0 calc(.6vmin + var(--beat) * 1.6vmin) rgb(var(--col))", background: "radial-gradient(circle, #1c1450, #120c3a)" }} />
              </div>
            ))}
          </div>
          {/* ground shadow */}
          <div className="absolute left-1/2 -translate-x-1/2 pointer-events-none" style={{ bottom: "-7%", width: "70%", height: "5%", background: "radial-gradient(ellipse, rgba(0,0,0,.6), transparent 70%)", zIndex: -1 }} />
        </div>
      </div>
    </div>
  );
}
