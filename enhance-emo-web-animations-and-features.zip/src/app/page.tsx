import EmoClient from "@/components/EmoClient";

export default function HomePage() {
  return <EmoClient />;
}
