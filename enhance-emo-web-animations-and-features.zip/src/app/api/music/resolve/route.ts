import { NextRequest, NextResponse } from "next/server";
import { ytScrape, ytApi } from "@/lib/music-server";

export const dynamic = "force-dynamic";

// Find playable YouTube video ids for an "artist + title" (used when the catalogue gave us no video).
export async function GET(req: NextRequest) {
  const artist = req.nextUrl.searchParams.get("artist") || "";
  const title = req.nextUrl.searchParams.get("title") || "";
  const key = req.headers.get("x-yt-key") || process.env.YOUTUBE_API_KEY || "";
  const q = `${artist} ${title}`.trim();
  if (!q) return NextResponse.json({ ids: [] });
  try {
    if (key) { const r = await ytApi(q, key); if (r.length) return NextResponse.json({ ids: r.slice(0, 4).map((v) => v.id) }); }
  } catch { /* fall through */ }
  try {
    const r = await ytScrape(`${q} official audio`);
    return NextResponse.json({ ids: r.slice(0, 4).map((v) => v.id) });
  } catch {
    return NextResponse.json({ ids: [] });
  }
}
