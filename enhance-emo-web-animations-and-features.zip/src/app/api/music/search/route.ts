import { NextRequest, NextResponse } from "next/server";
import { itunes, ytScrape, ytApi, cleanTitle, cleanChannel, type YtVideo } from "@/lib/music-server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const q = (req.nextUrl.searchParams.get("q") || "").replace(/\s+by\s+/i, " ").replace(/[^\p{L}\p{N}\s'&.-]/gu, " ").trim();
  if (!q) return NextResponse.json({ tracks: [] });
  const key = req.headers.get("x-yt-key") || process.env.YOUTUBE_API_KEY || "";

  const [ytRes, itRes] = await Promise.allSettled([
    (async (): Promise<YtVideo[]> => {
      if (key) { try { const r = await ytApi(q, key); if (r.length) return r; } catch { /* fall through */ } }
      return ytScrape(`${q} official audio`);
    })(),
    itunes(q),
  ]);
  const yt = ytRes.status === "fulfilled" ? ytRes.value : [];
  const it = itRes.status === "fulfilled" ? itRes.value : [];

  if (yt.length) {
    const tracks = yt.slice(0, 6).map((v, i) => {
      const title = cleanTitle(v.title);
      const low = title.toLowerCase();
      const match = it.find((m) => low.includes(m.title.toLowerCase().replace(/\s*\(.*?\)\s*/g, "").trim())) || (i === 0 ? it[0] : undefined);
      return {
        id: v.id, videoId: v.id, title, artist: cleanChannel(v.channel), art: `https://i.ytimg.com/vi/${v.id}/mqdefault.jpg`,
        alts: yt.filter((o) => o.id !== v.id).slice(0, 3).map((o) => o.id),
        previewUrl: match?.previewUrl,
      };
    });
    return NextResponse.json({ tracks, source: "youtube" });
  }
  const tracks = it.slice(0, 6).map((m) => ({ id: m.id, title: m.title, artist: m.artist, art: m.art, previewUrl: m.previewUrl }));
  return NextResponse.json({ tracks, source: "itunes" });
}
