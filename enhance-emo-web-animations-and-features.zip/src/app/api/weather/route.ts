import { NextRequest, NextResponse } from "next/server";
import type { SceneKind, WeatherInfo } from "@/emo/weather";

export const dynamic = "force-dynamic";

async function getJson(url: string, ms = 6000) {
  const r = await fetch(url, { cache: "no-store", signal: AbortSignal.timeout(ms), headers: { "user-agent": "emo-web/1.0" } });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

interface Loc { lat: number; lon: number; name: string }

async function geocode(q: string): Promise<Loc | null> {
  const name = q.split(",")[0].trim();
  const j = await getJson(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1&language=en&format=json`);
  const r = j.results?.[0];
  if (!r) return null;
  return { lat: r.latitude, lon: r.longitude, name: [r.name, r.admin1 && r.country_code === "US" ? r.admin1 : r.country].filter(Boolean).join(", ") };
}

async function reverse(lat: number, lon: number): Promise<string> {
  try {
    const j = await getJson(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=en`, 2500);
    return [j.city || j.locality, j.principalSubdivisionCode?.startsWith("US-") ? j.principalSubdivisionCode.slice(3) : j.countryName].filter(Boolean).join(", ");
  } catch { return ""; }
}

async function ipLocate(req: NextRequest): Promise<Loc | null> {
  const fwd = (req.headers.get("x-forwarded-for") || "").split(",")[0].trim().replace(/^::ffff:/, "");
  const priv = !fwd || /^(10\.|127\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|::1|fc|fd)/.test(fwd);
  const tries = [priv ? "https://ipwho.is/" : `https://ipwho.is/${fwd}`, priv ? "https://ipapi.co/json/" : `https://ipapi.co/${fwd}/json/`];
  for (const u of tries) {
    try {
      const j = await getJson(u, 4000);
      const lat = j.latitude, lon = j.longitude;
      if (typeof lat === "number" && typeof lon === "number") return { lat, lon, name: [j.city, j.region_code || j.region].filter(Boolean).join(", ") };
    } catch { /* next */ }
  }
  return null;
}

// WMO code -> scene
function wmo(code: number): { kind: SceneKind; desc: string; intensity: number } {
  if (code === 0) return { kind: "clear", desc: "Sunny", intensity: 0.5 };
  if (code === 1) return { kind: "clear", desc: "Mostly sunny", intensity: 0.5 };
  if (code === 2) return { kind: "partly", desc: "Partly cloudy", intensity: 0.5 };
  if (code === 3) return { kind: "cloudy", desc: "Overcast", intensity: 0.5 };
  if (code === 45 || code === 48) return { kind: "fog", desc: "Foggy", intensity: 0.5 };
  if (code >= 51 && code <= 55) return { kind: "drizzle", desc: code === 55 ? "Heavy drizzle" : "Light drizzle", intensity: 0.25 + (code - 51) * 0.1 };
  if (code === 56 || code === 57) return { kind: "sleet", desc: "Freezing drizzle", intensity: 0.4 };
  if (code === 61) return { kind: "rain", desc: "Light rain", intensity: 0.4 };
  if (code === 63) return { kind: "rain", desc: "Rain", intensity: 0.65 };
  if (code === 65) return { kind: "rain", desc: "Heavy rain", intensity: 1 };
  if (code === 66 || code === 67) return { kind: "sleet", desc: "Freezing rain", intensity: 0.6 };
  if (code === 71) return { kind: "snow", desc: "Light snow", intensity: 0.35 };
  if (code === 73) return { kind: "snow", desc: "Snow", intensity: 0.65 };
  if (code === 75 || code === 77) return { kind: "snow", desc: code === 77 ? "Snow grains" : "Heavy snow", intensity: 1 };
  if (code === 80) return { kind: "rain", desc: "Light showers", intensity: 0.45 };
  if (code === 81) return { kind: "rain", desc: "Showers", intensity: 0.7 };
  if (code === 82) return { kind: "rain", desc: "Violent showers", intensity: 1 };
  if (code === 85 || code === 86) return { kind: "snow", desc: "Snow showers", intensity: 0.7 };
  if (code >= 95) return { kind: "storm", desc: code >= 96 ? "Thunderstorm with hail" : "Thunderstorm", intensity: 0.9 };
  return { kind: "cloudy", desc: "Cloudy", intensity: 0.5 };
}

// World Weather Online code (wttr.in) -> scene
function wwo(code: number, text: string): { kind: SceneKind; desc: string; intensity: number } {
  const D = text || "";
  if ([200, 386, 389, 392, 395].includes(code)) return { kind: "storm", desc: D || "Thunderstorm", intensity: 0.9 };
  if ([113].includes(code)) return { kind: "clear", desc: D || "Sunny", intensity: 0.5 };
  if ([116].includes(code)) return { kind: "partly", desc: D || "Partly cloudy", intensity: 0.5 };
  if ([119, 122].includes(code)) return { kind: "cloudy", desc: D || "Cloudy", intensity: 0.5 };
  if ([143, 248, 260].includes(code)) return { kind: "fog", desc: D || "Foggy", intensity: 0.5 };
  if ([263, 266, 293, 296].includes(code)) return { kind: "drizzle", desc: D || "Light drizzle", intensity: 0.3 };
  if ([299, 302, 305, 308, 353, 356, 359].includes(code)) return { kind: "rain", desc: D || "Rain", intensity: [308, 359, 305].includes(code) ? 1 : 0.65 };
  if ([299, 302].includes(code)) return { kind: "rain", desc: D || "Rain", intensity: 0.6 };
  if ([179, 182, 185, 281, 284, 311, 314, 317, 320, 350, 362, 365, 374, 377].includes(code)) return { kind: "sleet", desc: D || "Sleet", intensity: 0.5 };
  if ([227, 230, 323, 326, 329, 332, 335, 338, 368, 371].includes(code)) return { kind: "snow", desc: D || "Snow", intensity: [230, 335, 338, 371].includes(code) ? 1 : 0.6 };
  return { kind: "cloudy", desc: D || "Cloudy", intensity: 0.5 };
}

async function openMeteo(l: Loc): Promise<WeatherInfo> {
  const j = await getJson(
    `https://api.open-meteo.com/v1/forecast?latitude=${l.lat}&longitude=${l.lon}&current=temperature_2m,apparent_temperature,relative_humidity_2m,is_day,precipitation,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=1`,
    5000,
  );
  const c = j.current;
  const s = wmo(c.weather_code);
  return {
    place: l.name, ...s, isDay: c.is_day === 1,
    tempC: c.temperature_2m, feelsC: c.apparent_temperature, humidity: c.relative_humidity_2m, windKmh: c.wind_speed_10m,
    highC: j.daily?.temperature_2m_max?.[0] ?? c.temperature_2m, lowC: j.daily?.temperature_2m_min?.[0] ?? c.temperature_2m,
    rainChance: j.daily?.precipitation_probability_max?.[0] ?? 0, precipMm: c.precipitation ?? 0, source: "open-meteo",
  };
}

async function wttr(l: Loc): Promise<WeatherInfo> {
  const j = await getJson(`https://wttr.in/${l.lat},${l.lon}?format=j1`, 8000);
  const c = j.current_condition[0];
  const d = j.weather?.[0];
  const s = wwo(+c.weatherCode, c.weatherDesc?.[0]?.value);
  const m = /(\d+):\d+\s*(AM|PM)/i.exec(c.observation_time || "");
  let h = m ? (+m[1] % 12) + (/pm/i.test(m[2]) ? 12 : 0) : 12;
  // observation_time is UTC; shift by the offset wttr reports for the area when available
  const local = j.current_condition?.[0]?.localObsDateTime as string | undefined;
  const lm = local ? /(\d+):\d+\s*(AM|PM)/i.exec(local.split(" ").slice(1).join(" ")) : null;
  if (lm) h = (+lm[1] % 12) + (/pm/i.test(lm[2]) ? 12 : 0);
  const chance = Math.max(0, ...((d?.hourly || []) as { chanceofrain: string }[]).map((x) => +x.chanceofrain || 0));
  return {
    place: l.name || j.nearest_area?.[0]?.areaName?.[0]?.value || "", ...s, isDay: h >= 6 && h < 19,
    tempC: +c.temp_C, feelsC: +c.FeelsLikeC, humidity: +c.humidity, windKmh: +c.windspeedKmph,
    highC: d ? +d.maxtempC : +c.temp_C, lowC: d ? +d.mintempC : +c.temp_C, rainChance: chance, precipMm: +c.precipMM || 0, source: "wttr.in",
  };
}

export async function GET(req: NextRequest) {
  const p = req.nextUrl.searchParams;
  const q = (p.get("q") || "").trim();
  const lat = parseFloat(p.get("lat") || "");
  const lon = parseFloat(p.get("lon") || "");
  let loc: Loc | null = null;
  try {
    if (q) {
      loc = await geocode(q);
      if (!loc) return NextResponse.json({ error: "place_not_found", message: `I couldn't find a place called "${q}".` }, { status: 404 });
    } else if (Number.isFinite(lat) && Number.isFinite(lon)) {
      loc = { lat, lon, name: p.get("name") || (await reverse(lat, lon)) };
    } else {
      loc = await ipLocate(req);
    }
  } catch {
    if (!loc) loc = null;
  }
  if (!loc) return NextResponse.json({ error: "no_location", message: "I couldn't work out where you are." }, { status: 422 });

  let info: WeatherInfo | null = null;
  try { info = await openMeteo(loc); } catch { /* fallback */ }
  if (!info) { try { info = await wttr(loc); } catch { /* none */ } }
  if (!info) return NextResponse.json({ error: "unavailable", message: "The weather service isn't answering right now." }, { status: 502 });
  if (!info.place && loc.name) info.place = loc.name;
  return NextResponse.json({ ...info, lat: loc.lat, lon: loc.lon });
}
