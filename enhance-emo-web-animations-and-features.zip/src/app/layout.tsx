import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "EMO — Desk Companion",
  description: "A tiny expressive desk robot: weather, music, timers, games and a whole lot of feelings.",
};

export const viewport: Viewport = { themeColor: "#05060a", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@700;800&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-[#05060a] text-cyan-50 antialiased">{children}</body>
    </html>
  );
}
