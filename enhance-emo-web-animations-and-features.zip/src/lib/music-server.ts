const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

export interface YtVideo { id: string; title: string; channel: string; secs: number }
export interface ItTrack { id: string; title: string; artist: string; art: string; previewUrl?: string }

function toSecs(s?: string) {
  if (!s) return 0;
  return s.split(":").reduce((a, n) => a * 60 + (+n || 0), 0);
}

function* walk(o: unknown): Generator<Record<string, unknown>> {
  if (!o || typeof o !== "object") return;
  if (Array.isArray(o)) { for (const x of o) yield* walk(x); return; }
  const r = o as Record<string, unknown>;
  if (r.videoRenderer) yield r.videoRenderer as Record<string, unknown>;
  for (const k of Object.keys(r)) if (k !== "videoRenderer") yield* walk(r[k]);
}

export async function ytScrape(query: string): Promise<YtVideo[]> {
  const r = await fetch(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}&sp=EgIQAQ%253D%253D`, {
    cache: "no-store", signal: AbortSignal.timeout(7000),
    headers: { "user-agent": UA, "accept-language": "en-US,en;q=0.9", cookie: "CONSENT=YES+1; SOCS=CAI" },
  });
  const html = await r.text();
  const m = html.match(/var ytInitialData = (\{[\s\S]+?\});\s*<\/script>/);
  const out: YtVideo[] = [];
  const seen = new Set<string>();
  if (m) {
    try {
      const data = JSON.parse(m[1]);
      for (const v of walk(data) as Generator<any>) {
        const id = v.videoId as string;
        if (!id || seen.has(id)) continue;
        const secs = toSecs(v.lengthText?.simpleText);
        if (!secs || secs > 12 * 60) continue; // live streams / mixes / long videos
        seen.add(id);
        out.push({ id, title: v.title?.runs?.[0]?.text || "Untitled", channel: v.ownerText?.runs?.[0]?.text || "YouTube", secs });
        if (out.length >= 8) break;
      }
    } catch { /* fall through to regex */ }
  }
  if (!out.length) {
    for (const x of html.matchAll(/"videoRenderer":\{"videoId":"([\w-]{11})"/g)) {
      if (!seen.has(x[1])) { seen.add(x[1]); out.push({ id: x[1], title: "YouTube result", channel: "YouTube", secs: 0 }); }
      if (out.length >= 6) break;
    }
  }
  return out;
}

export async function ytApi(q: string, key: string): Promise<YtVideo[]> {
  const r = await fetch(
    `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&videoCategoryId=10&maxResults=8&q=${encodeURIComponent(q)}&key=${encodeURIComponent(key)}`,
    { cache: "no-store", signal: AbortSignal.timeout(6000) },
  );
  const j = await r.json();
  return (j.items || []).map((it: any) => ({ id: it.id.videoId, title: dec(it.snippet.title), channel: dec(it.snippet.channelTitle), secs: 0 }));
}

export async function itunes(q: string): Promise<ItTrack[]> {
  const r = await fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(q)}&media=music&entity=song&limit=10`, { cache: "no-store", signal: AbortSignal.timeout(6000) });
  const j = await r.json();
  const seen = new Set<string>();
  const out: ItTrack[] = [];
  for (const it of j.results || []) {
    const key = `${it.trackName}|${it.artistName}`.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ id: String(it.trackId), title: it.trackName, artist: it.artistName, art: (it.artworkUrl100 || "").replace("100x100", "300x300"), previewUrl: it.previewUrl });
  }
  return out;
}

function dec(s: string) {
  return s.replace(/&amp;/g, "&").replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, "<").replace(/&gt;/g, ">");
}

export function cleanTitle(t: string) {
  return dec(t)
    .replace(/\s*[([](?:official|lyrics?|lyric video|audio|video|hd|4k|visuali[sz]er|music video|explicit)[^)\]]*[)\]]/gi, "")
    .replace(/\s*\|.*$/, "")
    .replace(/\s{2,}/g, " ")
    .trim();
}
export function cleanChannel(c: string) {
  return dec(c).replace(/\s*-\s*Topic$/i, "").replace(/VEVO$/i, "").trim();
}
