// Microphone: (1) speech recognition for "Emo, ..." commands, (2) a raw level/beat meter so EMO can
// feel the music coming out of your speakers and dance in time.
export class MicMeter {
  private stream: MediaStream | null = null;
  private ac: AudioContext | null = null;
  private an: AnalyserNode | null = null;
  private timer: number | null = null;
  private avg = 0;
  private lastOnset = 0;
  private peak = 0.12;
  onLevel?: (energy: number, onset: boolean) => void;
  running = false;

  async start() {
    if (this.running) return true;
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
      });
    } catch { return false; }
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    this.ac = new AC();
    const src = this.ac.createMediaStreamSource(this.stream);
    this.an = this.ac.createAnalyser();
    this.an.fftSize = 1024;
    this.an.smoothingTimeConstant = 0.4;
    src.connect(this.an);
    const data = new Uint8Array(this.an.frequencyBinCount);
    this.running = true;
    this.timer = window.setInterval(() => {
      if (!this.an) return;
      this.an.getByteFrequencyData(data);
      let low = 0;
      for (let i = 1; i < 9; i++) low += data[i];
      low /= 8 * 255;
      let all = 0;
      for (let i = 1; i < 64; i++) all += data[i];
      all /= 63 * 255;
      const e = low * 0.7 + all * 0.3;
      this.peak = Math.max(e, this.peak * 0.995);
      const now = performance.now();
      const onset = e > this.avg * 1.3 + 0.03 && e > 0.1 && now - this.lastOnset > 280;
      if (onset) this.lastOnset = now;
      this.avg = this.avg * 0.93 + e * 0.07;
      this.onLevel?.(Math.min(1, e / this.peak), onset);
    }, 33);
    return true;
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.stream?.getTracks().forEach((t) => t.stop());
    this.ac?.close().catch(() => {});
    this.stream = null; this.ac = null; this.an = null; this.running = false;
  }
}

export class SpeechListener {
  private rec: any = null;
  private active = false;
  supported: boolean;
  onFinal?: (text: string) => void;
  onInterim?: (text: string) => void;
  onState?: (listening: boolean, error?: string) => void;

  constructor() {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    this.supported = !!SR;
    if (!SR) return;
    const r = new SR();
    r.continuous = true;
    r.interimResults = true;
    r.lang = "en-US";
    r.maxAlternatives = 3;
    r.onresult = (e: any) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const res = e.results[i];
        const txt = Array.from({ length: res.length }, (_, k) => res[k].transcript).join(" | ");
        if (res.isFinal) this.onFinal?.(txt);
        else this.onInterim?.(res[0].transcript);
      }
    };
    r.onerror = (e: any) => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        this.active = false;
        this.onState?.(false, "denied");
      }
    };
    r.onend = () => {
      if (this.active) setTimeout(() => { try { r.start(); } catch { /* already started */ } }, 250);
      else this.onState?.(false);
    };
    r.onstart = () => this.onState?.(true);
    this.rec = r;
  }

  start() {
    if (!this.rec || this.active) return;
    this.active = true;
    try { this.rec.start(); } catch { /* */ }
  }
  stop() {
    this.active = false;
    try { this.rec?.stop(); } catch { /* */ }
  }
}
