import { EmoEngine } from "./engine";
import * as snd from "./sound";
import type { FaceInfo } from "./vision";
import type { Cmd } from "./commands";

const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const pick = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)];
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const CANCEL = Symbol("cancel");

type W = (ms: number) => Promise<void>;
type ActionFn = (w: W, alive: () => boolean) => Promise<void>;

export interface Hooks {
  search?: (q: string) => Promise<number>;
  stopMusic?: () => void;
  pauseMusic?: () => void;
  resumeMusic?: () => void;
  nextTrack?: () => void;
  prevTrack?: () => void;
  volume?: (dir: 1 | -1) => void;
  pick?: (n: number) => void;
  camera?: (on: boolean) => void;
  remember?: () => Promise<boolean>;
  forget?: () => void;
  hasResults?: () => boolean;
}

const DJ_COLORS: [number, number, number][] = [
  [62, 244, 255], [255, 92, 220], [140, 255, 120], [255, 210, 80], [170, 140, 255], [255, 120, 90],
];

interface DjMode { id: string; expr: string; sing: boolean; tilt: number; scratch?: boolean; nod?: boolean; confetti?: boolean; bang?: boolean }
const DJ_MODES: DjMode[] = [
  { id: "bounce", expr: "sing", sing: true, tilt: 7 },
  { id: "eq", expr: "eq", sing: false, tilt: 4 },
  { id: "love", expr: "love", sing: true, tilt: 6 },
  { id: "vinyl", expr: "vinyl", sing: false, tilt: 3, scratch: true },
  { id: "cool", expr: "cool", sing: true, tilt: 5, nod: true },
  { id: "star", expr: "excited", sing: true, tilt: 9, confetti: true },
  { id: "bang", expr: "laugh", sing: true, tilt: 15, bang: true },
];

export class Brain {
  hooks: Hooks = {};
  token = 0;
  busy = false;
  sleeping = false;
  musicOn = false;
  djSrc: "yt" | "own" | "" = "";
  djModeIdx = 0;
  djColorIdx = 0;
  mood = 0.3;
  lastInteract = performance.now();
  private nextIdle = performance.now() + 4000;
  private lastZzz = 0;
  private ownTimeout: number | null = null;
  private timer: { end: number; total: number } | null = null;
  private petting = false;
  private dragging = false;
  private released = false;
  private taps: number[] = [];
  private vis = { present: false, lastSeen: 0, since: 0, greeted: true, away: 0, hold: {} as Record<string, number>, lastMimic: 0, lastClose: 0, everSeen: false };
  private perkAt = 0;
  private tickId = 0;
  onTimerChange?: (t: { remaining: number; total: number } | null) => void;
  actions: Record<string, ActionFn> = {};

  constructor(public e: EmoEngine) {
    e.onBeat = (n) => this.onBeat(n);
    this.defineActions();
    e.setExpr("neutral");
  }

  start() {
    this.tickId = window.setInterval(() => this.tick(), 200);
  }
  destroy() { clearInterval(this.tickId); }

  /* ---------- core runner ---------- */
  run(name: string, fn: ActionFn) {
    const my = ++this.token;
    const e = this.e;
    e.resetFx();
    e.autoGaze = true;
    if (name !== "sleep") this.sleeping = false;
    this.busy = true;
    const w: W = (ms) => new Promise((res, rej) => setTimeout(() => (this.token === my ? res() : rej(CANCEL)), ms));
    fn(w, () => this.token === my)
      .catch((err) => { if (err !== CANCEL) console.error(err); })
      .finally(() => {
        if (this.token === my) { this.busy = false; this.after(); }
      });
  }

  private after() {
    const e = this.e;
    e.resetFx();
    e.autoGaze = true;
    e.tweak({ bright: 1 });
    if (this.sleeping) { e.setExpr("sleep"); e.look(0, 0.3); return; }
    if (this.musicOn) { this.applyDjMode(); return; }
    e.setExpr("neutral");
    this.nextIdle = performance.now() + rnd(4000, 9000);
  }

  act(id: string) {
    this.lastInteract = performance.now();
    const f = this.actions[id];
    if (f) this.run(id, f);
  }

  private x(name: string, extra?: any) { this.e.setExpr(name, extra); }

  /* ---------- particle helpers ---------- */
  private hearts(n: number, spread = 1) {
    for (let i = 0; i < n; i++)
      this.e.emit("heart", 1, { x: rnd(260, 540) * spread + 400 * (1 - spread), y: rnd(420, 540), vx: rnd(-25, 25), vy: rnd(-150, -90), max: 1.9, size: rnd(0.7, 1.4), rot: rnd(0, 6) });
  }
  private sparks(n: number) {
    for (let i = 0; i < n; i++)
      this.e.emit("spark", 1, { x: rnd(130, 670), y: rnd(120, 560), vy: rnd(-40, 0), max: rnd(0.7, 1.3), size: rnd(0.8, 1.6), vr: rnd(-3, 3) });
  }
  private tears() {
    for (const x of [250, 550]) this.e.emit("tear", 1, { x: x + rnd(-24, 24), y: 470, vy: 30, g: 520, max: 1.4, size: rnd(0.8, 1.2) });
  }
  private sweat(n = 1) {
    for (let i = 0; i < n; i++) this.e.emit("drop", 1, { type: "sweat", x: pick([180, 620]) + rnd(-20, 20), y: 260 + rnd(0, 40), vy: 20, g: 420, max: 1.3, size: rnd(0.9, 1.3) });
  }
  private notes(n = 1) {
    for (let i = 0; i < n; i++)
      this.e.emit("note", 1, { text: pick(["♪", "♫", "♬"]), x: pick([rnd(40, 150), rnd(650, 760)]), y: rnd(400, 600), vx: rnd(-20, 20), vy: rnd(-130, -80), max: 2.2, size: rnd(0.8, 1.3), rot: rnd(0, 3), hue: pick([180, 300, 100, 45, 260]) });
  }
  private confetti(n: number) {
    for (let i = 0; i < n; i++)
      this.e.emit("confetti", 1, { x: rnd(60, 740), y: rnd(-40, 40), vx: rnd(-50, 50), vy: rnd(60, 190), g: 30, max: rnd(2.5, 4), size: rnd(0.8, 1.6), vr: rnd(-9, 9), hue: rnd(0, 360) });
  }
  private tiltWiggle(amt: number, n: number, ms: number, w: W) {
    return (async () => {
      for (let i = 0; i < n; i++) { this.e.head.tilt.t = (i % 2 ? -1 : 1) * amt; this.e.bump(-180); await w(ms); }
      this.e.head.tilt.t = 0;
    })();
  }

  /* ---------- actions ---------- */
  private defineActions() {
    const e = this.e;
    const A = this.actions;
    const x = this.x.bind(this);

    A.hello = async (w) => {
      x("happy"); snd.chirp("hello"); e.look(0, 0); this.sparks(4);
      await this.tiltWiggle(9, 4, 260, w); await w(700); this.mood = clamp(this.mood + 0.1, -1, 1);
    };
    A.happy = async (w) => { x("happy"); snd.chirp("happy"); this.sparks(5); e.bump(-400); await this.tiltWiggle(6, 4, 300, w); await w(900); this.mood = clamp(this.mood + 0.1, -1, 1); };
    A.laugh = async (w) => {
      x("laugh"); snd.chirp("laugh"); e.fx.tremble = 1.5;
      for (let i = 0; i < 9; i++) { e.head.tilt.t = i % 2 ? -5 : 5; e.bump(-260); e.tweak({ open: i % 2 ? 0.6 : 1 }); await w(210); }
      e.fx.tremble = 0; x("happy"); await w(600); this.mood = clamp(this.mood + 0.15, -1, 1);
    };
    A.love = async (w) => {
      x("love"); snd.chirp("love");
      for (let i = 0; i < 9; i++) { this.hearts(2); e.pulse(1); e.head.sx.v += 2; e.head.sy.v += 2; await w(380); }
      await w(500); this.mood = clamp(this.mood + 0.2, -1, 1);
    };
    A.excited = async (w) => {
      x("excited"); snd.chirp("happy"); this.confetti(30); this.sparks(8);
      for (let i = 0; i < 8; i++) { e.head.tilt.t = i % 2 ? -10 : 10; e.bump(-420); if (i % 3 === 0) this.sparks(3); await w(280); }
      await w(400);
    };
    A.wink = async (w) => { x("neutral"); await w(300); x("wink"); snd.chirp("wink"); this.sparks(4); e.head.tilt.t = 6; e.bump(-250); await w(1100); };
    A.kiss = async (w) => { x("kiss"); snd.chirp("kiss"); await w(300); for (let i = 0; i < 4; i++) { this.hearts(2); await w(250); } await w(900); };
    A.silly = async (w) => { x("silly"); snd.chirp("laugh"); await this.tiltWiggle(8, 6, 300, w); await w(400); };
    A.cool = async (w) => { x("cool"); snd.chirp("proud"); e.look(0, 0); this.sparks(3); e.head.rotX.t = 8; await w(500); e.head.rotX.t = -4; await w(2200); };
    A.proud = async (w) => { x("proud"); snd.chirp("proud"); e.head.y.t = -12; this.sparks(5); await w(2300); };
    A.shy = async (w) => { x("shy"); snd.chirp("pet"); e.look(-0.9, 0.5); e.head.tilt.t = -6; this.hearts(2); await w(1200); e.look(0.9, 0.6); await w(1200); };
    A.curious = async (w) => {
      x("curious"); snd.chirp("curious"); e.autoGaze = false; e.look(0.8, -0.2); e.head.tilt.t = 10;
      e.emit("question", 1, { text: "?", x: 650, y: 190, vy: -20, max: 2, size: 1 }); await w(1000);
      e.look(-0.8, -0.1); e.head.tilt.t = -10; await w(1000);
    };
    A.huh = async (w) => {
      x("curious"); snd.chirp("curious"); e.look(0, -0.2); e.head.tilt.t = 12;
      e.emit("question", 1, { text: "?", x: 640, y: 180, vy: -20, max: 1.8, size: 1.1 }); await w(1500);
    };
    A.think = async (w) => {
      x("thinking"); e.autoGaze = false; e.look(-0.8, -0.7); await w(500); x("dots"); await w(1800);
      x("surprised"); snd.chirp("surprised"); e.emit("bang", 1, { text: "!", x: 640, y: 200, vy: -20, max: 1.2 }); await w(1100);
    };
    A.suspicious = async (w) => {
      x("suspicious"); e.autoGaze = false; e.look(0.9, 0); await w(800); e.look(-0.9, 0); await w(800); e.look(0, 0.05); snd.chirp("curious"); await w(1000);
    };
    A.bored = async (w) => {
      x("bored"); snd.chirp("sleepy"); e.autoGaze = false; e.look(-0.7, -0.3); await w(1300); e.look(0.7, 0.2); await w(1300); x("sleepy"); await w(1000);
      this.mood = clamp(this.mood - 0.05, -1, 1);
    };
    A.surprised = async (w) => {
      x("surprised"); snd.chirp("surprised"); e.fx.tremble = 2; e.emit("bang", 1, { text: "!", x: 640, y: 190, vy: -30, max: 1.4 }); e.bump(-650);
      await w(300); e.fx.tremble = 0; await w(1500);
    };
    A.scared = async (w) => {
      x("scared"); snd.chirp("scared"); e.fx.tremble = 5; e.look(0, 0.1);
      for (let i = 0; i < 6; i++) { this.sweat(1); e.look(rnd(-0.7, 0.7), rnd(-0.2, 0.3)); await w(450); }
    };
    A.sad = async (w) => { x("sad"); snd.chirp("sad"); e.look(0, 0.7); e.head.y.t = 14; e.head.tilt.t = -3; await w(3200); this.mood = clamp(this.mood - 0.05, -1, 1); };
    A.cry = async (w) => {
      x("cry"); snd.chirp("cry"); e.look(0, 0.5); e.fx.tremble = 1; e.head.y.t = 12;
      for (let i = 0; i < 11; i++) { this.tears(); await w(380); }
      x("sad"); await w(600);
    };
    A.angry = async (w) => {
      x("angry"); snd.chirp("angry"); e.emit("anger", 1, { x: 640, y: 170, vy: -10, max: 2.6, size: 1.3 });
      e.fx.tremble = 3;
      for (let i = 0; i < 6; i++) { e.head.x.t = i % 2 ? -8 : 8; e.bump(-120); await w(300); }
      e.head.x.t = 0; await w(700);
    };
    A.dizzy = async (w) => {
      x("dizzy"); snd.chirp("dizzy"); e.look(0, 0);
      for (let i = 0; i < 9; i++) { e.head.tilt.t = i % 2 ? -14 : 14; e.head.x.t = i % 2 ? -14 : 14; await w(260); }
      e.head.x.t = 0; e.head.tilt.t = 0; x("sick"); await w(1000);
    };
    A.dead = async (w) => { x("dead"); snd.chirp("sad"); e.head.tilt.t = -9; e.head.y.t = 20; await w(2400); x("surprised"); snd.chirp("surprised"); e.bump(-500); await w(900); };
    A.yawn = async (w) => { x("yawn"); snd.chirp("yawn"); e.look(0, -0.2); await w(2500); x("sleepy"); await w(700); };
    A.sleep = async (w) => {
      x("yawn"); snd.chirp("yawn"); await w(2200); x("sleepy"); await w(1300); x("sleep"); e.look(0, 0.3);
      e.djStop(); e.hp.t = 0; this.musicOn = false; snd.stopBeat();
      this.sleeping = true; e.emit("zzz", 1, { text: "Z", x: 600, y: 270, vx: 25, vy: -35, max: 3, size: 1 });
    };
    A.wake = async (w) => {
      this.sleeping = false; x("sleepy"); await w(500); x("yawn"); snd.chirp("yawn"); await w(1800);
      x("surprised"); e.bump(-400); await w(500); x("happy"); snd.chirp("hello"); await w(1000);
    };
    A.sick = async (w) => {
      x("sick"); await w(800); x("sneeze"); snd.chirp("sneeze"); e.bump(-800); e.head.tilt.t = -10;
      for (let i = 0; i < 5; i++) e.emit("drop", 1, { x: 400 + rnd(-60, 60), y: 600, vx: rnd(-200, 200), vy: rnd(-100, 60), g: 400, max: 0.9, size: 0.7 });
      await w(1200); e.head.tilt.t = 0; x("sick"); await w(1500);
    };
    A.glitch = async (w) => {
      x("neutral"); e.fx.glitch = 0.9; snd.chirp("glitch");
      for (let i = 0; i < 7; i++) { x(pick(["dizzy", "surprised", "scared", "cool", "angry", "neutral", "love"])); e.fx.glitch = rnd(0.4, 1); e.fx.tremble = 6; await w(170); }
      e.fx.glitch = 0; e.fx.tremble = 0; x("neutral"); await w(400); x("curious"); await w(800);
    };
    A.mood = async (w, alive) => {
      const id = this.mood > 0.45 ? "happy" : this.mood < -0.25 ? "sad" : "content";
      if (id === "content") { x("content"); snd.chirp("pet"); await w(2200); }
      else { const f = A[id]; await f(w, alive); }
    };
    A.birthday = async (w) => {
      x("excited"); snd.chirp("happy"); this.confetti(40); await w(600);
      x("sing"); e.fx.sing = true;
      const dur = snd.playMelody(snd.HAPPY_BIRTHDAY, 112);
      const end = performance.now() + (dur || 12) * 1000;
      let i = 0;
      while (performance.now() < end) {
        e.head.tilt.t = i % 2 ? -7 : 7; e.bump(-160); if (i % 3 === 0) { this.confetti(10); this.notes(1); } i++;
        await w(420);
      }
      e.fx.sing = false; this.confetti(40); x("love"); await this.tiltWiggle(8, 4, 300, w); this.hearts(6);
      await w(900);
    };
    A.dance = async (w) => {
      this.startDj("own", 122);
      snd.startBeat(122);
      if (this.ownTimeout) clearTimeout(this.ownTimeout);
      this.ownTimeout = window.setTimeout(() => this.stopDj(), 24000);
      await w(10);
    };
    A.musicOwn = async (w) => {
      this.startDj("own", 118);
      snd.startBeat(118);
      if (this.ownTimeout) clearTimeout(this.ownTimeout);
      this.ownTimeout = window.setTimeout(() => this.stopDj(), 90000);
      await w(10);
    };
    A.poke = async (w) => {
      x("squint"); snd.chirp("poke"); e.bump(-350); e.head.tilt.t = pick([-7, 7]); await w(400);
      x(pick(["laugh", "wink", "surprised", "happy"])); snd.chirp("laugh"); await w(1300);
    };
    A.handsup = async (w) => {
      this.released = false;
      x("terrified"); e.autoGaze = false; e.look(0, -0.2); snd.chirp("scared");
      e.emit("bang", 1, { text: "!", x: 400, y: 170, vy: -25, max: 1.4, size: 1.1 });
      e.hands.t = 1; e.fx.tremble = 3.5; e.head.y.v -= 560; e.head.sy.v -= 5; e.head.sx.v += 3;
      for (let i = 0; i < 24 && !this.released; i++) {
        if (i % 2 === 0) this.sweat(1);
        if (i % 6 === 3) { snd.chirp("scared"); e.look(rnd(-0.6, 0.6), rnd(-0.4, 0.2)); }
        await w(450);
      }
      e.fx.tremble = 0; e.hands.t = 0; x("relief"); snd.chirp("phew"); this.sweat(2); await w(1500);
      x("happy"); await w(900);
    };
    A.shoot = async (w, alive) => { await this.dodgeSeq(Math.random() < 0.2, w, alive); };
    A.dodge = async (w, alive) => { await this.dodgeSeq(false, w, alive); };
    A.clock = async (w) => {
      e.display("clock"); snd.chirp("ding"); e.autoGaze = false; await w(5500);
    };
    A.timerShow = async (w) => {
      if (!this.timer) { x("curious"); await w(1200); return; }
      e.display("timer", { remaining: 0, total: 1 }); await w(4500);
    };
    A.timerSet = async (w) => { snd.chirp("happy"); e.display("timer", { remaining: 0, total: 1 }); await w(3200); x("happy"); await w(700); };
    A.alarm = async (w) => {
      x("excited"); snd.alarm(9); e.fx.tremble = 2;
      for (let i = 0; i < 20; i++) { e.head.tilt.t = i % 2 ? -9 : 9; e.bump(-300); if (i % 4 === 0) this.sparks(5); await w(450); }
    };
    A.dice = async (w) => {
      e.autoGaze = false; snd.chirp("curious");
      const d: any = { value: 1, rot: 0 }; e.display("dice", d);
      for (let i = 0; i < 14; i++) { d.value = 1 + Math.floor(Math.random() * 6); d.rot = rnd(-0.5, 0.5); e.head.y.v -= 150; await w(70 + i * 18); }
      d.rot = 0; snd.chirp("ding"); await w(2600);
    };
    A.coin = async (w) => {
      e.autoGaze = false; snd.chirp("whoosh");
      const d: any = { angle: 0, face: "H" }; e.display("coin", d);
      const res = Math.random() < 0.5 ? "H" : "T";
      const steps = 30;
      for (let i = 0; i <= steps; i++) { d.angle = (i / steps) * Math.PI * 7 + (res === "T" ? 0 : Math.PI); d.face = Math.cos(d.angle) >= 0 ? "H" : "T"; await w(45); }
      d.angle = 0; d.face = res; e.head.y.v -= 200; snd.chirp("ding"); await w(2400);
    };
    A.weather = async (w, alive) => {
      x("dots"); e.look(0, -0.4);
      const info = await this.fetchWeather();
      if (!alive()) return;
      if (!info) { x("sad"); snd.chirp("sad"); await w(2000); return; }
      e.autoGaze = false;
      e.display("weather", info); snd.chirp("ding"); await w(5200);
      e.display("none");
      if (info.kind === "sun") { x("happy"); snd.chirp("happy"); this.sparks(5); }
      else if (info.kind === "rain" || info.kind === "storm") { x("sad"); snd.chirp("sad"); }
      else if (info.kind === "snow") { x("scared"); e.fx.tremble = 1.5; }
      else x("content");
      await w(2200);
    };
    A.found = async (w) => { x("happy"); snd.chirp("happy"); e.look(0, 0.8); this.sparks(3); await w(1400); x("curious"); e.look(0, 0.8); e.autoGaze = false; await w(1200); };
    A.notfound = async (w) => { x("sad"); snd.chirp("sad"); await w(2000); };
    A.searching = async (w) => { x("dots"); e.look(0, -0.5); snd.chirp("curious"); await w(30000); };
    A.remembered = async (w) => { x("love"); snd.chirp("love"); this.hearts(10); await w(2500); };
    A.perk = async (w) => { await w(10); };
    A.peekaboo = async (w) => { x("surprised"); snd.chirp("surprised"); e.bump(-500); await w(500); x("laugh"); snd.chirp("laugh"); this.sparks(6); this.hearts(2); await this.tiltWiggle(7, 5, 240, w); };
    A.greetOwner = async (w) => { x("love"); snd.chirp("love"); this.hearts(8); e.head.y.v -= 400; await w(600); x("happy"); await this.tiltWiggle(8, 4, 260, w); await w(500); };
    A.greetStranger = async (w) => {
      x("suspicious"); e.autoGaze = false; e.look(0, 0); snd.chirp("curious"); await w(1500);
      x("curious"); e.head.tilt.t = 9; await w(1100); x("happy"); snd.chirp("hello"); e.head.tilt.t = 0; await w(1100);
    };
    A.carried = async (w) => {
      x("scared"); snd.chirp("scared"); e.fx.tremble = 4;
      while (this.dragging) { if (Math.random() < 0.3) this.sweat(1); e.look(rnd(-0.5, 0.5), rnd(-0.3, 0.3)); await w(300); }
      e.fx.tremble = 0; e.head.x.t = 0; e.head.y.t = 0;
      await A.dizzy(w, () => true);
    };
    A.pet = async (w, alive) => {
      x("content", { blush: 1 }); snd.chirp("pet"); e.look(0, 0.2);
      while (this.petting && alive()) { this.hearts(1); e.pulse(0.6); await w(520); }
      x("happy", { blush: 0.8 }); snd.chirp("happy"); await w(1100); this.mood = clamp(this.mood + 0.2, -1, 1);
    };
    A.djend = async (w) => { x("proud"); snd.chirp("proud"); this.sparks(4); await w(1400); };
    A.lookAround = async (w) => {
      e.autoGaze = false;
      e.look(-0.9, 0); await w(600); e.look(0.9, 0); await w(700); e.look(0, 0); await w(300);
    };
    A.hum = async (w) => {
      x("content"); snd.chirp("pet");
      for (let i = 0; i < 6; i++) { this.notes(1); e.head.tilt.t = i % 2 ? -5 : 5; await w(500); }
    };
    A.worried = async (w) => { x("worried"); snd.chirp("sad"); e.head.tilt.t = -6; await w(2200); };
      }

  private async dodgeSeq(hit: boolean, w: W, alive: () => boolean) {
    const e = this.e;
    this.released = true;
    e.autoGaze = false;
    this.x("focus"); e.look(-0.9, 0); snd.chirp("curious"); e.head.tilt.t = 2;
    await w(650);
    this.x("suspicious"); await w(350);
    e.bullet.x = -140; e.bullet.y = 395; e.bullet.vx = 1500; e.bullet.on = true;
    snd.chirp("whoosh");
    e.look(-0.5, 0);
    while (alive() && e.bullet.x < 40) await w(16);
    if (!alive()) return;
    this.x("surprised", { w: 190, h: 235 }); snd.chirp("surprised");
    e.fx.timeScale = 0.16;
    if (!hit) {
      e.head.tilt.t = -34; e.head.rotX.t = 30; e.head.y.t = 44; e.head.x.t = 26;
      while (alive() && e.bullet.x < 560) { e.look(clamp((e.bullet.x - 400) / 300, -1, 1), 0); await w(16); }
    } else {
      while (alive() && e.bullet.x < 330) await w(16);
      e.bullet.on = false; e.fx.timeScale = 1; e.fx.flash = 1; snd.chirp("bang");
      e.head.x.v += 900; e.head.tilt.v += 500; this.x("dead"); await w(900);
      this.x("dizzy"); snd.chirp("dizzy"); await w(1500);
      this.x("angry"); snd.chirp("angry"); e.emit("anger", 1, { x: 640, y: 170, vy: -10, max: 2.4, size: 1.2 }); await w(1800);
      return;
    }
    if (!alive()) return;
    e.fx.timeScale = 0.6; await w(250);
    e.fx.timeScale = 1;
    e.head.tilt.t = 0; e.head.rotX.t = 0; e.head.y.t = 0; e.head.x.t = 0;
    await w(900);
    this.x("relief"); snd.chirp("phew"); this.sweat(3); e.look(0, 0);
    await w(1500);
    this.x("cool"); snd.chirp("proud"); this.sparks(8); e.head.rotX.t = 6;
    await w(2200);
  }

  private async fetchWeather(): Promise<{ kind: string; temp: number } | null> {
    try {
      const pos = await new Promise<GeolocationPosition>((res, rej) => navigator.geolocation.getCurrentPosition(res, rej, { timeout: 6000 }));
      const f = /^en-US/i.test(navigator.language) ? "&temperature_unit=fahrenheit" : "";
      const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${pos.coords.latitude}&longitude=${pos.coords.longitude}&current=temperature_2m,weather_code${f}`);
      const j = await r.json();
      const code = j.current.weather_code as number;
      let kind = "cloud";
      if (code <= 1) kind = "sun";
      else if (code <= 3 || code === 45 || code === 48) kind = "cloud";
      else if (code >= 71 && code <= 77) kind = "snow";
      else if (code >= 85 && code <= 86) kind = "snow";
      else if (code >= 95) kind = "storm";
      else kind = "rain";
      return { kind, temp: Math.round(j.current.temperature_2m) };
    } catch { return null; }
  }

  /* ---------- DJ ---------- */
  startDj(src: "yt" | "own", bpm = 118) {
    const e = this.e;
    this.sleeping = false;
    if (src === "yt") { snd.stopBeat(); if (this.ownTimeout) clearTimeout(this.ownTimeout); }
    const wasOn = this.musicOn;
    this.musicOn = true;
    this.djSrc = src;
    e.djStart(bpm);
    e.hp.t = 1;
    // take over from whatever action is running
    this.token++;
    this.busy = false;
    e.resetFx();
    if (!wasOn) {
      this.djModeIdx = 0;
      this.djColorIdx = 0;
      this.confetti(25);
      snd.chirp("happy");
    }
    this.applyDjMode();
  }

  stopDj() {
    if (!this.musicOn) return;
    this.musicOn = false;
    this.djSrc = "";
    snd.stopBeat();
    if (this.ownTimeout) clearTimeout(this.ownTimeout);
    this.e.djStop();
    this.e.hp.t = 0;
    this.run("djend", this.actions.djend);
  }

  private applyDjMode() {
    const e = this.e;
    const m = DJ_MODES[this.djModeIdx % DJ_MODES.length];
    const col = m.id === "love" ? [255, 96, 168] as [number, number, number] : DJ_COLORS[this.djColorIdx % DJ_COLORS.length];
    e.autoGaze = false;
    e.look(0, 0);
    e.setExpr(m.expr, { color: m.expr === "love" ? col : col });
    e.fx.sing = m.sing;
    if (!m.sing) e.tweak({ mouth: 0 });
    e.fx.hue = (this.djColorIdx * 55 + 190) % 360;
    e.fx.flash = 0.7;
  }

  private onBeat(n: number) {
    if (!this.musicOn || this.busy) return;
    const e = this.e;
    const m = DJ_MODES[this.djModeIdx % DJ_MODES.length];
    if (n % 12 === 0) {
      this.djModeIdx = (this.djModeIdx + 1 + Math.floor(Math.random() * 2)) % DJ_MODES.length;
      this.djColorIdx++;
      this.applyDjMode();
    }
    const dir = n % 2 ? 1 : -1;
    e.head.tilt.t = dir * m.tilt;
    e.bump(m.bang ? -380 : -240);
    if (m.scratch) { e.head.tilt.v += dir * 700; e.head.rotY.t = dir * 12; }
    else e.head.rotY.t = dir * 6;
    if (m.nod) e.head.rotX.t = n % 2 ? 12 : -3;
    if (m.bang) { e.head.rotX.t = n % 2 ? 16 : 0; e.head.x.t = dir * 18; }
    else e.head.x.t = dir * 6;
    if (n % 3 === 0) this.notes(1);
    if (m.confetti && n % 2 === 0) this.confetti(6);
    if (n % 4 === 0) this.sparks(2);
  }

  /* ---------- timers ---------- */
  startTimer(secs: number) {
    this.timer = { end: Date.now() + secs * 1000, total: secs };
    this.onTimerChange?.({ remaining: secs, total: secs });
    this.act("timerSet");
  }
  cancelTimer() { this.timer = null; this.onTimerChange?.(null); }

  /* ---------- tick ---------- */
  private tick() {
    const now = performance.now();
    const e = this.e;
    if (this.timer) {
      const remaining = Math.max(0, (this.timer.end - Date.now()) / 1000);
      if (e.disp.type === "timer") e.disp.data = { remaining, total: this.timer.total };
      this.onTimerChange?.({ remaining: Math.ceil(remaining), total: this.timer.total });
      if (remaining <= 0) {
        this.timer = null; this.onTimerChange?.(null);
        this.act("alarm");
      }
    }
    if (this.sleeping && !this.busy) {
      if (now - this.lastZzz > 1900) {
        this.lastZzz = now;
        e.emit("zzz", 1, { text: "Z", x: 590, y: 280, vx: 22, vy: -34, max: 3.4, size: rnd(0.8, 1.2) });
      }
      e.head.sy.t = 1 + Math.sin(now / 900) * 0.012;
      return;
    }
    // slowly decay mood when ignored
    if (now - this.lastInteract > 45000 && !this.vis.present) this.mood = Math.max(-0.8, this.mood - 0.0008);
    if (this.busy || this.musicOn) return;

    // follow the user's head tilt when camera sees them
    if (this.vis.present && now - this.vis.lastSeen < 400) { /* handled in onVision */ }

    // auto sleep
    if (now - this.lastInteract > 150000 && !this.vis.present && !this.timer) { this.act("sleep"); return; }

    if (now > this.nextIdle) {
      this.nextIdle = now + rnd(5500, 11000);
      const engaged = this.vis.present;
      const pool: string[] = engaged
        ? ["happy", "wink", "curious", "hum", "lookAround", "think", "silly", "love", "proud"]
        : ["lookAround", "curious", "hum", "bored", "yawn", "think", "suspicious", "wink", "sneezeRare", "glitchRare", "happy", "dizzyRare"];
      if (this.mood < -0.35) pool.push("sad", "sad", "bored");
      if (this.mood > 0.5) pool.push("happy", "hum", "love");
      let id = pick(pool);
      if (id === "sneezeRare") id = Math.random() < 0.4 ? "sick" : "lookAround";
      if (id === "glitchRare") id = Math.random() < 0.3 ? "glitch" : "curious";
      if (id === "dizzyRare") id = Math.random() < 0.3 ? "dizzy" : "lookAround";
      const f = this.actions[id];
      if (f) this.run(id, f);
    }
  }

  /* ---------- user input ---------- */
  exec(c: Cmd) {
    this.lastInteract = performance.now();
    this.mood = clamp(this.mood + 0.03, -1, 1);
    const h = this.hooks;
    switch (c.t) {
      case "act":
        if (c.id === "sleep" || this.actions[c.id]) this.act(c.id);
        break;
      case "play":
        this.act("searching");
        Promise.resolve(h.search?.(c.q) ?? 0).then((n) => this.act(n > 0 ? "found" : "notfound")).catch(() => this.act("notfound"));
        break;
      case "music-own": this.stopYtOnly(); this.act("musicOwn"); break;
      case "stop":
        this.timer = null; this.onTimerChange?.(null);
        h.stopMusic?.();
        if (this.musicOn) this.stopDj(); else this.act("happy");
        break;
      case "pause": h.pauseMusic?.(); break;
      case "resume": h.resumeMusic?.(); break;
      case "next": h.nextTrack?.(); break;
      case "prev": h.prevTrack?.(); break;
      case "vol": h.volume?.(c.dir); break;
      case "pick": h.pick?.(c.n); break;
      case "timer": this.startTimer(c.secs); break;
      case "timer-show": this.act("timerShow"); break;
      case "timer-cancel": this.cancelTimer(); this.act("happy"); break;
      case "clock": this.act("clock"); break;
      case "weather": this.act("weather"); break;
      case "dice": this.act("dice"); break;
      case "coin": this.act("coin"); break;
      case "camera": h.camera?.(c.on); this.act(c.on ? "hello" : "curious"); break;
      case "remember":
        this.act("lookAround");
        h.remember?.()?.then((ok) => this.act(ok ? "remembered" : "notfound"));
        break;
      case "forget": h.forget?.(); this.act("sad"); break;
      case "release": this.released = true; break;
      case "unknown": this.act("huh"); break;
    }
  }
  private stopYtOnly() { if (this.djSrc === "yt") this.hooks.stopMusic?.(); }

  /** user said "Emo" – perk up (and wake) */
  perk() {
    const now = performance.now();
    if (now - this.perkAt < 3000) return;
    this.perkAt = now;
    this.lastInteract = now;
    if (this.sleeping) { this.act("wake"); return; }
    if (!this.busy) {
      this.e.tweak({ h: 205, w: 165 });
      this.e.look(0, 0);
      this.e.bump(-300);
      snd.chirp("poke");
      setTimeout(() => { if (!this.busy) this.e.tweak(this.musicOn ? {} : { h: 175, w: 150 }); }, 1800);
    }
  }

  touch(kind: "tap" | "pet-start" | "pet-end" | "drag-start" | "drag-end" | "shake") {
    const now = performance.now();
    this.lastInteract = now;
    if (this.timer === null && this.actions.alarm) { /* no-op */ }
    switch (kind) {
      case "tap": {
        if (this.sleeping) { this.act("wake"); return; }
        this.taps = this.taps.filter((t) => now - t < 1400); this.taps.push(now);
        if (this.taps.length >= 5) { this.taps = []; this.act("dizzy"); }
        else if (this.taps.length >= 3) this.act("angry");
        else this.act("poke");
        break;
      }
      case "pet-start": this.petting = true; if (this.sleeping) this.act("wake"); else this.act("pet"); break;
      case "pet-end": this.petting = false; break;
      case "drag-start": this.dragging = true; this.petting = false; this.act("carried"); break;
      case "drag-end": this.dragging = false; break;
      case "shake": if (!this.busy) this.act("dizzy"); break;
    }
  }

  /* ---------- camera ---------- */
  onVision(f: FaceInfo) {
    const now = performance.now();
    const v = this.vis;
    const e = this.e;
    if (f.present) {
      if (!v.present) {
        v.away = now - v.lastSeen;
        v.present = true; v.since = now; v.greeted = false;
      }
      v.lastSeen = now;
      this.lastInteract = now;
      if (!this.sleeping && !this.busy) {
        e.autoGaze = false;
        e.lookFor(f.x * 0.95, f.y * 0.8 + 0.05, 700);
        if (!this.musicOn) {
          e.head.tilt.t = clamp(-f.roll * 0.55, -14, 14);
          e.head.x.t = f.x * 14;
        }
      }
      if (this.busy) return;
      // greeting
      if (!v.greeted && now - v.since > (f.count ? 1300 : 500)) {
        v.greeted = true;
        if (this.sleeping) { this.act("wake"); return; }
        if (v.everSeen && v.away > 800 && v.away < 7000) this.act("peekaboo");
        else if (f.known) this.act("greetOwner");
        else if (f.identity === -1 && f.blinkL === 0 && f.smile === 0 && f.jaw === 0) this.act("hello"); // motion-only tracking
        else this.act(this.knownCount > 0 ? "greetStranger" : "hello");
        v.everSeen = true;
        return;
      }
      if (this.sleeping || this.musicOn) return;
      // mimic expressions
      const h = v.hold;
      const hit = (k: string, cond: boolean, frames: number) => {
        h[k] = cond ? (h[k] || 0) + 1 : 0;
        return h[k] >= frames;
      };
      if (now - v.lastMimic < 4500 || !v.greeted) return;
      const trig = (id: string) => { v.lastMimic = now; for (const k in h) h[k] = 0; this.act(id); };
      if (hit("tongue", f.tongue > 0.5, 4)) trig("silly");
      else if (hit("pucker", f.pucker > 0.65, 4)) trig("kiss");
      else if (hit("wink", Math.abs(f.blinkL - f.blinkR) > 0.55 && Math.max(f.blinkL, f.blinkR) > 0.65, 4)) trig("wink");
      else if (hit("jaw", f.jaw > 0.6 && f.smile < 0.5, 4)) trig("surprised");
      else if (hit("smile", f.smile > 0.55, 5)) trig(Math.random() < 0.35 ? "love" : "happy");
      else if (hit("frown", f.frown > 0.4 && f.smile < 0.2, 8)) trig("worried");
      else if (hit("brow", f.brow > 0.75, 5)) trig("curious");
      else if (f.size > 0.62 && now - v.lastClose > 25000) { v.lastClose = now; trig("shy"); }
    } else if (v.present && now - v.lastSeen > 1600) {
      v.present = false;
      if (!this.busy && !this.musicOn && !this.sleeping) {
        e.head.tilt.t = 0; e.head.x.t = 0;
        if (now - v.since > 5000) this.act("lookAround");
      }
    }
  }
  knownCount = 0;
}
