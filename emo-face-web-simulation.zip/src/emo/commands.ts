export type Cmd =
  | { t: "act"; id: string }
  | { t: "play"; q: string }
  | { t: "music-own" }
  | { t: "stop" } | { t: "pause" } | { t: "resume" } | { t: "next" } | { t: "prev" }
  | { t: "vol"; dir: 1 | -1 }
  | { t: "pick"; n: number }
  | { t: "timer"; secs: number } | { t: "timer-show" } | { t: "timer-cancel" }
  | { t: "clock" } | { t: "weather" } | { t: "dice" } | { t: "coin" }
  | { t: "camera"; on: boolean } | { t: "remember" } | { t: "forget" }
  | { t: "release" }
  | { t: "unknown" };

const WAKE = /\b(?:hey |hi |ok |okay |yo )?(emo|e-mo|eemo|emmo|emu|imo|amo|aymo|emoh|ee mo|e mo|emma|ema|himo|eimo|aimo)\b[\s,.!?]*/;

export function hasWake(text: string) {
  return WAKE.test(text.toLowerCase());
}

const NUMW: Record<string, number> = {
  a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10,
  fifteen: 15, twenty: 20, thirty: 30, forty: 40, forty_five: 45, sixty: 60, half: 0.5,
};

const PICK: Record<string, number> = {
  one: 1, "1": 1, first: 1, two: 2, "2": 2, second: 2, three: 3, "3": 3, third: 3,
  four: 4, "4": 4, fourth: 4, five: 5, "5": 5, fifth: 5, six: 6, "6": 6, sixth: 6,
};

export function parse(raw: string, o: { requireWake: boolean; hasResults: boolean }): { woke: boolean; cmd: Cmd | null } {
  // raw may contain several alternatives separated by " | "
  const alts = raw.toLowerCase().split("|").map((s) => s.trim()).filter(Boolean);
  let woke = false;
  let best: Cmd | null = null;
  for (const a of alts) {
    let t = a;
    const m = t.match(WAKE);
    if (m) { woke = true; t = t.slice((m.index || 0) + m[0].length); }
    else if (o.requireWake && !(o.hasResults && PICK_RE.test(t))) continue;
    t = t.replace(/^(please|can you|could you|will you|would you|let's|lets)\s+/g, "").trim();
    const c = match(t, o.hasResults);
    if (c && c.t !== "unknown") return { woke, cmd: c };
    if (!best && t.length > 1) best = c;
  }
  return { woke, cmd: woke || !o.requireWake ? best : null };
}

const PICK_RE = /^(?:play |pick |choose |select |the )?(?:number |option |song |track )?(one|two|three|four|five|six|1|2|3|4|5|6|first|second|third|fourth|fifth|sixth)(?: one| song)?$/;

function act(id: string): Cmd { return { t: "act", id }; }

function match(t: string, hasResults: boolean): Cmd {
  if (!t) return { t: "unknown" };
  let m: RegExpMatchArray | null;

  if (hasResults && (m = t.match(PICK_RE))) return { t: "pick", n: PICK[m[1]] };
  if (/hands? (down|back)|put (them|your hands?) down|relax|at ease|calm down|it'?s ok|you can lower/.test(t)) return { t: "release" };
  if (/hands? up|stick ?(em|them|'em) up|put (your|ya) hands|freeze|don'?t move|this is a (hold ?up|robbery)|raise your hands/.test(t)) return act("handsup");
  if (/dodge|bullet|matrix|duck\b|incoming|neo\b|look out/.test(t)) return act("dodge");
  if (/\b(bang|shoot|pew|gun|fire)\b/.test(t)) return act("shoot");
  if (/play dead|pretend (to be )?dead|die\b/.test(t)) return act("dead");
  if (/play (by yourself|with me|a game)|go play|explore/.test(t)) return act("dance");
  if (/happy birthday|(it'?s|its) my birthday|birthday/.test(t)) return act("birthday");

  // timers
  if ((m = t.match(/(?:set|start|make)?\s*(?:a |an )?(\d+|a|an|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty|sixty|half)?\s*(?:and a half )?(second|minute|hour)s?\s*timer/))
    || (m = t.match(/timer (?:for )?(\d+|a|an|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty|sixty|half)\s*(second|minute|hour)s?/))
    || (m = t.match(/(?:in|for) (\d+|a|an|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty|sixty|half)\s*(second|minute|hour)s?.*(?:wake|remind|alarm|timer)/))) {
    const n = m[1] ? (isNaN(+m[1]) ? NUMW[m[1]] ?? 1 : +m[1]) : 1;
    const unit = m[2] === "hour" ? 3600 : m[2] === "minute" ? 60 : 1;
    return { t: "timer", secs: Math.max(1, Math.round(n * unit)) };
  }
  if (/cancel .*timer|stop .*timer|clear .*timer/.test(t)) return { t: "timer-cancel" };
  if (/(how much|time left|timer)/.test(t) && /left|remaining|much|show|timer/.test(t)) return { t: "timer-show" };

  if (/what('?s| is) the time|what time|clock|show (me )?the time|time is it|tell me the time/.test(t)) return { t: "clock" };
  if (/weather|temperature|forecast|is it (raining|sunny|cold|hot)|how'?s it outside/.test(t)) return { t: "weather" };
  if (/(roll|throw).*(die|dice)|\bdice\b|\bdie\b/.test(t)) return { t: "dice" };
  if (/(flip|toss).*coin|coin (flip|toss)|heads or tails/.test(t)) return { t: "coin" };

  if (/(turn|switch) (on|off) (the |your )?(camera|eyes)|(open|close) your eyes|look at me|see me/.test(t)) {
    return { t: "camera", on: !/off|close/.test(t) };
  }
  if (/remember me|learn my face|who am i|know me|this is me|recogni[sz]e me/.test(t)) return { t: "remember" };
  if (/forget (me|my face|everyone|faces)/.test(t)) return { t: "forget" };

  // music
  if (/^(stop|pause|quiet|silence|shut up|be quiet|enough|stop (the )?(music|song|dancing|dance|it)|stop playing|that'?s enough|turn (it|the music) off)$/.test(t)) {
    return /^pause/.test(t) ? { t: "pause" } : { t: "stop" };
  }
  if (/^(pause( the)?( music| song)?)$/.test(t)) return { t: "pause" };
  if (/^(resume|continue|unpause|keep (playing|going)|play( the music| it)?( again)?)$/.test(t)) return { t: "resume" };
  if (/^(next|skip|next song|skip (it|song)|another( one)?|play next)$/.test(t)) return { t: "next" };
  if (/^(previous|previous song|go back|last song|back)$/.test(t)) return { t: "prev" };
  if (/(volume up|louder|turn (it|the (music|volume)) up|crank it)/.test(t)) return { t: "vol", dir: 1 };
  if (/(volume down|quieter|softer|turn (it|the (music|volume)) down|lower the volume)/.test(t)) return { t: "vol", dir: -1 };
  if (/^(music|some music|dance music|dj|let'?s dance|dance for me|dance|boogie|put on some music|play (some )?music|sing( a song)?|sing for me|play something|play a song)$/.test(t)) {
    return /^(sing|play)/.test(t) || /music|dj/.test(t) ? { t: "music-own" } : act("dance");
  }
  if ((m = t.match(/^(?:play|put on|sing|queue( up)?|search( for)?|find|listen to|i want to hear|i wanna hear|show me)\s+(.+)$/))) {
    const q = m[m.length - 1].replace(/^(the song|a song|the track|some)\s+/, "").replace(/\s+(on|from) (youtube|youtube music|spotify)$/, "").trim();
    if (q && q.length > 1 && !/^(dead|music|something)$/.test(q)) return { t: "play", q };
  }

  // moods / expressions
  const E: [RegExp, string][] = [
    [/wake up|get up|good morning|rise and shine/, "wake"],
    [/go to sleep|sleep|good ?night|nap|bedtime|time for bed/, "sleep"],
    [/\b(hello|hi|hey|hiya|howdy|what'?s up|sup)\b/, "hello"],
    [/dance|boogie|groove|disco|party time/, "dance"],
    [/laugh|joke|funny|lol|haha|make me laugh/, "laugh"],
    [/i love you|love|heart|good (boy|robot|job|emo)|cute|adorable|best|hug|cuddle/, "love"],
    [/\bhappy|smile|cheer up|good mood|joy/, "happy"],
    [/\bsad|frown|unhappy|upset/, "sad"],
    [/cry|weep|tears/, "cry"],
    [/angry|mad|grr|annoyed|furious|rage|get mad/, "angry"],
    [/scare|scary|boo\b|afraid|ghost|spooky|monster|frightened/, "scared"],
    [/surprise|wow|no way|really|omg/, "surprised"],
    [/wink|hey there handsome/, "wink"],
    [/kiss|mwah|smooch/, "kiss"],
    [/tongue|silly|blep|goofy|raspberry/, "silly"],
    [/cool|sunglasses|shades|swag|chill/, "cool"],
    [/shy|blush|compliment|thank|thanks|you'?re (great|awesome|amazing)/, "shy"],
    [/think|hmm|ponder|wonder/, "think"],
    [/curious|what'?s that|interesting/, "curious"],
    [/bored|boring|nothing to do/, "bored"],
    [/suspicious|sus\b|doubt|really\?|sceptical|skeptical/, "suspicious"],
    [/sneeze|sick|cold|achoo|ill\b/, "sick"],
    [/dizzy|spin|spinning|drunk|round and round/, "dizzy"],
    [/yawn|tired|sleepy|exhausted/, "yawn"],
    [/glitch|malfunction|bug|error|crash|hack/, "glitch"],
    [/excited|yay|celebrate|hooray|woo|awesome|amazing|let'?s go|fantastic/, "excited"],
    [/proud|flex|show off|boss/, "proud"],
    [/how are you|how do you feel|feeling|mood/, "mood"],
    [/who are you|your name|introduce|what are you|what can you do|help/, "hello"],
  ];
  for (const [re, id] of E) if (re.test(t)) return act(id);
  return { t: "unknown" };
}
