import { DEF, PRESETS, type Expr, type Kind } from "./expressions";

class Spring {
  x: number; v = 0; t: number;
  constructor(x: number, public k = 260, public c = 24) { this.x = x; this.t = x; }
  step(dt: number) {
    const n = Math.max(1, Math.ceil(dt / 0.008));
    const h = dt / n;
    for (let i = 0; i < n; i++) {
      this.v += ((this.t - this.x) * this.k - this.v * this.c) * h;
      this.x += this.v * h;
    }
  }
  snap(x: number) { this.x = x; this.t = x; this.v = 0; }
}

const NUM_KEYS = [
  "w", "h", "r", "gap", "y", "tilt", "slant", "topLid", "botLid", "hR", "lidR", "yR",
  "mouth", "open", "smile", "mw", "tongue", "blush", "bright",
] as const;
type NumKey = (typeof NUM_KEYS)[number];

interface KindState { cur: Kind; target: Kind; s: Spring; }

type PType = "heart" | "note" | "zzz" | "tear" | "sweat" | "spark" | "bang" | "question" | "anger" | "confetti" | "drop" | "dot";
interface Particle {
  type: PType; x: number; y: number; vx: number; vy: number; g: number;
  life: number; max: number; size: number; rot: number; vr: number; text?: string; hue?: number;
}

export interface FrameInfo {
  tilt: number; x: number; y: number; sx: number; sy: number; rotX: number; rotY: number;
  beat: number; hp: number; djOn: boolean; energy: number; hue: number; flash: number;
  color: [number, number, number]; bright: number;
}

export type DisplayType = "none" | "clock" | "timer" | "weather" | "dice" | "coin";

const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export class EmoEngine {
  cv: HTMLCanvasElement;
  c: CanvasRenderingContext2D;
  W = 800;
  dpr = 1;
  P = {} as Record<NumKey, Spring>;
  col = [new Spring(62, 80, 14), new Spring(244, 80, 14), new Spring(255, 80, 14)];
  kL: KindState = { cur: "rect", target: "rect", s: new Spring(1, 520, 34) };
  kR: KindState = { cur: "rect", target: "rect", s: new Spring(1, 520, 34) };
  base: Expr = { ...DEF };
  lx = new Spring(0, 170, 20);
  ly = new Spring(0, 170, 20);
  gazeLock = 0;
  nextSaccade = 0;
  autoGaze = true;
  head = {
    tilt: new Spring(0, 120, 11), x: new Spring(0, 140, 13), y: new Spring(0, 140, 13),
    sx: new Spring(1, 200, 12), sy: new Spring(1, 200, 12), rotX: new Spring(0, 100, 12), rotY: new Spring(0, 100, 12),
  };
  hands = new Spring(0, 90, 11);
  hp = new Spring(0, 70, 11);
  beatPulse = new Spring(0, 180, 13);
  disp = { type: "none" as DisplayType, a: new Spring(0, 120, 18), data: {} as any };
  fx = { glitch: 0, flash: 0, tremble: 0, timeScale: 1, blinkOn: true, sing: false, hue: 190 };
  parts: Particle[] = [];
  bullet: { x: number; y: number; vx: number; on: boolean } = { x: -100, y: 360, vx: 0, on: false };
  dj = {
    on: false, bpm: 120, energy: 0, bars: [0.3, 0.5, 0.7, 0.5, 0.3], tgt: [0, 0, 0, 0, 0],
    nextBeat: 0, lastBeat: 0, beat: 0, external: 0,
  };
  t = 0;
  last = 0;
  raf = 0;
  blink = 0;
  blinkPhase = -1;
  nextBlink = 2000;
  onFrame?: (f: FrameInfo) => void;
  onBeat?: (n: number) => void;
  blur = 0;

  constructor(cv: HTMLCanvasElement) {
    this.cv = cv;
    this.c = cv.getContext("2d")!;
    for (const k of NUM_KEYS) this.P[k] = new Spring((DEF as any)[k]);
    this.P.bright.k = 60; this.P.bright.c = 14;
    this.P.tilt.k = 160; this.P.tilt.c = 16;
    this.resize();
  }

  resize() {
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    const px = 800 * this.dpr;
    if (this.cv.width !== px) { this.cv.width = px; this.cv.height = px; }
  }

  start() {
    this.last = performance.now();
    const loop = (now: number) => {
      this.raf = requestAnimationFrame(loop);
      this.frame(now);
    };
    this.raf = requestAnimationFrame(loop);
  }
  stop() { cancelAnimationFrame(this.raf); }

  /* ---------- state API ---------- */
  setExpr(name: string | Partial<Expr>, extra?: Partial<Expr>) {
    const p = typeof name === "string" ? PRESETS[name] || {} : name;
    const e: Expr = { ...DEF, ...p, ...extra };
    this.base = e;
    for (const k of NUM_KEYS) this.P[k].t = (e as any)[k];
    for (let i = 0; i < 3; i++) this.col[i].t = e.color[i];
    this.setKind(this.kL, e.kind);
    this.setKind(this.kR, e.kindR || e.kind);
  }
  tweak(p: Partial<Expr>) {
    for (const k of NUM_KEYS) if ((p as any)[k] !== undefined) this.P[k].t = (p as any)[k];
    if (p.color) for (let i = 0; i < 3; i++) this.col[i].t = p.color[i];
  }
  private setKind(s: KindState, k: Kind) { s.target = k; }
  look(x: number, y: number) { this.lx.t = clamp(x, -1.2, 1.2); this.ly.t = clamp(y, -1.2, 1.2); }
  lookFor(x: number, y: number, ms: number) { this.look(x, y); this.gazeLock = performance.now() + ms; }
  display(type: DisplayType, data: any = {}) {
    this.disp.type = type !== "none" ? type : this.disp.type;
    this.disp.data = data;
    this.disp.a.t = type === "none" ? 0 : 1;
  }
  emit(type: PType, n = 1, o: Partial<Particle> = {}) {
    for (let i = 0; i < n; i++) {
      const base: Particle = {
        type, x: 400, y: 400, vx: 0, vy: -60, g: 0, life: 0, max: 2, size: 1, rot: 0, vr: 0,
      };
      this.parts.push(Object.assign(base, o));
    }
  }
  pulse(amount = 1) { this.beatPulse.x = Math.max(this.beatPulse.x, amount); this.beatPulse.v = 0; }
  bump(dy = -420) { this.head.y.v += dy; this.head.sy.v -= 3; this.head.sx.v += 2; }
  resetFx() {
    this.fx.timeScale = 1; this.fx.glitch = 0; this.fx.tremble = 0; this.fx.sing = false;
    this.hands.t = 0; this.bullet.on = false;
    this.head.tilt.t = 0; this.head.x.t = 0; this.head.y.t = 0; this.head.rotX.t = 0; this.head.rotY.t = 0;
    this.head.sx.t = 1; this.head.sy.t = 1;
    this.disp.a.t = 0;
  }

  /* ---------- DJ ---------- */
  djStart(bpm = 120) {
    this.dj.on = true; this.dj.bpm = bpm; this.dj.nextBeat = performance.now() + 200; this.dj.beat = 0;
  }
  djStop() { this.dj.on = false; this.dj.energy = 0; this.fx.sing = false; }
  djOnset(now = performance.now()) {
    if (!this.dj.on) return;
    this.dj.external = now;
    if (now - this.dj.lastBeat > 280) { this.fireBeat(now); this.dj.nextBeat = now + 60000 / this.dj.bpm; }
  }
  private fireBeat(now: number) {
    this.dj.lastBeat = now;
    this.dj.beat++;
    this.pulse(1);
    this.onBeat?.(this.dj.beat);
  }

  /* ---------- frame ---------- */
  private frame(now: number) {
    const real = clamp((now - this.last) / 1000, 0, 0.05);
    this.last = now;
    const dt = real * this.fx.timeScale;
    this.t += dt;
    this.update(dt, real, now);
    this.draw();
    const h = this.head;
    const breath = Math.sin(this.t * 1.7) * 3;
    this.onFrame?.({
      tilt: h.tilt.x, x: h.x.x, y: h.y.x + breath, sx: h.sx.x, sy: h.sy.x, rotX: h.rotX.x, rotY: h.rotY.x,
      beat: this.beatPulse.x, hp: this.hp.x, djOn: this.dj.on, energy: this.dj.energy, hue: this.fx.hue,
      flash: this.fx.flash, color: [this.col[0].x, this.col[1].x, this.col[2].x], bright: this.P.bright.x,
    });
  }

  private update(dt: number, real: number, now: number) {
    for (const k of NUM_KEYS) this.P[k].step(dt);
    for (const s of this.col) s.step(dt);
    for (const s of Object.values(this.head)) s.step(dt);
    this.lx.step(dt); this.ly.step(dt); this.hands.step(dt); this.hp.step(dt);
    this.beatPulse.t = 0; this.beatPulse.step(real);
    this.disp.a.step(real);
    this.fx.flash = Math.max(0, this.fx.flash - real * 3);
    for (const ks of [this.kL, this.kR]) {
      if (ks.cur !== ks.target) {
        ks.s.t = 0;
        if (ks.s.x < 0.14) { ks.cur = ks.target; ks.s.t = 1; }
      } else ks.s.t = 1;
      ks.s.step(real);
    }

    // idle gaze saccades
    if (this.autoGaze && now > this.gazeLock && now > this.nextSaccade) {
      this.nextSaccade = now + rnd(1400, 4200);
      this.lx.t = rnd(-0.35, 0.35); this.ly.t = rnd(-0.2, 0.2);
    }
    // blinking
    if (this.fx.blinkOn) {
      if (this.blinkPhase < 0 && now > this.nextBlink) { this.blinkPhase = 0; }
      if (this.blinkPhase >= 0) {
        this.blinkPhase += real / 0.2;
        this.blink = Math.sin(clamp(this.blinkPhase, 0, 1) * Math.PI);
        if (this.blinkPhase >= 1) {
          this.blinkPhase = -1; this.blink = 0;
          this.nextBlink = now + (Math.random() < 0.2 ? 250 : rnd(2200, 5600));
        }
      }
    } else this.blink = 0;

    // DJ clock + bars + singing
    const d = this.dj;
    if (d.on) {
      if (now - d.external > 900 && now >= d.nextBeat) {
        this.fireBeat(now);
        d.nextBeat += 60000 / d.bpm;
        if (d.nextBeat < now) d.nextBeat = now + 60000 / d.bpm;
      }
      for (let i = 0; i < 5; i++) {
        if (Math.random() < 0.18 + this.beatPulse.x * 0.5) d.tgt[i] = clamp(0.2 + Math.random() * 0.55 + d.energy * 0.5 + this.beatPulse.x * 0.3, 0.12, 1);
        d.bars[i] += (d.tgt[i] - d.bars[i]) * Math.min(1, real * 14);
      }
      if (this.fx.sing) {
        const syl = (Math.sin(this.t * 11) + Math.sin(this.t * 7.3 + 1)) * 0.25 + 0.5;
        this.P.mouth.t = 1;
        this.P.open.t = clamp(0.12 + syl * 0.8 + d.energy * 0.5 + this.beatPulse.x * 0.2, 0.05, 1.2);
        this.P.mw.t = 70 + syl * 55;
        this.P.smile.t = 0.5 + Math.sin(this.t * 3) * 0.3;
      }
    } else if (this.fx.sing) {
      // singing without DJ (birthday etc)
      const syl = (Math.sin(this.t * 10) + Math.sin(this.t * 6.1 + 1)) * 0.25 + 0.5;
      this.P.mouth.t = 1;
      this.P.open.t = 0.15 + syl * 0.9;
      this.P.mw.t = 70 + syl * 50;
    }

    // particles
    for (const p of this.parts) {
      p.life += dt;
      p.vy += p.g * dt;
      p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt;
      if (p.type === "heart" || p.type === "note" || p.type === "zzz") p.x += Math.sin(p.life * 3 + p.rot) * 0.6;
    }
    this.parts = this.parts.filter((p) => p.life < p.max);
    if (this.parts.length > 160) this.parts.splice(0, this.parts.length - 160);

    if (this.bullet.on) {
      this.bullet.x += this.bullet.vx * dt;
      if (this.bullet.x > 950) this.bullet.on = false;
    }
  }

  /* ---------- drawing ---------- */
  private rgba(a = 1) {
    return `rgba(${this.col[0].x | 0},${this.col[1].x | 0},${this.col[2].x | 0},${clamp(a, 0, 1)})`;
  }

  private draw() {
    const c = this.c;
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.clearRect(0, 0, this.cv.width, this.cv.height);
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const bright = clamp(this.P.bright.x, 0, 1.2);
    const dispA = this.disp.a.x;
    const handsA = this.hands.x;
    c.globalAlpha = bright;
    c.lineCap = "round"; c.lineJoin = "round";

    // tremble / shake
    const tr = this.fx.tremble;
    c.save();
    if (tr > 0) c.translate(rnd(-tr, tr), rnd(-tr, tr) * 0.6);

    c.save();
    c.globalAlpha = bright * (1 - dispA);
    if (c.globalAlpha > 0.01) {
      this.drawEye(1);
      this.drawEye(-1);
      if (this.kL.cur === "glass" && this.kR.cur === "glass") this.drawBridge();
      this.drawMouth();
      this.drawBlush();
    }
    c.restore();

    if (dispA > 0.01) { c.save(); c.globalAlpha = bright * dispA; this.drawDisplay(); c.restore(); }
    c.restore();

    this.drawParticles();
    if (this.bullet.on) this.drawBullet();
    if (handsA > 0.02) this.drawHands(handsA);

    // glitch post-process
    if (this.fx.glitch > 0.02) {
      const g = this.fx.glitch;
      c.setTransform(1, 0, 0, 1, 0, 0);
      c.globalAlpha = 1;
      const n = 3 + Math.floor(g * 8);
      for (let i = 0; i < n; i++) {
        const sy = Math.floor(rnd(0, this.cv.height - 40));
        const sh = Math.floor(rnd(6, 60 * this.dpr));
        const dx = Math.floor(rnd(-80, 80) * g * this.dpr);
        c.drawImage(this.cv, 0, sy, this.cv.width, sh, dx, sy, this.cv.width, sh);
      }
      if (Math.random() < g * 0.5) {
        c.fillStyle = this.rgba(0.8);
        for (let i = 0; i < 6; i++) c.fillRect(rnd(0, this.cv.width), rnd(0, this.cv.height), rnd(4, 24) * this.dpr, 3 * this.dpr);
      }
    }
  }

  private eyeBox(side: 1 | -1) {
    const right = side === -1;
    const P = this.P;
    const ks = right ? this.kR : this.kL;
    const lx = this.lx.x, ly = this.ly.x;
    const w = P.w.x * (1 - 0.08 * Math.abs(lx));
    const h = P.h.x * (right ? P.hR.x : 1);
    const cx = 400 - side * P.gap.x * 0.5 + lx * 55;
    const cy = 385 + P.y.x + (right ? P.yR.x : 0) + ly * 42 + Math.sin(this.t * 1.7) * 2;
    return { right, ks, w, h, cx, cy };
  }

  private drawEye(side: 1 | -1) {
    const c = this.c;
    const { right, ks, w, h: h0, cx, cy } = this.eyeBox(side);
    const P = this.P;
    const sc = clamp(ks.s.x, 0, 1.15);
    if (sc < 0.02) return;
    const kind = ks.cur;
    const solid = kind === "rect" || kind === "glass";
    const h = solid ? Math.max(6, h0 * (1 - this.blink * 0.94)) : h0;
    const col = this.rgba(1);

    c.save();
    c.translate(cx, cy);
    c.rotate((side * P.tilt.x * Math.PI) / 180);
    c.scale(side * (0.5 + 0.5 * sc), sc);
    c.fillStyle = col;
    c.strokeStyle = col;
    const thick = 28;

    switch (kind) {
      case "rect": {
        const r = Math.min(P.r.x, w / 2, h / 2);
        c.beginPath(); c.roundRect(-w / 2, -h / 2, w, h, r); c.clip();
        const lid = clamp(P.topLid.x + (right ? P.lidR.x : 0), 0, 0.95);
        const sl = P.slant.x;
        const yi = -h / 2 + h * (lid + sl * 0.5);
        const yo = -h / 2 + h * (lid - sl * 0.5);
        const yAt = (x: number) => yo + ((yi - yo) * (x + w / 2)) / w;
        c.beginPath(); c.moveTo(-w, yAt(-w)); c.lineTo(w, yAt(w)); c.lineTo(w, h); c.lineTo(-w, h); c.closePath(); c.clip();
        if (P.botLid.x > 0.01) {
          const edge = h / 2 - h * P.botLid.x * 0.25;
          const mid = h / 2 - h * P.botLid.x * 1.1;
          c.beginPath(); c.moveTo(-w, -h); c.lineTo(w, -h); c.lineTo(w, edge); c.quadraticCurveTo(0, 2 * mid - edge, -w, edge); c.closePath(); c.clip();
        }
        c.fillRect(-w, -h, w * 2, h * 2);
        break;
      }
      case "glass": {
        c.beginPath();
        c.roundRect(-w / 2, -h * 0.3 * (1 - this.blink * 0.5), w, h * 0.62, [14, 14, w * 0.38, w * 0.38]);
        c.fill();
        c.save();
        c.clip();
        c.strokeStyle = "rgba(0,0,0,0.75)";
        c.lineWidth = 12;
        const o = ((this.t * 40) % 120) - 60;
        for (let i = -1; i < 2; i++) { c.beginPath(); c.moveTo(-w / 2 + i * 55 + o * 0.3 + 10, h * 0.35); c.lineTo(-w / 2 + i * 55 + o * 0.3 + 80, -h * 0.35); c.stroke(); }
        c.restore();
        break;
      }
      case "arc": {
        c.lineWidth = thick;
        c.beginPath(); c.ellipse(0, h * 0.5, w / 2 - thick / 2, h, 0, Math.PI * 1.04, Math.PI * 1.96); c.stroke();
        break;
      }
      case "arcDown": {
        c.lineWidth = thick - 4;
        c.beginPath(); c.ellipse(0, -h * 0.5, w / 2 - thick / 2, h, 0, Math.PI * 0.04, Math.PI * 0.96); c.stroke();
        break;
      }
      case "line": {
        c.lineWidth = 18; c.beginPath(); c.moveTo(-w / 2, 0); c.lineTo(w / 2, 0); c.stroke();
        break;
      }
      case "heart": {
        const s = (w / 2) * (1 + this.beatPulse.x * 0.18 + Math.sin(this.t * 6) * 0.05);
        c.beginPath();
        c.moveTo(0, s * 0.9);
        c.bezierCurveTo(-s * 1.35, s * 0.1, -s * 0.95, -s * 0.95, 0, -s * 0.38);
        c.bezierCurveTo(s * 0.95, -s * 0.95, s * 1.35, s * 0.1, 0, s * 0.9);
        c.fill();
        break;
      }
      case "star": {
        const R = (w / 2) * (1 + Math.sin(this.t * 7 + side) * 0.08 + this.beatPulse.x * 0.1);
        c.rotate(Math.sin(this.t * 2) * 0.15);
        c.beginPath();
        for (let i = 0; i < 4; i++) {
          const a = (i * Math.PI) / 2 - Math.PI / 2;
          const nxt = a + Math.PI / 2;
          const mid = a + Math.PI / 4;
          if (i === 0) c.moveTo(Math.cos(a) * R, Math.sin(a) * R);
          c.quadraticCurveTo(Math.cos(mid) * R * 0.16, Math.sin(mid) * R * 0.16, Math.cos(nxt) * R, Math.sin(nxt) * R);
        }
        c.closePath();
        c.fill();
        break;
      }
      case "x": {
        c.lineWidth = 30;
        const s = w * 0.36;
        c.beginPath(); c.moveTo(-s, -s); c.lineTo(s, s); c.moveTo(s, -s); c.lineTo(-s, s); c.stroke();
        break;
      }
      case "spiral": {
        c.rotate(this.t * 7 * -side);
        c.lineWidth = 15;
        c.beginPath();
        const R = w / 2;
        for (let a = 0; a < Math.PI * 5; a += 0.15) {
          const r = (a / (Math.PI * 5)) * R;
          const x = Math.cos(a) * r, y = Math.sin(a) * r;
          if (a === 0) c.moveTo(x, y); else c.lineTo(x, y);
        }
        c.stroke();
        break;
      }
      case "bars": {
        const n = 5, bw = w / (n * 1.55);
        for (let i = 0; i < n; i++) {
          const bh = Math.max(bw, this.dj.bars[(i + (right ? 2 : 0)) % 5] * h);
          c.beginPath();
          c.roundRect(-w / 2 + i * (w / n) + (w / n - bw) / 2, -bh / 2, bw, bh, bw / 2);
          c.fill();
        }
        break;
      }
      case "vinyl": {
        const R = w / 2;
        const a = this.t * 5 * -side;
        c.lineWidth = 10;
        c.beginPath(); c.arc(0, 0, R - 5, 0, Math.PI * 2); c.stroke();
        c.globalAlpha *= 0.18; c.fill(); c.globalAlpha /= 0.18;
        c.lineWidth = 8;
        c.beginPath(); c.arc(0, 0, R * 0.72, a, a + 1.7); c.stroke();
        c.beginPath(); c.arc(0, 0, R * 0.72, a + Math.PI, a + Math.PI + 1.7); c.stroke();
        c.beginPath(); c.arc(0, 0, R * 0.5, a + 1, a + 2.8); c.stroke();
        c.beginPath(); c.arc(0, 0, R * 0.5, a + 1 + Math.PI, a + 2.8 + Math.PI); c.stroke();
        c.beginPath(); c.arc(0, 0, R * 0.24, 0, Math.PI * 2); c.fill();
        c.fillStyle = "#000"; c.beginPath(); c.arc(0, 0, R * 0.06, 0, Math.PI * 2); c.fill();
        break;
      }
      case "dots": {
        for (let i = -1; i <= 1; i++) {
          const y = -Math.abs(Math.sin(this.t * 6 + i * 0.9)) * 36 + 10;
          c.beginPath(); c.arc(i * 50, y, 15, 0, Math.PI * 2); c.fill();
        }
        break;
      }
      case "ring": {
        c.lineWidth = 18;
        const a = this.t * 7;
        c.beginPath(); c.arc(0, 0, w / 2 - 14, a, a + 4.2); c.stroke();
        break;
      }
    }
    c.restore();
  }

  private drawBridge() {
    const c = this.c;
    const L = this.eyeBox(1), R = this.eyeBox(-1);
    c.strokeStyle = this.rgba(1); c.lineWidth = 14;
    c.beginPath();
    c.moveTo(L.cx - L.w / 2 - 30, L.cy - L.h * 0.28); c.lineTo(R.cx + R.w / 2 + 30, R.cy - R.h * 0.28);
    c.stroke();
  }

  private drawMouth() {
    const vis = this.P.mouth.x;
    if (vis < 0.03) return;
    const c = this.c;
    c.save();
    c.globalAlpha *= clamp(vis, 0, 1);
    const open = Math.max(0, this.P.open.x) * 70;
    const mw = this.P.mw.x;
    const sm = this.P.smile.x;
    const y0 = 610 + this.P.y.x * 0.3 + this.ly.x * 20;
    const cx = 400 + this.lx.x * 30;
    const yc = y0 - sm * 28;
    const yt = y0 + sm * 26;
    c.strokeStyle = this.rgba(1); c.fillStyle = this.rgba(1); c.lineWidth = 16;
    c.beginPath();
    c.moveTo(cx - mw, yc);
    c.quadraticCurveTo(cx, 2 * yt - yc, cx + mw, yc);
    if (open > 6) {
      const yb = yt + open;
      c.quadraticCurveTo(cx + mw * 0.7, 2 * yb - yc + open * 0.3, cx, yb + open * 0.1);
      c.quadraticCurveTo(cx - mw * 0.7, 2 * yb - yc + open * 0.3, cx - mw, yc);
      c.closePath();
      c.fill();
      if (this.P.tongue.x > 0.1) {
        c.fillStyle = "rgba(255,110,160,0.95)";
        c.beginPath(); c.ellipse(cx, yt + open * 0.78, mw * 0.4, open * 0.38, 0, 0, Math.PI * 2); c.fill();
      } else if (open > 24) {
        c.fillStyle = "rgba(0,20,30,0.55)";
        c.beginPath(); c.ellipse(cx, yt + open * 0.65, mw * 0.5, open * 0.3, 0, 0, Math.PI * 2); c.fill();
      }
    } else c.stroke();
    c.restore();
  }

  private drawBlush() {
    const b = this.P.blush.x;
    if (b < 0.03) return;
    const c = this.c;
    c.save();
    c.strokeStyle = `rgba(255,120,180,${b})`; c.lineWidth = 9;
    for (const s of [1, -1] as const) {
      const e = this.eyeBox(s);
      for (let i = 0; i < 3; i++) {
        const x = e.cx + (i - 1) * 24, y = e.cy + e.h / 2 + 34;
        c.beginPath(); c.moveTo(x - 6, y + 12); c.lineTo(x + 8, y - 10); c.stroke();
      }
    }
    c.restore();
  }

  private drawParticles() {
    const c = this.c;
    for (const p of this.parts) {
      const k = p.life / p.max;
      const a = k < 0.12 ? k / 0.12 : 1 - Math.pow((k - 0.12) / 0.88, 2);
      c.save();
      c.globalAlpha = clamp(a, 0, 1) * clamp(this.P.bright.x + 0.2, 0, 1);
      c.translate(p.x, p.y);
      c.rotate(p.rot);
      const s = p.size;
      c.fillStyle = p.hue !== undefined ? `hsl(${p.hue},95%,62%)` : this.rgba(1);
      c.strokeStyle = c.fillStyle;
      switch (p.type) {
        case "heart": {
          const r = 16 * s;
          if (p.hue === undefined) c.fillStyle = "rgb(255,110,175)";
          c.beginPath(); c.moveTo(0, r * 0.9);
          c.bezierCurveTo(-r * 1.35, r * 0.1, -r * 0.95, -r * 0.95, 0, -r * 0.38);
          c.bezierCurveTo(r * 0.95, -r * 0.95, r * 1.35, r * 0.1, 0, r * 0.9); c.fill();
          break;
        }
        case "note": case "zzz": case "bang": case "question": {
          c.font = `800 ${(p.type === "zzz" ? 44 : p.type === "note" ? 56 : 90) * s}px Orbitron, ui-sans-serif, system-ui, sans-serif`;
          c.textAlign = "center"; c.textBaseline = "middle";
          c.fillText(p.text || "", 0, 0);
          break;
        }
        case "tear": case "sweat": case "drop": {
          const r = (p.type === "tear" ? 13 : 10) * s;
          c.fillStyle = p.type === "tear" ? "rgb(120,210,255)" : "rgb(170,235,255)";
          c.beginPath(); c.moveTo(0, -r * 2.2); c.quadraticCurveTo(r * 1.3, -r * 0.2, 0, r); c.quadraticCurveTo(-r * 1.3, -r * 0.2, 0, -r * 2.2); c.fill();
          break;
        }
        case "spark": {
          const R = 20 * s * (0.6 + 0.4 * Math.sin(p.life * 12));
          c.beginPath();
          for (let i = 0; i < 4; i++) {
            const ang = (i * Math.PI) / 2;
            c.lineTo(Math.cos(ang) * R, Math.sin(ang) * R);
            c.lineTo(Math.cos(ang + Math.PI / 4) * R * 0.22, Math.sin(ang + Math.PI / 4) * R * 0.22);
          }
          c.closePath(); c.fill();
          break;
        }
        case "anger": {
          c.strokeStyle = "rgb(255,70,50)"; c.lineWidth = 9 * s;
          for (let i = 0; i < 4; i++) {
            c.save(); c.rotate((i * Math.PI) / 2);
            c.beginPath(); c.arc(22 * s, 22 * s, 18 * s, Math.PI, Math.PI * 1.5); c.stroke(); c.restore();
          }
          break;
        }
        case "confetti": c.fillRect(-6 * s, -3 * s, 12 * s, 6 * s); break;
        case "dot": c.beginPath(); c.arc(0, 0, 5 * s, 0, Math.PI * 2); c.fill(); break;
      }
      c.restore();
    }
  }

  private drawBullet() {
    const c = this.c, b = this.bullet;
    const slow = this.fx.timeScale < 0.6;
    c.save();
    c.translate(b.x, b.y);
    const grad = c.createLinearGradient(-320, 0, 0, 0);
    grad.addColorStop(0, "rgba(255,230,160,0)"); grad.addColorStop(1, "rgba(255,230,160,0.9)");
    c.fillStyle = grad;
    c.beginPath(); c.moveTo(-320, 0); c.lineTo(-10, -9); c.lineTo(-10, 9); c.closePath(); c.fill();
    c.fillStyle = "rgb(255,220,140)";
    c.beginPath(); c.roundRect(-40, -13, 62, 26, 12); c.fill();
    c.fillStyle = "rgb(255,255,255)";
    c.beginPath(); c.roundRect(-34, -8, 40, 7, 4); c.fill();
    if (slow) {
      c.strokeStyle = "rgba(255,230,160,0.45)"; c.lineWidth = 5;
      for (let i = 1; i <= 3; i++) { c.beginPath(); c.arc(30, 0, i * 38 + (this.t * 90) % 38, -0.9, 0.9); c.stroke(); }
    }
    c.restore();
  }

  private drawHand(x: number, y: number, mirror: number, spread: number, wob: number) {
    const c = this.c;
    c.save();
    c.translate(x, y);
    c.rotate(wob + mirror * 0.08);
    c.scale(mirror, 1);
    c.lineWidth = 11;
    c.strokeStyle = this.rgba(1);
    c.fillStyle = "rgba(0,0,0,0.9)";
    // forearm
    c.beginPath(); c.roundRect(-26, 40, 52, 520, 22); c.fill(); c.stroke();
    // palm
    c.beginPath(); c.roundRect(-52, -36, 104, 96, 30); c.fill(); c.stroke();
    // fingers
    const fl = [62, 82, 86, 70];
    for (let i = 0; i < 4; i++) {
      const ang = (-0.34 + i * 0.226) * spread;
      c.save();
      c.translate(-34 + i * 23, -30);
      c.rotate(ang);
      c.beginPath(); c.roundRect(-10, -fl[i], 20, fl[i] + 10, 10); c.fill(); c.stroke();
      c.restore();
    }
    // thumb
    c.save(); c.translate(48, 10); c.rotate(0.9 + 0.3 * spread);
    c.beginPath(); c.roundRect(-10, -56, 20, 66, 10); c.fill(); c.stroke(); c.restore();
    // electronic details
    c.lineWidth = 5;
    c.beginPath(); c.arc(0, 14, 13, 0, Math.PI * 2); c.stroke();
    c.beginPath(); c.moveTo(-30, 14); c.lineTo(-18, 14); c.moveTo(18, 14); c.lineTo(30, 14); c.stroke();
    c.restore();
  }

  private drawHands(a: number) {
    const c = this.c;
    const e = a;
    const y = 1000 - 480 * clamp(e, 0, 1.05);
    const wob = Math.sin(this.t * 38) * 0.04 * clamp(e, 0, 1);
    c.save();
    c.globalAlpha = clamp(e * 2, 0, 1);
    const sp = 0.8 + Math.sin(this.t * 30) * 0.08;
    this.drawHand(98, y, 1, sp, wob);
    this.drawHand(702, y, -1, sp, -wob);
    c.restore();
  }

  private drawDisplay() {
    const c = this.c, d = this.disp;
    const data = d.data || {};
    c.fillStyle = this.rgba(1); c.strokeStyle = this.rgba(1);
    c.textAlign = "center"; c.textBaseline = "middle";
    const font = (s: number) => `800 ${s}px Orbitron, ui-monospace, Menlo, monospace`;
    switch (d.type) {
      case "clock": {
        const now = new Date();
        let hh = now.getHours() % 12; if (hh === 0) hh = 12;
        const mm = String(now.getMinutes()).padStart(2, "0");
        const colon = Math.floor(this.t * 1.6) % 2 === 0 ? ":" : " ";
        c.font = font(170);
        c.fillText(`${hh}${colon}${mm}`, 400, 380);
        c.font = font(34);
        c.globalAlpha *= 0.7;
        c.fillText(now.getHours() >= 12 ? "PM" : "AM", 400, 500);
        break;
      }
      case "timer": {
        const rem = Math.max(0, data.remaining ?? 0);
        const tot = Math.max(1, data.total ?? 1);
        c.lineWidth = 22;
        c.globalAlpha *= 0.25; c.beginPath(); c.arc(400, 390, 250, 0, Math.PI * 2); c.stroke(); c.globalAlpha /= 0.25;
        c.beginPath(); c.arc(400, 390, 250, -Math.PI / 2, -Math.PI / 2 + (rem / tot) * Math.PI * 2); c.stroke();
        const m = Math.floor(rem / 60), s = Math.floor(rem % 60);
        c.font = font(m >= 10 ? 120 : 140);
        c.fillText(`${m}:${String(s).padStart(2, "0")}`, 400, 390);
        break;
      }
      case "weather": {
        const k = data.kind || "sun";
        c.lineWidth = 16;
        const cx = 400, cy = 310;
        if (k === "sun") {
          c.beginPath(); c.arc(cx, cy, 78, 0, Math.PI * 2); c.fill();
          for (let i = 0; i < 8; i++) {
            const a = (i / 8) * Math.PI * 2 + this.t * 0.6;
            c.beginPath(); c.moveTo(cx + Math.cos(a) * 112, cy + Math.sin(a) * 112); c.lineTo(cx + Math.cos(a) * 150, cy + Math.sin(a) * 150); c.stroke();
          }
        } else {
          const cloud = (x: number, y: number, s: number) => {
            c.beginPath();
            c.arc(x - 55 * s, y + 10 * s, 45 * s, 0, Math.PI * 2);
            c.arc(x, y - 25 * s, 62 * s, 0, Math.PI * 2);
            c.arc(x + 60 * s, y + 10 * s, 48 * s, 0, Math.PI * 2);
            c.rect(x - 55 * s, y + 10 * s, 115 * s, 45 * s);
            c.fill();
          };
          cloud(cx, cy, 1.15);
          if (k === "rain" || k === "storm") {
            for (let i = 0; i < 4; i++) {
              const o = (this.t * 220 + i * 40) % 120;
              c.beginPath(); c.moveTo(cx - 90 + i * 60 - o * 0.2, cy + 80 + o); c.lineTo(cx - 100 + i * 60 - o * 0.2, cy + 105 + o); c.stroke();
            }
          }
          if (k === "snow") {
            for (let i = 0; i < 4; i++) {
              const o = (this.t * 70 + i * 30) % 120;
              c.beginPath(); c.arc(cx - 90 + i * 60 + Math.sin(this.t * 3 + i) * 10, cy + 85 + o, 9, 0, Math.PI * 2); c.fill();
            }
          }
        }
        c.font = font(96);
        c.fillText(data.temp != null ? `${data.temp}°` : "--", 400, 600);
        break;
      }
      case "dice": {
        const v = data.value || 1;
        const s = 330;
        c.lineWidth = 18;
        c.save(); c.translate(400, 390); c.rotate(data.rot || 0);
        c.beginPath(); c.roundRect(-s / 2, -s / 2, s, s, 60); c.stroke();
        const pos: Record<number, [number, number][]> = {
          1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]],
          5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]],
        };
        for (const [px, py] of pos[v]) { c.beginPath(); c.arc(px * 92, py * 92, 27, 0, Math.PI * 2); c.fill(); }
        c.restore();
        break;
      }
      case "coin": {
        const sx = Math.abs(Math.cos(data.angle || 0));
        c.save(); c.translate(400, 390); c.scale(Math.max(0.05, sx), 1);
        c.lineWidth = 20; c.beginPath(); c.arc(0, 0, 170, 0, Math.PI * 2); c.stroke();
        c.font = font(190); c.fillText(data.face === "T" ? "T" : "H", 0, 6);
        c.restore();
        break;
      }
    }
  }
}
