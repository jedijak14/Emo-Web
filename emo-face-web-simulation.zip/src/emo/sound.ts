// EMO-ese: tiny synthesized chirps (no speech), a built-in dance beat, and songs EMO can sing.
let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let muted = false;
let beatTimer: number | null = null;

export function initAudio() {
  if (!ctx) {
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.55;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") ctx.resume();
}

export function setMuted(m: boolean) {
  muted = m;
  if (master) master.gain.value = m ? 0 : 0.55;
}
export function isMuted() {
  return muted;
}

function tone(freq: number, t0: number, dur: number, type: OscillatorType = "sine", vol = 0.18, slideTo?: number) {
  if (!ctx || !master) return;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t0 + dur);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g);
  g.connect(master);
  o.start(t0);
  o.stop(t0 + dur + 0.05);
}

type Pat = { notes: [number, number, number?][]; type?: OscillatorType; vol?: number; gap?: number };
const PATTERNS: Record<string, Pat> = {
  happy: { notes: [[600, 0.08, 900], [800, 0.08, 1200], [1000, 0.14, 1500]], type: "triangle" },
  hello: { notes: [[500, 0.07, 700], [700, 0.07, 1000], [900, 0.07, 1300], [1200, 0.14, 1600]], type: "triangle" },
  sad: { notes: [[520, 0.22, 380], [400, 0.35, 220]], type: "sine" },
  cry: { notes: [[500, 0.2, 350], [480, 0.2, 330], [460, 0.2, 300], [420, 0.4, 200]], type: "sine" },
  angry: { notes: [[170, 0.16, 110], [150, 0.22, 90]], type: "sawtooth", vol: 0.1 },
  surprised: { notes: [[500, 0.06, 1500], [1500, 0.12, 1600]], type: "square", vol: 0.08 },
  scared: { notes: Array.from({ length: 8 }, (_, i) => [900 + (i % 2) * 150, 0.05, 1000] as [number, number, number]), type: "triangle", gap: 0.02 },
  love: { notes: [[700, 0.12, 900], [900, 0.12, 700], [1100, 0.2, 1400]], type: "sine" },
  sleepy: { notes: [[320, 0.5, 200]], type: "sine", vol: 0.1 },
  yawn: { notes: [[420, 0.6, 180]], type: "triangle", vol: 0.1 },
  curious: { notes: [[500, 0.1, 700], [700, 0.14, 520], [620, 0.14, 950]], type: "triangle" },
  laugh: { notes: Array.from({ length: 6 }, (_, i) => [760 + i * 40, 0.06, 980 + i * 40] as [number, number, number]), type: "triangle", gap: 0.05 },
  dizzy: { notes: [[400, 0.15, 700], [700, 0.15, 400], [400, 0.15, 700], [700, 0.2, 300]], type: "sine" },
  kiss: { notes: [[1200, 0.07, 1900], [1500, 0.05, 900]], type: "sine" },
  poke: { notes: [[900, 0.05, 1300], [1100, 0.05, 700]], type: "square", vol: 0.07 },
  wink: { notes: [[700, 0.06, 1100], [1300, 0.08, 1700]], type: "triangle" },
  proud: { notes: [[523, 0.1], [659, 0.1], [784, 0.2]], type: "triangle" },
  phew: { notes: [[600, 0.4, 250]], type: "sine", vol: 0.1 },
  glitch: { notes: [[220, 0.03], [1800, 0.03], [90, 0.05], [2400, 0.03]], type: "square", vol: 0.05, gap: 0.01 },
  sneeze: { notes: [[400, 0.08, 800], [1200, 0.2, 100]], type: "sawtooth", vol: 0.07 },
  pet: { notes: [[600, 0.15, 750], [650, 0.18, 800]], type: "sine", vol: 0.12 },
  whoosh: { notes: [[200, 0.5, 2200]], type: "sawtooth", vol: 0.04 },
  bang: { notes: [[900, 0.04, 80]], type: "square", vol: 0.12 },
  ding: { notes: [[1318, 0.3], [1760, 0.5]], type: "sine" },
};

export function chirp(name: string) {
  if (!ctx || muted) return;
  const p = PATTERNS[name];
  if (!p) return;
  let t = ctx.currentTime + 0.02;
  for (const [f, d, s] of p.notes) {
    tone(f, t, d, p.type || "sine", p.vol ?? 0.16, s);
    t += d + (p.gap ?? 0.03);
  }
}

export function alarm(seconds = 6) {
  if (!ctx || muted) return;
  let t = ctx.currentTime + 0.05;
  for (let i = 0; i < seconds * 3; i++) {
    tone(1320, t, 0.08, "square", 0.08);
    tone(1320, t + 0.13, 0.08, "square", 0.08);
    t += 0.33;
  }
}

function noise(t0: number, dur: number, vol: number, hp = 6000) {
  if (!ctx || !master) return;
  const len = Math.floor(ctx.sampleRate * dur);
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const s = ctx.createBufferSource();
  s.buffer = buf;
  const f = ctx.createBiquadFilter();
  f.type = "highpass";
  f.frequency.value = hp;
  const g = ctx.createGain();
  g.gain.value = vol;
  s.connect(f);
  f.connect(g);
  g.connect(master);
  s.start(t0);
}

function kick(t0: number) {
  tone(150, t0, 0.18, "sine", 0.5, 40);
}

// EMO's own built-in dance track (used for "Emo, dance for me")
export function startBeat(bpm = 122) {
  stopBeat();
  if (!ctx) return;
  const step = 60 / bpm / 4;
  let next = ctx.currentTime + 0.1;
  let n = 0;
  const bass = [0, 0, 7, 0, 5, 5, 3, 7];
  const lead = [0, 3, 7, 12, 10, 7, 3, 7];
  beatTimer = window.setInterval(() => {
    if (!ctx) return;
    while (next < ctx.currentTime + 0.15) {
      const s = n % 16;
      if (!muted) {
        if (s % 4 === 0) kick(next);
        if (s === 4 || s === 12) noise(next, 0.14, 0.25, 1800);
        if (s % 2 === 0) noise(next, 0.04, 0.12);
        if (s % 2 === 0) tone(55 * Math.pow(2, bass[(s / 2) % 8] / 12), next, step * 1.8, "sawtooth", 0.1);
        if (s % 2 === 1 || s % 4 === 2) tone(440 * Math.pow(2, lead[(n >> 1) % 8] / 12), next, step * 0.9, "square", 0.035);
      }
      next += step;
      n++;
    }
  }, 25);
}

export function stopBeat() {
  if (beatTimer) clearInterval(beatTimer);
  beatTimer = null;
}

// Songs EMO can sing (tiny synth melodies)
export const HAPPY_BIRTHDAY: [number, number][] = [
  [67, 0.75], [67, 0.25], [69, 1], [67, 1], [72, 1], [71, 2],
  [67, 0.75], [67, 0.25], [69, 1], [67, 1], [74, 1], [72, 2],
  [67, 0.75], [67, 0.25], [79, 1], [76, 1], [72, 1], [71, 1], [69, 1],
  [77, 0.75], [77, 0.25], [76, 1], [72, 1], [74, 1], [72, 2],
];

export function playMelody(notes: [number, number][], bpm = 120) {
  if (!ctx || muted) return 0;
  const beat = 60 / bpm;
  let t = ctx.currentTime + 0.05;
  for (const [m, b] of notes) {
    const f = 440 * Math.pow(2, (m - 69) / 12);
    tone(f, t, b * beat * 0.9, "triangle", 0.2);
    tone(f * 2, t, b * beat * 0.9, "sine", 0.05);
    t += b * beat;
  }
  return t - ctx.currentTime;
}
