// Music: search (iTunes catalogue / YouTube Data API) + playback through the YouTube IFrame Player API.
// If a full YouTube video can't be resolved, EMO falls back to the 30-second catalogue preview.
export interface Track {
  id: string;
  title: string;
  artist: string;
  art: string;
  previewUrl?: string;
  videoId?: string;
}

export type PlayStatus = "idle" | "loading" | "playing" | "paused";
export interface PlayerState { status: PlayStatus; track?: Track; full: boolean; }

function withTimeout(url: string, ms = 6000, init?: RequestInit): Promise<Response> {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  return fetch(url, { ...init, signal: ctl.signal }).finally(() => clearTimeout(t));
}

export async function searchTracks(q: string, apiKey?: string): Promise<Track[]> {
  const clean = q.replace(/\s+by\s+/i, " ").replace(/[^\p{L}\p{N}\s'&.-]/gu, " ").trim();
  if (apiKey) {
    try {
      const r = await withTimeout(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoCategoryId=10&maxResults=8&q=${encodeURIComponent(clean)}&key=${apiKey}`,
      );
      const j = await r.json();
      if (j.items?.length) {
        return j.items.map((it: any) => ({
          id: it.id.videoId,
          videoId: it.id.videoId,
          title: decode(it.snippet.title),
          artist: decode(it.snippet.channelTitle).replace(/ - Topic$/, ""),
          art: it.snippet.thumbnails?.medium?.url || `https://i.ytimg.com/vi/${it.id.videoId}/mqdefault.jpg`,
        }));
      }
    } catch { /* fall through */ }
  }
  const r = await withTimeout(`https://itunes.apple.com/search?term=${encodeURIComponent(clean)}&media=music&entity=song&limit=10`, 8000);
  const j = await r.json();
  const seen = new Set<string>();
  const out: Track[] = [];
  for (const it of j.results || []) {
    const key = `${it.trackName}|${it.artistName}`.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({
      id: String(it.trackId),
      title: it.trackName,
      artist: it.artistName,
      art: (it.artworkUrl100 || "").replace("100x100", "300x300"),
      previewUrl: it.previewUrl,
    });
    if (out.length >= 6) break;
  }
  return out;
}

function decode(s: string) {
  const t = document.createElement("textarea");
  t.innerHTML = s;
  return t.value;
}

const PROXIES = [
  (u: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
  (u: string) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
  (u: string) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(u)}`,
];
const PIPED = ["https://pipedapi.kavin.rocks", "https://api.piped.private.coffee", "https://pipedapi.adminforge.de"];

// Find YouTube video ids for a song (best-first)
export async function resolveVideoIds(t: Track, apiKey?: string): Promise<string[]> {
  if (t.videoId) return [t.videoId];
  const q = `${t.artist} ${t.title} official audio`;
  const jobs: Promise<string[]>[] = [];
  if (apiKey) {
    jobs.push(
      withTimeout(`https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&maxResults=4&q=${encodeURIComponent(q)}&key=${apiKey}`, 6000)
        .then((r) => r.json())
        .then((j) => { const ids = (j.items || []).map((i: any) => i.id.videoId); if (!ids.length) throw 0; return ids; }),
    );
  }
  const ytUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}&sp=EgIQAQ%253D%253D`;
  for (const p of PROXIES) {
    jobs.push(
      withTimeout(p(ytUrl), 7000)
        .then((r) => r.text())
        .then((html) => {
          const ids = [...html.matchAll(/"videoRenderer":\{"videoId":"([\w-]{11})"/g)].map((m) => m[1]);
          const uniq = [...new Set(ids)].slice(0, 4);
          if (!uniq.length) throw 0;
          return uniq;
        }),
    );
  }
  for (const base of PIPED) {
    jobs.push(
      withTimeout(`${base}/search?q=${encodeURIComponent(q)}&filter=music_songs`, 6000)
        .then((r) => r.json())
        .then((j) => {
          const ids = (j.items || []).map((i: any) => (i.url || "").split("v=")[1]).filter(Boolean).slice(0, 4);
          if (!ids.length) throw 0;
          return ids;
        }),
    );
  }
  try {
    return await anyOf(jobs);
  } catch {
    return [];
  }
}

function anyOf<T>(ps: Promise<T>[]): Promise<T> {
  return new Promise((resolve, reject) => {
    let n = ps.length;
    if (!n) reject(new Error("none"));
    for (const p of ps) p.then(resolve, () => { if (--n === 0) reject(new Error("all failed")); });
  });
}

let ytPromise: Promise<void> | null = null;
function loadYT(): Promise<void> {
  if (ytPromise) return ytPromise;
  ytPromise = new Promise((resolve, reject) => {
    const w = window as any;
    if (w.YT?.Player) return resolve();
    const prev = w.onYouTubeIframeAPIReady;
    w.onYouTubeIframeAPIReady = () => { prev?.(); resolve(); };
    const s = document.createElement("script");
    s.src = "https://www.youtube.com/iframe_api";
    s.onerror = () => { ytPromise = null; reject(new Error("yt blocked")); };
    document.head.appendChild(s);
    setTimeout(() => { if (!w.YT?.Player) { ytPromise = null; reject(new Error("yt timeout")); } }, 9000);
  });
  return ytPromise;
}

export class MusicPlayer {
  state: PlayerState = { status: "idle", full: false };
  queue: Track[] = [];
  index = -1;
  apiKey = "";
  volume = 80;
  ducked = false;
  onChange?: (s: PlayerState) => void;
  onEnded?: () => void;
  private yt: any = null;
  private audio: HTMLAudioElement | null = null;
  private cands: string[] = [];
  private candIdx = 0;
  private token = 0;
  private poll: number | null = null;

  private set(s: Partial<PlayerState>) {
    this.state = { ...this.state, ...s };
    this.onChange?.(this.state);
  }

  async play(track: Track, queue?: Track[]) {
    const my = ++this.token;
    this.killMedia();
    if (queue) { this.queue = queue; }
    this.index = this.queue.findIndex((t) => t.id === track.id);
    this.set({ status: "loading", track, full: false });
    let ids = track.videoId ? [track.videoId] : [];
    if (!ids.length) ids = await resolveVideoIds(track, this.apiKey);
    if (my !== this.token) return;
    this.cands = ids;
    this.candIdx = 0;
    if (ids.length) {
      try {
        await this.playYT(ids[0], my);
        return;
      } catch { /* fall back */ }
    }
    if (my !== this.token) return;
    this.playPreview(track, my);
  }

  private handlers: { state: (s: number) => void; error: () => void } = { state: () => {}, error: () => {} };

  private async playYT(id: string, my: number) {
    await loadYT();
    if (my !== this.token) return;
    const w = window as any;
    this.handlers = {
      state: (s: number) => {
        if (my !== this.token) return;
        if (s === 1) this.set({ status: "playing", full: true });
        else if (s === 2) this.set({ status: "paused" });
        else if (s === 0) this.onEnded?.();
      },
      error: () => {
        if (my !== this.token) return;
        this.candIdx++;
        if (this.candIdx < this.cands.length) this.yt?.loadVideoById(this.cands[this.candIdx]);
        else if (this.state.track) this.playPreview(this.state.track, my);
      },
    };
    if (!this.yt) {
      const host = document.createElement("div");
      host.style.cssText = "position:fixed;left:-400px;bottom:0;width:200px;height:200px;opacity:0.01;pointer-events:none;overflow:hidden";
      const inner = document.createElement("div");
      inner.id = "emo-yt";
      host.appendChild(inner);
      document.body.appendChild(host);
      await new Promise<void>((resolve) => {
        this.yt = new w.YT.Player("emo-yt", {
          width: 200, height: 200, videoId: id,
          playerVars: { autoplay: 1, controls: 0, playsinline: 1, rel: 0, origin: location.origin },
          events: {
            onReady: (e: any) => { e.target.setVolume(this.effVol()); e.target.playVideo(); resolve(); },
            onStateChange: (e: any) => this.handlers.state(e.data),
            onError: () => this.handlers.error(),
          },
        });
      });
    } else {
      this.yt.loadVideoById(id);
      this.yt.setVolume(this.effVol());
    }
  }

  private playPreview(track: Track, my: number) {
    if (!track.previewUrl) { this.set({ status: "idle", full: false }); return; }
    const a = new Audio(track.previewUrl);
    a.volume = this.effVol() / 100;
    this.audio = a;
    a.onplaying = () => { if (my === this.token) this.set({ status: "playing", full: false }); };
    a.onpause = () => { if (my === this.token && !a.ended) this.set({ status: "paused" }); };
    a.onended = () => { if (my === this.token) this.onEnded?.(); };
    a.onerror = () => { if (my === this.token) this.set({ status: "idle" }); };
    a.play().catch(() => this.set({ status: "paused" }));
  }

  private effVol() { return this.ducked ? Math.round(this.volume * 0.2) : this.volume; }
  private applyVol() {
    try { this.yt?.setVolume?.(this.effVol()); } catch { /* */ }
    if (this.audio) this.audio.volume = this.effVol() / 100;
  }
  setVolume(v: number) { this.volume = Math.max(0, Math.min(100, v)); this.applyVol(); }
  duck(on: boolean) { if (this.ducked !== on) { this.ducked = on; this.applyVol(); } }

  pause() {
    if (this.audio) this.audio.pause();
    else try { this.yt?.pauseVideo?.(); } catch { /* */ }
    if (this.state.status === "playing") this.set({ status: "paused" });
  }
  resume() {
    if (this.audio) this.audio.play().catch(() => {});
    else try { this.yt?.playVideo?.(); } catch { /* */ }
  }
  private killMedia() {
    if (this.audio) { this.audio.pause(); this.audio.src = ""; this.audio = null; }
    try { this.yt?.stopVideo?.(); } catch { /* */ }
    if (this.poll) clearInterval(this.poll);
  }
  stop() {
    this.token++;
    this.killMedia();
    this.set({ status: "idle", track: undefined, full: false });
  }
  next() { if (this.queue.length) { this.play(this.queue[(this.index + 1) % this.queue.length]); } }
  prev() { if (this.queue.length) { this.play(this.queue[(this.index - 1 + this.queue.length) % this.queue.length]); } }
}
