import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { EmoHead } from "./components/EmoHead";
import { EmoEngine } from "./emo/engine";
import { Brain } from "./emo/brain";
import { MusicPlayer, searchTracks, type PlayerState, type Track } from "./emo/music";
import { MicMeter, SpeechListener } from "./emo/voice";
import { Vision, EMPTY_FACE } from "./emo/vision";
import { hasWake, parse, type Cmd } from "./emo/commands";
import { MENU } from "./emo/expressions";
import * as snd from "./emo/sound";

type Panel = "none" | "music" | "expr" | "help" | "settings";

const HELP: { title: string; items: string[] }[] = [
  { title: "Wake him up", items: ["“Emo” — he perks up (and wakes from sleep)", "Pat his head: tap = poke, hold = pet, drag = pick him up"] },
  { title: "Fun", items: ["“Emo, hands up!” — terrified electronic hands", "“Emo, dodge the bullet” / “Emo, bang!”", "“Emo, dance for me” / “Emo, music” — his own beat", "“Emo, it's my birthday” — he sings", "“Emo, play dead” · “scare” · “tell a joke” · “I love you”"] },
  { title: "Music (YouTube)", items: ["“Emo, play Blinding Lights by The Weeknd” → results appear", "Then say “number two” / “the first one”, or tap a card", "“stop” · “pause” · “resume” · “next” · “louder” · “quieter”"] },
  { title: "Helper", items: ["“What time is it?” · “What's the weather?”", "“Set a 2 minute timer” · “How much time is left?”", "“Roll a dice” · “Flip a coin”", "“Remember me” — teach him your face (up to 10 people)"] },
  { title: "Moods", items: ["happy · sad · angry · cry · shy · wink · kiss · cool · silly · sneeze · dizzy · yawn · go to sleep · wake up · glitch…"] },
  { title: "Camera", items: ["He follows your face, greets you, mirrors your smile, surprise, tongue, wink & head tilt, plays peek‑a‑boo and notices strangers."] },
];

function fmt(n: number) { const m = Math.floor(n / 60), s = Math.floor(n % 60); return `${m}:${String(s).padStart(2, "0")}`; }

export default function App() {
  const [started, setStarted] = useState(false);
  const [wantMic, setWantMic] = useState(true);
  const [wantCam, setWantCam] = useState(true);
  const [micOn, setMicOn] = useState(false);
  const [listening, setListening] = useState(false);
  const [camOn, setCamOn] = useState(false);
  const [visionMode, setVisionMode] = useState("off");
  const [showCam, setShowCam] = useState(true);
  const [panel, setPanel] = useState<Panel>("none");
  const [uiVisible, setUiVisible] = useState(true);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Track[]>([]);
  const [searching, setSearching] = useState(false);
  const [ps, setPs] = useState<PlayerState>({ status: "idle", full: false });
  const [apiKey, setApiKey] = useState(() => localStorage.getItem("emo.ytkey") || "");
  const [muted, setMuted] = useState(false);
  const [vol, setVol] = useState(80);
  const [timerInfo, setTimerInfo] = useState<{ remaining: number; total: number } | null>(null);
  const [toast, setToast] = useState("");
  const [box, setBox] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [known, setKnown] = useState(0);
  const [djOn, setDjOn] = useState(false);

  const engineRef = useRef<EmoEngine | null>(null);
  const brainRef = useRef<Brain | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const resultsRef = useRef<Track[]>([]);
  const panelRef = useRef<Panel>("none");
  const apiRef = useRef(apiKey);
  const awakeUntil = useRef(0);
  const duckT = useRef<any>(null);
  const prevStatus = useRef("idle");
  const boxT = useRef(0);

  const music = useMemo(() => new MusicPlayer(), []);
  const vision = useMemo(() => new Vision(), []);
  const mic = useMemo(() => new MicMeter(), []);
  const speech = useMemo(() => new SpeechListener(), []);

  resultsRef.current = results;
  panelRef.current = panel;
  apiRef.current = apiKey;

  const say = useCallback((t: string) => { setToast(t); setTimeout(() => setToast((c) => (c === t ? "" : c)), 4200); }, []);

  /* ---------- camera / mic ---------- */
  const enableCam = useCallback(async () => {
    if (!videoRef.current) return false;
    setVisionMode("loading");
    const ok = await vision.start(videoRef.current);
    if (!ok) { setVisionMode("off"); say("Camera permission was blocked."); return false; }
    setCamOn(true);
    setKnown(vision.remembered);
    return true;
  }, [vision, say]);

  const disableCam = useCallback(() => {
    vision.stop();
    setCamOn(false);
    setVisionMode("off");
    setBox(null);
    brainRef.current?.onVision(EMPTY_FACE);
  }, [vision]);

  const enableMic = useCallback(async () => {
    const ok = await mic.start();
    if (!ok) { say("Microphone permission was blocked."); return false; }
    setMicOn(true);
    if (speech.supported) speech.start();
    else say("Voice commands need Chrome, Edge or Safari. You can type commands instead.");
    return true;
  }, [mic, speech, say]);

  const disableMic = useCallback(() => {
    speech.stop(); mic.stop(); setMicOn(false); setListening(false);
  }, [mic, speech]);

  /* ---------- music ---------- */
  const playTrack = useCallback((t: Track) => {
    const b = brainRef.current;
    music.play(t, resultsRef.current);
    if (b && !b.musicOn) b.act("searching");
  }, [music]);

  const doSearch = useCallback(async (q: string) => {
    setSearching(true);
    setPanel("music");
    try {
      const tracks = await searchTracks(q, apiRef.current);
      setResults(tracks);
      resultsRef.current = tracks;
      return tracks.length;
    } catch {
      setResults([]);
      say("Couldn't reach the music catalogue.");
      return 0;
    } finally { setSearching(false); }
  }, [say]);

  /* ---------- engine ready ---------- */
  const onEngine = useCallback((engine: EmoEngine) => {
    engineRef.current = engine;
    const brain = new Brain(engine);
    brainRef.current = brain;
    brain.sleeping = true;
    engine.setExpr("sleep");
    engine.look(0, 0.3);
    brain.onTimerChange = setTimerInfo;
    brain.hooks = {
      search: doSearch,
      stopMusic: () => music.stop(),
      pauseMusic: () => music.pause(),
      resumeMusic: () => music.resume(),
      nextTrack: () => music.next(),
      prevTrack: () => music.prev(),
      volume: (d) => { const v = Math.max(0, Math.min(100, music.volume + d * 20)); music.setVolume(v); setVol(v); },
      pick: (n) => { const t = resultsRef.current[n - 1]; if (t) playTrack(t); },
      camera: (on) => { if (on) enableCam(); else disableCam(); },
      remember: async () => {
        if (!vision.stream) { const ok = await enableCam(); if (!ok) return false; await new Promise((r) => setTimeout(r, 2500)); }
        const ok = await vision.enroll();
        setKnown(vision.remembered);
        return ok;
      },
      forget: () => { vision.forget(); setKnown(0); },
    };
    brain.start();
    // audio feeds the DJ
    mic.onLevel = (energy, onset) => {
      if (brain.djSrc === "yt") { engine.dj.energy = energy; if (onset) engine.djOnset(); }
      else engine.dj.energy = 0.45;
    };
    vision.onFace = (f) => { brain.knownCount = vision.remembered; brain.onVision(f); };
    vision.onBox = (b) => {
      const n = performance.now();
      if (n - boxT.current > 100) { boxT.current = n; setBox(b); }
    };
    const t = setInterval(() => { setVisionMode(vision.mode); setDjOn(brain.musicOn); }, 500);
    (engine as any).__cleanup = () => clearInterval(t);
  }, [doSearch, music, playTrack, enableCam, disableCam, vision, mic]);

  useEffect(() => {
    music.onChange = (s) => {
      setPs(s);
      const b = brainRef.current;
      const prev = prevStatus.current;
      prevStatus.current = s.status;
      if (!b) return;
      if (s.status === "playing") b.startDj("yt", 118);
      else if ((s.status === "paused" || s.status === "idle") && b.musicOn && b.djSrc === "yt") b.stopDj();
      if (prev === "loading" && s.status === "idle" && !b.musicOn) b.act("notfound");
    };
    music.onEnded = () => music.next();
    speech.onState = (l, err) => { setListening(l); if (err === "denied") { setMicOn(false); say("Speech recognition was blocked."); } };
    speech.onInterim = (t) => {
      if (!hasWake(t)) return;
      brainRef.current?.perk();
      if (music.state.status === "playing") {
        music.duck(true);
        clearTimeout(duckT.current);
        duckT.current = setTimeout(() => music.duck(false), 6000);
      }
    };
    speech.onFinal = (t) => {
      const b = brainRef.current;
      if (!b) return;
      const now = Date.now();
      const { woke, cmd } = parse(t, {
        requireWake: now > awakeUntil.current,
        hasResults: resultsRef.current.length > 0 && panelRef.current === "music",
      });
      if (woke) b.perk();
      if (cmd) {
        awakeUntil.current = 0;
        b.exec(cmd);
        clearTimeout(duckT.current);
        duckT.current = setTimeout(() => music.duck(false), 2200);
      } else if (woke) awakeUntil.current = now + 7000;
    };
    return () => { music.stop(); };
  }, [music, speech, say]);

  useEffect(() => { music.apiKey = apiKey; localStorage.setItem("emo.ytkey", apiKey); }, [apiKey, music]);
  useEffect(() => { snd.setMuted(muted); }, [muted]);

  // auto hide UI
  useEffect(() => {
    let t: any;
    const show = () => { setUiVisible(true); clearTimeout(t); t = setTimeout(() => setUiVisible(false), 5000); };
    show();
    window.addEventListener("pointermove", show);
    window.addEventListener("pointerdown", show);
    window.addEventListener("keydown", show);
    return () => { window.removeEventListener("pointermove", show); window.removeEventListener("pointerdown", show); window.removeEventListener("keydown", show); clearTimeout(t); };
  }, []);

  // shake detection (phones)
  useEffect(() => {
    let last = 0;
    const h = (e: DeviceMotionEvent) => {
      const a = e.accelerationIncludingGravity;
      if (!a) return;
      const m = Math.hypot(a.x || 0, a.y || 0, a.z || 0);
      const n = Date.now();
      if (m > 28 && n - last > 3500) { last = n; brainRef.current?.touch("shake"); }
    };
    window.addEventListener("devicemotion", h);
    return () => window.removeEventListener("devicemotion", h);
  }, []);

  /* ---------- start ---------- */
  const wake = async () => {
    snd.initAudio();
    setStarted(true);
    brainRef.current?.act("wake");
    if (wantMic) await enableMic();
    if (wantCam) await enableCam();
  };

  const submit = (text: string) => {
    const b = brainRef.current;
    const q = text.trim();
    if (!b || !q) return;
    snd.initAudio();
    const { cmd } = parse(q, { requireWake: false, hasResults: resultsRef.current.length > 0 });
    if (cmd && cmd.t !== "unknown") b.exec(cmd);
    else b.exec({ t: "play", q: q.replace(/^(emo[, ]*)/i, "") } as Cmd);
  };

  const exec = (c: Cmd) => { snd.initAudio(); brainRef.current?.exec(c); };
  const toggle = (p: Panel) => setPanel((cur) => (cur === p ? "none" : p));
  const fullscreen = () => { if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen?.(); };

  const playing = ps.status === "playing" || ps.status === "paused" || ps.status === "loading";
  const dockShown = uiVisible || panel !== "none" || !started;

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#05060a] text-cyan-50">
      <EmoHead onEngine={onEngine} onTouch={(k) => { snd.initAudio(); brainRef.current?.touch(k); }} lifted={panel === "music" || panel === "expr"} />

      {/* camera feed (kept in DOM for the vision loop) */}
      <div className={`absolute right-3 top-14 z-30 w-44 overflow-hidden rounded-2xl glass transition-all duration-300 ${camOn && showCam ? "opacity-100" : "pointer-events-none opacity-0"}`} style={{ height: camOn && showCam ? "auto" : 0 }}>
        <div className="relative aspect-[4/3] bg-black">
          <video ref={videoRef} className="h-full w-full -scale-x-100 object-cover" muted playsInline />
          {box && (
            <div className="absolute rounded-md border-2 border-cyan-300 shadow-[0_0_12px_rgba(62,244,255,.9)] transition-all duration-100" style={{ left: `${box.x * 100}%`, top: `${box.y * 100}%`, width: `${box.w * 100}%`, height: `${box.h * 100}%` }} />
          )}
        </div>
        <div className="flex items-center justify-between gap-1 p-2 text-[10px] text-cyan-100/80">
          <span>{visionMode === "mediapipe" ? "Face tracking" : visionMode === "motion" ? "Motion tracking · loading face model…" : "…"}</span>
          <span>{known ? `${known} known` : ""}</span>
        </div>
        <div className="flex gap-1 px-2 pb-2">
          <button onClick={() => exec({ t: "remember" })} className="flex-1 rounded-lg bg-cyan-400/15 px-2 py-1 text-[11px] hover:bg-cyan-400/30">Remember me</button>
          <button onClick={() => exec({ t: "forget" })} className="rounded-lg bg-white/5 px-2 py-1 text-[11px] hover:bg-white/10">Forget</button>
        </div>
      </div>

      {/* status */}
      <div className={`absolute left-3 top-3 z-30 flex items-center gap-2 transition-opacity duration-500 ${started && !uiVisible ? "opacity-0" : "opacity-100"}`}>
        <span title="Microphone" className={`flex h-7 items-center gap-1.5 rounded-full px-2.5 text-[11px] glass ${micOn ? "text-cyan-200" : "text-white/40"}`}>
          <span className={`h-2 w-2 rounded-full ${micOn && listening ? "animate-pulse bg-cyan-300 shadow-[0_0_8px_#3ef4ff]" : micOn ? "bg-cyan-700" : "bg-white/20"}`} /> mic
        </span>
        <span title="Camera" className={`flex h-7 items-center gap-1.5 rounded-full px-2.5 text-[11px] glass ${camOn ? "text-cyan-200" : "text-white/40"}`}>
          <span className={`h-2 w-2 rounded-full ${camOn ? "bg-cyan-300 shadow-[0_0_8px_#3ef4ff]" : "bg-white/20"}`} /> cam
        </span>
        {timerInfo && (
          <button onClick={() => exec({ t: "timer-show" })} className="flex h-7 items-center gap-1 rounded-full px-2.5 text-[11px] text-cyan-200 glass">⏱ {fmt(timerInfo.remaining)}</button>
        )}
      </div>

      {/* now playing */}
      {playing && ps.track && (
        <div className="emo-fade-up absolute left-1/2 top-3 z-30 flex max-w-[92vw] -translate-x-1/2 items-center gap-3 rounded-2xl p-2 pr-3 glass">
          {ps.track.art && <img src={ps.track.art} alt="" className="h-10 w-10 rounded-lg object-cover" />}
          <div className="min-w-0 max-w-[40vw] sm:max-w-xs">
            <div className="truncate text-xs font-semibold">{ps.track.title}</div>
            <div className="truncate text-[11px] text-cyan-100/60">{ps.track.artist}{ps.status === "playing" && !ps.full ? " · 30s preview" : ps.status === "loading" ? " · loading…" : ""}</div>
          </div>
          <div className="flex items-center gap-1 text-sm">
            <button className="rounded-full px-2 py-1 hover:bg-white/10" onClick={() => music.prev()}>⏮</button>
            <button className="rounded-full px-2 py-1 hover:bg-white/10" onClick={() => (ps.status === "playing" ? music.pause() : music.resume())}>{ps.status === "playing" ? "⏸" : "▶"}</button>
            <button className="rounded-full px-2 py-1 hover:bg-white/10" onClick={() => music.next()}>⏭</button>
            <button className="rounded-full px-2 py-1 hover:bg-white/10" onClick={() => music.stop()}>✕</button>
          </div>
        </div>
      )}
      {!playing && djOn && (
        <div className="emo-fade-up absolute left-1/2 top-3 z-30 flex -translate-x-1/2 items-center gap-2 rounded-full px-3 py-1.5 text-xs glass">
          🎧 EMO's own beat
          <button className="rounded-full px-2 hover:bg-white/10" onClick={() => exec({ t: "stop" })}>✕</button>
        </div>
      )}

      {toast && <div className="emo-fade-up absolute left-1/2 top-16 z-40 -translate-x-1/2 rounded-xl px-4 py-2 text-xs glass">{toast}</div>}

      {/* panels */}
      {panel !== "none" && started && (
        <div className="emo-fade-up emo-scroll absolute inset-x-2 bottom-20 z-30 mx-auto max-h-[52vh] max-w-3xl overflow-y-auto rounded-3xl p-4 glass">
          {panel === "music" && (
            <div>
              <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); submit(query); setQuery(""); }}>
                <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Song by artist… or a command like “hands up”" className="min-w-0 flex-1 rounded-xl border border-cyan-300/20 bg-black/40 px-4 py-2.5 text-sm outline-none placeholder:text-cyan-100/30 focus:border-cyan-300/60" />
                <button className="rounded-xl bg-cyan-400/20 px-4 text-sm font-medium text-cyan-100 hover:bg-cyan-400/35">Ask EMO</button>
              </form>
              <div className="mt-2 flex flex-wrap gap-1.5 text-[11px] text-cyan-100/60">
                {["Blinding Lights by The Weeknd", "Dance Monkey by Tones and I", "Uptown Funk by Bruno Mars", "Take On Me by a-ha"].map((s) => (
                  <button key={s} onClick={() => submit("play " + s)} className="rounded-full border border-cyan-300/15 px-2.5 py-1 hover:bg-cyan-400/15">{s}</button>
                ))}
                <button onClick={() => exec({ t: "music-own" })} className="rounded-full border border-cyan-300/30 px-2.5 py-1 text-cyan-200 hover:bg-cyan-400/15">🎧 EMO's own beat</button>
              </div>
              {searching && <div className="mt-4 text-center text-xs text-cyan-100/50">searching…</div>}
              {results.length > 0 && !searching && (
                <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {results.map((t, i) => (
                    <button key={t.id} onClick={() => playTrack(t)} className={`group relative flex items-center gap-2 rounded-2xl border p-2 text-left transition hover:bg-cyan-400/10 ${ps.track?.id === t.id ? "border-cyan-300/70 bg-cyan-400/10" : "border-cyan-300/10 bg-black/20"}`}>
                      <span className="absolute -left-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-cyan-300 text-[10px] font-bold text-black">{i + 1}</span>
                      <img src={t.art} alt="" className="h-12 w-12 shrink-0 rounded-lg object-cover" />
                      <span className="min-w-0">
                        <span className="block truncate text-xs font-semibold">{t.title}</span>
                        <span className="block truncate text-[11px] text-cyan-100/55">{t.artist}</span>
                      </span>
                    </button>
                  ))}
                </div>
              )}
              {results.length > 0 && <p className="mt-2 text-center text-[11px] text-cyan-100/40">Tap a card, or say “Emo, number two”.</p>}
            </div>
          )}

          {panel === "expr" && (
            <div>
              <div className="grid grid-cols-5 gap-1.5 sm:grid-cols-6 md:grid-cols-8">
                {MENU.map((m) => (
                  <button key={m.id} onClick={() => exec({ t: "act", id: m.id })} className="flex flex-col items-center gap-0.5 rounded-xl border border-cyan-300/10 bg-black/25 px-1 py-2 text-[10px] hover:bg-cyan-400/15">
                    <span className="text-xl leading-none">{m.icon}</span>{m.label}
                  </button>
                ))}
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5 text-xs">
                {[
                  ["🕒 Clock", { t: "clock" }], ["⏱ 1‑min timer", { t: "timer", secs: 60 }], ["🌤 Weather", { t: "weather" }],
                  ["🎲 Dice", { t: "dice" }], ["🪙 Coin", { t: "coin" }], ["🎧 Own beat", { t: "music-own" }], ["⏹ Stop", { t: "stop" }],
                ].map(([l, c]) => (
                  <button key={l as string} onClick={() => exec(c as Cmd)} className="rounded-full border border-cyan-300/15 bg-black/25 px-3 py-1.5 hover:bg-cyan-400/15">{l as string}</button>
                ))}
              </div>
            </div>
          )}

          {panel === "help" && (
            <div className="grid gap-3 text-xs sm:grid-cols-2">
              {HELP.map((h) => (
                <div key={h.title}>
                  <div className="mb-1 font-semibold text-cyan-300">{h.title}</div>
                  <ul className="space-y-1 text-cyan-50/70">{h.items.map((i) => <li key={i}>{i}</li>)}</ul>
                </div>
              ))}
            </div>
          )}

          {panel === "settings" && (
            <div className="space-y-4 text-sm">
              <label className="flex items-center justify-between gap-3">
                <span>EMO sounds (chirps)</span>
                <input type="checkbox" checked={!muted} onChange={(e) => setMuted(!e.target.checked)} className="h-4 w-4 accent-cyan-300" />
              </label>
              <label className="flex items-center justify-between gap-3">
                <span>Show camera preview</span>
                <input type="checkbox" checked={showCam} onChange={(e) => setShowCam(e.target.checked)} className="h-4 w-4 accent-cyan-300" />
              </label>
              <label className="flex items-center justify-between gap-3">
                <span>Music volume</span>
                <input type="range" min={0} max={100} value={vol} onChange={(e) => { setVol(+e.target.value); music.setVolume(+e.target.value); }} className="w-40 accent-cyan-300" />
              </label>
              <div>
                <div className="mb-1">YouTube Data API key <span className="text-cyan-100/40">(optional – gives exact YouTube results)</span></div>
                <input value={apiKey} onChange={(e) => setApiKey(e.target.value.trim())} type="password" placeholder="AIza…" className="w-full rounded-xl border border-cyan-300/20 bg-black/40 px-3 py-2 text-sm outline-none focus:border-cyan-300/60" />
              </div>
              <div className="flex gap-2">
                <button onClick={() => { vision.forget(); setKnown(0); }} className="rounded-xl border border-cyan-300/20 px-3 py-2 text-xs hover:bg-cyan-400/15">Forget all faces ({known})</button>
                <button onClick={() => exec({ t: "act", id: "sleep" })} className="rounded-xl border border-cyan-300/20 px-3 py-2 text-xs hover:bg-cyan-400/15">Put EMO to sleep</button>
              </div>
              <p className="text-[11px] leading-relaxed text-cyan-100/40">Face recognition runs entirely in your browser (MediaPipe) — video never leaves your device. Face data is stored locally.</p>
            </div>
          )}
        </div>
      )}

      {/* dock */}
      <div className={`absolute inset-x-0 bottom-4 z-40 flex justify-center transition-all duration-500 ${dockShown ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0"}`}>
        <div className="flex items-center gap-1 rounded-full p-1.5 glass">
          <DockBtn on={micOn} label="Microphone" onClick={() => { snd.initAudio(); micOn ? disableMic() : enableMic(); }}>🎙️</DockBtn>
          <DockBtn on={camOn} label="Camera" onClick={() => { snd.initAudio(); camOn ? disableCam() : enableCam(); }}>📷</DockBtn>
          <DockBtn on={panel === "music"} label="Music & commands" onClick={() => toggle("music")}>🎵</DockBtn>
          <DockBtn on={panel === "expr"} label="Expressions & apps" onClick={() => toggle("expr")}>😊</DockBtn>
          <DockBtn on={panel === "help"} label="What can EMO do?" onClick={() => toggle("help")}>❔</DockBtn>
          <DockBtn on={panel === "settings"} label="Settings" onClick={() => toggle("settings")}>⚙️</DockBtn>
          <DockBtn on={false} label="Fullscreen" onClick={fullscreen}>⛶</DockBtn>
        </div>
      </div>

      {/* start screen */}
      {!started && (
        <div className="absolute inset-0 z-50 flex items-end justify-center bg-gradient-to-t from-black/90 via-black/50 to-black/10 pb-[8vh]">
          <div className="emo-fade-up mx-4 w-full max-w-md rounded-3xl p-6 text-center glass">
            <h1 className="text-2xl font-extrabold tracking-[0.3em] text-cyan-300" style={{ fontFamily: "Orbitron, ui-sans-serif", textShadow: "0 0 18px rgba(62,244,255,.6)" }}>EMO</h1>
            <p className="mt-1 text-sm text-cyan-50/60">Your little desk companion. He doesn’t talk — he feels.</p>
            <div className="mt-5 space-y-2 text-left text-sm">
              <label className="flex items-center gap-3 rounded-xl border border-cyan-300/15 bg-black/25 p-3">
                <input type="checkbox" checked={wantMic} onChange={(e) => setWantMic(e.target.checked)} className="h-4 w-4 accent-cyan-300" />
                <span><b>Microphone</b><br /><span className="text-xs text-cyan-100/50">Say “Emo, hands up!” and feel the music’s beat</span></span>
              </label>
              <label className="flex items-center gap-3 rounded-xl border border-cyan-300/15 bg-black/25 p-3">
                <input type="checkbox" checked={wantCam} onChange={(e) => setWantCam(e.target.checked)} className="h-4 w-4 accent-cyan-300" />
                <span><b>Camera</b><br /><span className="text-xs text-cyan-100/50">Face tracking, recognition &amp; mirroring your expressions</span></span>
              </label>
            </div>
            <button onClick={wake} className="mt-5 w-full rounded-2xl bg-cyan-300 py-3 text-sm font-bold tracking-widest text-black shadow-[0_0_30px_rgba(62,244,255,.5)] transition hover:bg-cyan-200 active:scale-[.98]">WAKE EMO UP</button>
          </div>
        </div>
      )}
    </div>
  );
}

function DockBtn({ children, on, label, onClick }: { children: React.ReactNode; on: boolean; label: string; onClick: () => void }) {
  return (
    <button title={label} aria-label={label} onClick={onClick} className={`flex h-11 w-11 items-center justify-center rounded-full text-lg transition ${on ? "bg-cyan-400/25 shadow-[0_0_14px_rgba(62,244,255,.45)]" : "hover:bg-white/10"}`}>
      {children}
    </button>
  );
}
